'--- Class XYPlotForm ---
'Author         : Fabian Kung
'Last Modified  : 29 Dec 2018
'Version        : 1.25
'Description    : This object is used to plot a series of floating point values
'in the range of -1 to +1 onto an X-Y graph.  This version can plot four (4) 
'simultaneous data waveforms.  Data is send to this object via
'the field dblDatain1, dblDatain2, dblDatain3 and dblDatain4.
'
'Related object: XYPlot_menu
' 
'Other user accessible fields:
'intRecordLen - The no. of data points used to form a curve in the XY plot.
'curveColorControl - Set the properties of the line plot as follows:
'curveColorControl.forecolor - Set the line color.
'curveColorControl.height - Set the line width.
'curveColorControl.backcolor - Set the grid lines color.
'Me.XYPlotPictureBox.backcolor - Set background color of the plot
'strTitle - Set the title of the plot
'blnPlot- Assert as true when we want the object to recalculate the points
'strXDivision - Text to show the resolution of X axis (in ns/div)
'intXgridinterval - Interval for drawing the Y grid lines (grid line paralle to Y axis)
'                   This corresponds to the no. of data points before the grid line is 
'                   drawn
'
'Except for Datain, strTitle and blnPlot, the fields for controlling the 
'appearance can be set by invoking XYPlot_menu form, via double clicking
'the picturebox in the form.
'
'Example of usage:
'Assuming that we have created an instance of the object XYPlot named
'xyDisplayObject, we initialize this object as follows:
'
'       xyDisplayObject.dblDatain1 = 0.0    'Assign value to input trace 1.
'       xyDisplayObject.dblDatain2 = 0.0    'Assign value to input trace 2.
'       xyDisplayObject.dblDatain3 = 0.0    'Assign value to input trace 3.
'       xyDisplayObject.dblDatain4 = 0.0    'Assign value to input trace 4.
'       xyDisplayObject.blnPlot = True      'Assert updating of display data
'       xyDisplayObject.strXDivision = "4ns/div"
'       xyDisplayObject.XYPlotPictureBox.Refresh() 'Refresh display
'
'After this every fixed time interval, say every 50 msec we can refresh the object
'to update the display.
'       xyDisplayObject.dblDatain1 = 0.13    'Assign value to input trace 1.
'       xyDisplayObject.dblDatain2 = -0.2    'Assign value to input trace 2.
'       xyDisplayObject.dblDatain3 = 0.89    'Assign value to input trace 3.
'       xyDisplayObject.dblDatain4 = -0.46   'Assign value to input trace 4.
'       xyDisplayObject.XYPlotPictureBox.Refresh() 'Refresh display
'
' The above sequence is repeated as many times as needed to load
' all the input values into the object for display.  All this while bearing in 
' mind to keep the range of the dblDatainx to within -1.0 and +1.0.

Public Class XYPlotForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents XYPlotPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents Y0Label As System.Windows.Forms.Label
    Friend WithEvents Y1Label As System.Windows.Forms.Label
    Friend WithEvents Y_1Label As System.Windows.Forms.Label
    Friend WithEvents Trace1Label As Label
    Friend WithEvents Trace2Label As Label
    Friend WithEvents Trace3Label As Label
    Friend WithEvents Trace4Label As Label
    Friend WithEvents XDivisionLabel As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(XYPlotForm))
        Me.XYPlotPictureBox = New System.Windows.Forms.PictureBox()
        Me.Y0Label = New System.Windows.Forms.Label()
        Me.Y1Label = New System.Windows.Forms.Label()
        Me.Y_1Label = New System.Windows.Forms.Label()
        Me.XDivisionLabel = New System.Windows.Forms.Label()
        Me.Trace1Label = New System.Windows.Forms.Label()
        Me.Trace2Label = New System.Windows.Forms.Label()
        Me.Trace3Label = New System.Windows.Forms.Label()
        Me.Trace4Label = New System.Windows.Forms.Label()
        CType(Me.XYPlotPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'XYPlotPictureBox
        '
        Me.XYPlotPictureBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.XYPlotPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.XYPlotPictureBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.XYPlotPictureBox.Location = New System.Drawing.Point(0, 0)
        Me.XYPlotPictureBox.Name = "XYPlotPictureBox"
        Me.XYPlotPictureBox.Size = New System.Drawing.Size(773, 471)
        Me.XYPlotPictureBox.TabIndex = 0
        Me.XYPlotPictureBox.TabStop = False
        Me.XYPlotPictureBox.Tag = "1"
        '
        'Y0Label
        '
        Me.Y0Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Y0Label.Location = New System.Drawing.Point(0, 196)
        Me.Y0Label.Name = "Y0Label"
        Me.Y0Label.Size = New System.Drawing.Size(35, 24)
        Me.Y0Label.TabIndex = 4
        '
        'Y1Label
        '
        Me.Y1Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Y1Label.Location = New System.Drawing.Point(0, 0)
        Me.Y1Label.Name = "Y1Label"
        Me.Y1Label.Size = New System.Drawing.Size(35, 23)
        Me.Y1Label.TabIndex = 5
        '
        'Y_1Label
        '
        Me.Y_1Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Y_1Label.Location = New System.Drawing.Point(0, 378)
        Me.Y_1Label.Name = "Y_1Label"
        Me.Y_1Label.Size = New System.Drawing.Size(35, 23)
        Me.Y_1Label.TabIndex = 6
        '
        'XDivisionLabel
        '
        Me.XDivisionLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.XDivisionLabel.Location = New System.Drawing.Point(292, 378)
        Me.XDivisionLabel.Name = "XDivisionLabel"
        Me.XDivisionLabel.Size = New System.Drawing.Size(36, 24)
        Me.XDivisionLabel.TabIndex = 7
        '
        'Trace1Label
        '
        Me.Trace1Label.AutoSize = True
        Me.Trace1Label.Location = New System.Drawing.Point(415, 10)
        Me.Trace1Label.Name = "Trace1Label"
        Me.Trace1Label.Size = New System.Drawing.Size(41, 13)
        Me.Trace1Label.TabIndex = 8
        Me.Trace1Label.Text = "Trace1"
        '
        'Trace2Label
        '
        Me.Trace2Label.AutoSize = True
        Me.Trace2Label.Location = New System.Drawing.Point(472, 10)
        Me.Trace2Label.Name = "Trace2Label"
        Me.Trace2Label.Size = New System.Drawing.Size(41, 13)
        Me.Trace2Label.TabIndex = 9
        Me.Trace2Label.Text = "Trace2"
        '
        'Trace3Label
        '
        Me.Trace3Label.AutoSize = True
        Me.Trace3Label.Location = New System.Drawing.Point(529, 9)
        Me.Trace3Label.Name = "Trace3Label"
        Me.Trace3Label.Size = New System.Drawing.Size(41, 13)
        Me.Trace3Label.TabIndex = 10
        Me.Trace3Label.Text = "Trace3"
        '
        'Trace4Label
        '
        Me.Trace4Label.AutoSize = True
        Me.Trace4Label.Location = New System.Drawing.Point(587, 10)
        Me.Trace4Label.Name = "Trace4Label"
        Me.Trace4Label.Size = New System.Drawing.Size(41, 13)
        Me.Trace4Label.TabIndex = 11
        Me.Trace4Label.Text = "Trace4"
        '
        'XYPlotForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(773, 471)
        Me.Controls.Add(Me.Trace4Label)
        Me.Controls.Add(Me.Trace3Label)
        Me.Controls.Add(Me.Trace2Label)
        Me.Controls.Add(Me.Trace1Label)
        Me.Controls.Add(Me.XDivisionLabel)
        Me.Controls.Add(Me.Y_1Label)
        Me.Controls.Add(Me.Y1Label)
        Me.Controls.Add(Me.Y0Label)
        Me.Controls.Add(Me.XYPlotPictureBox)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "XYPlotForm"
        CType(Me.XYPlotPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

    'Public fields
    Public dblDatain1 As Double 'Current input value 1, should be between -1 to +1.
    Public dblDatain2 As Double 'Current input value 2, should be between -1 to +1.
    Public dblDatain3 As Double 'Current input value 3, should be between -1 to +1.
    Public dblDatain4 As Double 'Current input value 4, should be between -1 to +1.
    Public intRecordLen As Integer = 401 'Length of record (no. of points in 1 curve), other suitable values are 151, 251, 301.
    Public curveColor1Control As New Control 'Control object to set the property (e.g. color, thickness) of waveform 1.
    Public curveColor2Control As New Control 'Control object to set the property of waveform 2.
    Public curveColor3Control As New Control 'Control object to set the property of waveform 3.
    Public curveColor4Control As New Control 'Control object to set the property of waveform 4.
    Public strTitle As String = ""
    Public blnPlot As Boolean = False
    Public strXDivision As String = ""
    Public intXgridinterval As Integer = 20 'Interval for drawing the X grid lines (grid line parallel to Y axis), in line per pixels.
    Public dblYmax As Double 'Maximum value for y axis.
    Public dblYmin As Double 'Minimum value for y axis.

    'Private fields
    Private Data1() As Double   'Trace 1 data.
    Private Data2() As Double   'Trace 2 data.
    Private Data3() As Double   'Trace 3 data.
    Private Data4() As Double   'Trace 4 data.

    Private intXrange As Integer
    Private intYrange As Integer
    Private intXinterval As Integer
    Private intYinterval As Integer
    Private intMaxYgrid As Integer = 10 'Max no. of Y grid lines (grid line parallel to X axis), the Y grid lines will be
    'distributed evenly along the Y axis.


    Private Sub XYPlotForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim PicboxStartPoint As Point
        Dim YGraticlepoint As Point

        Try

            'Initialize Controls that determine the appearance of the display
            curveColor1Control.ForeColor = Color.Yellow
            curveColor1Control.BackColor = Color.White
            curveColor1Control.Height = 2
            curveColor2Control.ForeColor = Color.Azure
            curveColor2Control.BackColor = Color.White
            curveColor2Control.Height = 2
            curveColor3Control.ForeColor = Color.RoyalBlue
            curveColor3Control.BackColor = Color.White
            curveColor3Control.Height = 2
            curveColor4Control.ForeColor = Color.Crimson
            curveColor4Control.BackColor = Color.White
            curveColor4Control.Height = 2

            'Add custom control to the controlscollection object
            'in the form.  
            Me.Controls.Add(curveColor1Control)
            Me.Controls.Add(curveColor2Control)
            Me.Controls.Add(curveColor3Control)
            Me.Controls.Add(curveColor4Control)

            'Initialize array to store trace record.
            ReDim Data1(intRecordLen)
            ReDim Data2(intRecordLen)
            ReDim Data3(intRecordLen)
            ReDim Data4(intRecordLen)

            'Start location of XYPlot Picturebox.
            PicboxStartPoint.X = 0
            PicboxStartPoint.Y = 0

            'Get the size of XYPlot Picturebox based on size of the form
            intXrange = XYPlotPictureBox.Width   'Get x-axis range
            intYrange = XYPlotPictureBox.Height  'Get y-axis range
            intXinterval = intXrange / (intRecordLen - 1) 'Interval in the number of pixels for line segment length along X axis.

            If intXinterval < 2 Then 'enforce minimum x interval of 1 pixels
                intXinterval = 1
            End If

            If (intXinterval * (intRecordLen - 1)) < intXrange Then 'Always make sure that the length of each record is larger than the plot area.
                intXinterval = intXinterval + 1                     'Else there would be left over space on the right hand side.
            End If

            intYinterval = intYrange / intMaxYgrid

            'Reposition Y graticles and labels.
            YGraticlepoint.X = 5 'For label y=1
            YGraticlepoint.Y = 5
            Y1Label.Location = YGraticlepoint
            YGraticlepoint.Y = ((intMaxYgrid / 2) * intYinterval) 'For label y=0
            Y0Label.Location = YGraticlepoint
            YGraticlepoint.Y = (intMaxYgrid * intYinterval) - 24 'For label y=-1
            Y_1Label.Location = YGraticlepoint
            Y1Label.Text = CStr(dblYmax)
            Y_1Label.Text = CStr(dblYmin)
            Y0Label.Text = CStr(0.5 * (dblYmax + dblYmin))

            'Display the number of samples per X interval
            XDivisionLabel.Text = CStr(intXgridinterval)

            'Initialize the label indicating the color for each trace.
            Trace1Label.BackColor = curveColor1Control.ForeColor
            Trace2Label.BackColor = curveColor2Control.ForeColor
            Trace3Label.BackColor = curveColor3Control.ForeColor
            Trace4Label.BackColor = curveColor4Control.ForeColor

        Catch ex As Exception
            MessageBox.Show("An error 1 has occured, cannot display XY Plot",
                "Error", MessageBoxButtons.OK)
        End Try

    End Sub

    Private Sub XYPlotPictureBox_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles XYPlotPictureBox.Paint
        Dim WaveformGraphic As Graphics = e.Graphics 'Declare a graphics object provided by the paint event object.

        Dim Data1APoint As Point
        Dim Data1BPoint As Point

        Dim Data2APoint As Point
        Dim Data2BPoint As Point

        Dim Data3APoint As Point
        Dim Data3BPoint As Point

        Dim Data4APoint As Point
        Dim Data4BPoint As Point

        Dim Grid1Point As Point
        Dim Grid2Point As Point
        Dim intIndex As Integer
        Dim dblYmag As Double

        Dim MainPen1 As New Pen(curveColor1Control.ForeColor, curveColor1Control.Height)
        Dim MainPen2 As New Pen(curveColor2Control.ForeColor, curveColor2Control.Height)
        Dim MainPen3 As New Pen(curveColor3Control.ForeColor, curveColor3Control.Height)
        Dim MainPen4 As New Pen(curveColor4Control.ForeColor, curveColor4Control.Height)

        Dim GridPen As New Pen(curveColor1Control.BackColor, 1)

        Try

            dblYmag = CDbl(intYrange / 2)

            'Right shift data first
            If blnPlot = True Then 'Only right shift if Paint event is due to Refresh() method
                'of XYPlot form being called explicitly, here Datain value is valid.
                'If Paint event is due to invalidation of windows (say another window overlap it) 
                'then don't right shift as Datain value is invalid.
                For intIndex = 0 To (intRecordLen - 1)

                    If intIndex = (intRecordLen - 1) Then
                        Data1(0) = dblDatain1       'Get the first datapoint from host function.
                        Data2(0) = dblDatain2       'For old datapoints we just shift.
                        Data3(0) = dblDatain3
                        Data4(0) = dblDatain4
                    Else
                        Data1(intRecordLen - 1 - intIndex) = Data1(intRecordLen - 2 - intIndex)
                        Data2(intRecordLen - 1 - intIndex) = Data2(intRecordLen - 2 - intIndex)
                        Data3(intRecordLen - 1 - intIndex) = Data3(intRecordLen - 2 - intIndex)
                        Data4(intRecordLen - 1 - intIndex) = Data4(intRecordLen - 2 - intIndex)
                    End If

                Next
                blnPlot = False 'reset flag
            End If

            'Drawing the curves and Y grid lines

            For intIndex = 0 To (intRecordLen - 1)
                'Setting up the points x and y values.  Then form a line segment
                'joining adjacent points.  Since the origin in a Windows form is at
                'the top left-hand corner, we need to convert this to the normal x-y plot
                'origin which begin at lower left-hand corner.  This is done by modifying
                'the y value of each point -> intYrange - y_value.
                'Draw segment for Input Data 1.
                Data1APoint.X = intIndex * intXinterval 'Set first point
                Data1APoint.Y = intYrange - CInt((Data1(intIndex) * dblYmag) + dblYmag)

                Data1BPoint.X = (intIndex + 1) * intXinterval 'Set second point
                Data1BPoint.Y = intYrange - CInt((Data1(intIndex + 1) * dblYmag) + dblYmag)

                WaveformGraphic.DrawLine(MainPen1, Data1APoint, Data1BPoint)    'Form line segment for waveform 1

                'Draw segment for Input Data 2.
                Data2APoint.X = intIndex * intXinterval 'Set first point
                Data2APoint.Y = intYrange - CInt((Data2(intIndex) * dblYmag) + dblYmag)

                Data2BPoint.X = (intIndex + 1) * intXinterval 'Set second point
                Data2BPoint.Y = intYrange - CInt((Data2(intIndex + 1) * dblYmag) + dblYmag)

                WaveformGraphic.DrawLine(MainPen2, Data2APoint, Data2BPoint)    'Form line segment for waveform 2

                'Draw segment for Input Data 3.
                Data3APoint.X = intIndex * intXinterval 'Set first point
                Data3APoint.Y = intYrange - CInt((Data3(intIndex) * dblYmag) + dblYmag)

                Data3BPoint.X = (intIndex + 1) * intXinterval 'Set second point
                Data3BPoint.Y = intYrange - CInt((Data3(intIndex + 1) * dblYmag) + dblYmag)

                WaveformGraphic.DrawLine(MainPen3, Data3APoint, Data3BPoint)    'Form line segment for waveform 3

                'Draw segment for Input Data 4.
                Data4APoint.X = intIndex * intXinterval 'Set first point
                Data4APoint.Y = intYrange - CInt((Data4(intIndex) * dblYmag) + dblYmag)

                Data4BPoint.X = (intIndex + 1) * intXinterval 'Set second point
                Data4BPoint.Y = intYrange - CInt((Data4(intIndex + 1) * dblYmag) + dblYmag)

                WaveformGraphic.DrawLine(MainPen4, Data4APoint, Data4BPoint)    'Form line segment for waveform 4

                'Plot Y grid lines
                If (intIndex Mod intXgridinterval) = 0 Then 'Show X grid line every intXgridinterval.
                    Grid1Point.X = intIndex * intXinterval
                    Grid2Point.X = Grid1Point.X
                    Grid1Point.Y = 0
                    Grid2Point.Y = intYrange
                    WaveformGraphic.DrawLine(GridPen, Grid1Point, Grid2Point)
                End If

            Next

            'Plot X grid lines
            For intIndex = 0 To 9
                Grid1Point.X = 0
                Grid2Point.X = intXrange
                Grid1Point.Y = intIndex * intYinterval
                Grid2Point.Y = Grid1Point.Y
                WaveformGraphic.DrawLine(GridPen, Grid1Point, Grid2Point)
            Next

        Catch ex As Exception
            MessageBox.Show("An error 2 has occured, cannot display XY Plot",
             "Error", MessageBoxButtons.OK)
        End Try

    End Sub

    Private Sub XYPlotForm_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        Dim PicboxStartPoint As Point
        Dim YGraticlepoint As Point
        Dim XDivisionPoint As Point

        Try

            'Start location of XYPlot Picturebox.
            PicboxStartPoint.X = 0
            PicboxStartPoint.Y = 0

            'Get the size of XYPlot Picturebox based on size of the form
            intXrange = XYPlotPictureBox.Width   'Get x-axis range
            intYrange = XYPlotPictureBox.Height  'Get y-axis range
            intXinterval = intXrange / (intRecordLen - 1)

            If intXinterval < 2 Then 'enforce minimum x interval of 1 pixels
                intXinterval = 1
            End If

            If (intXinterval * (intRecordLen - 1)) < intXrange Then 'Always make sure that the length of each record is larger than the plot area.
                intXinterval = intXinterval + 1                     'Else there would be left over space on the right hand side.
            End If

            intYinterval = intYrange / intMaxYgrid

            'Reposition Y graticles and labels.
            YGraticlepoint.X = 5 'For label y=1
            YGraticlepoint.Y = 5
            Y1Label.Location = YGraticlepoint
            YGraticlepoint.Y = ((intMaxYgrid / 2) * intYinterval) 'For label y=0
            Y0Label.Location = YGraticlepoint
            YGraticlepoint.Y = (intMaxYgrid * intYinterval) - 24 'For label y=-1
            Y_1Label.Location = YGraticlepoint
            Y1Label.Text = CStr(dblYmax)
            Y_1Label.Text = CStr(dblYmin)
            Y0Label.Text = CStr(0.5 * (dblYmax + dblYmin))

            'Reposition XDivision label
            XDivisionPoint.X = 0.5 * (intRecordLen - 1) * intXinterval
            XDivisionPoint.Y = Me.Height - 54
            XDivisionLabel.Location = XDivisionPoint

            'Display the number of samples per X interval
            XDivisionLabel.Text = CStr(intXgridinterval)

            'Redraw curves and axes.
            XYPlotPictureBox.Refresh()

        Catch ex As Exception
            MessageBox.Show("An error 3 has occured, cannot display XY Plot",
              "Error", MessageBoxButtons.OK)
        End Try
    End Sub

    Private Sub XYPlotPictureBox_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles XYPlotPictureBox.DoubleClick
        Dim AppearanceForm As New XYPlot_menuForm

        AppearanceForm.Show()

    End Sub

End Class
