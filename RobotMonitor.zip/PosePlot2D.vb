﻿Imports System.Math
'--- Class FormBitmap ---
'Author         : Fabian Kung
'Last Modified  : 2 April 2022
'Version        : 1.01
'Description    : This object is used to plot the 2D pose (e.g. orientation and location) of the robot
'                 on an XY plane or window.
' 
'Example of usage:
' Suppose we creat an instance of the class as follows:
' 
' Private mfrmLocation As New PosePlot2DForm
'
' We then initialize the object:
' mfrmLocation.mpointRobotLocation.X = 0
' mfrmLocation.mpointRobotLocation.Y = 0
' mfrmLocation.mdblScaleFactor = 0.1
' mfrmLocation.Show()
'
' As needed, we can update the display of pose as follows:
' mfrmLocation.mdblRobotOrientation = nOrientation
' mfrmLocation.mnChangeDistanceTick = nChangeInDistance
' mfrmLocation.Refresh()


Public Class PosePlot2DForm

    'Public fields
    Public mdblRobotOrientation As Double = 90      'Initial orientation in degree.  Angle measured with respect to x-axis.
    Public mnChangeDistanceTick As Integer = 0
    Public mpointRobotLocation As New Point(0, 0)   'Actual location (x,y) of robot in cm from the origins.
    Public mdblScaleFactor As Double = 0.125        'Scale factor.  The actual position is scaled by
    'mnScaleFactor before being plotted into a 2D window.  The allows a large area to be mapped to
    'a scale surface area on a 2D window, otherwise the current robot location may go beyond the
    'surface area of the 2D window.
    Public mblnCenterSensor As Boolean = False
    Public mblnLeftSensor As Boolean = False
    Public mblnRightSensor As Boolean = False
    Public mblnCollision As Boolean = False

    'Private fields
    Private mnPlotWidth_div2 As Integer             'Plot area width / 2
    Private mnPlotHeigth_div2 As Integer            'Plot area heigth / 2
    Private mpenMainGreen As New Pen(Color.Green, 4)
    Private mpenMainRed As New Pen(Color.Red, 4)
    Private mnRobotSize As Integer = 16 'Length of robot is represented as 10 pixels.
    Private mbrushRed As New SolidBrush(Color.Red)
    Private mbrushGreen As New SolidBrush(Color.Green)

    Private mrectLsen As Rectangle                  'Rectangle to indicate status of left sensor.     
    Private mrectRsen As Rectangle                  'Rectangle to indicate status of right sensor.
    Private mrectCsen As Rectangle                  'Rectangle to indicate status of center sensor.

    Const _SENSOR_MARKER_SIZE = 6                   'In pixels.
    Const _SENSOR_MARER_SIZE_DIV2 = _SENSOR_MARKER_SIZE / 2
    Const _SENSOR_MARKER_SIZE_WITH_OFFSET = _SENSOR_MARKER_SIZE + 4
    Const _ROBOT_ICON_SIZE = 7
    Const _ROBOT_ICON_SIZE_DIV2 = 3

    Private Sub FormBitmap_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Setup the draw parameters and initial position/pose of robot.
        PictureBoxLocation.BackColor = Color.White
        mnPlotHeigth_div2 = PictureBoxLocation.Height / 2
        mnPlotWidth_div2 = PictureBoxLocation.Width / 2
        mrectLsen.Height = _SENSOR_MARKER_SIZE
        mrectLsen.Width = _SENSOR_MARKER_SIZE
        mrectRsen.Height = _SENSOR_MARKER_SIZE
        mrectRsen.Width = _SENSOR_MARKER_SIZE
        mrectCsen.Height = _SENSOR_MARKER_SIZE
        mrectCsen.Width = _SENSOR_MARKER_SIZE

    End Sub

    Private Sub PictureBoxLocation_Paint(sender As Object, e As PaintEventArgs) Handles PictureBoxLocation.Paint
        Dim graphicPlot As Graphics = e.Graphics 'Declare a graphics object provided by the paint event object.
        Dim pointEnd As Point
        Dim dblOrientation As Double
        Dim dblTempCos As Double
        Dim dblTempSin As Double
        Dim nTemp As Integer
        Dim pointLocationScaled As Point
        Dim rectTemp As Rectangle
        Dim nXoffset As Integer
        Dim nYoffset As Integer


        dblOrientation = (mdblRobotOrientation / 180) * PI  ' Update the orientation of the robot.
        dblTempCos = Cos(dblOrientation)                    ' Store the sine and cosine of orientation
        dblTempSin = Sin(dblOrientation)                    ' angle in temperory variables to improve efficiency.
        nTemp = mnChangeDistanceTick

        mpointRobotLocation.X = mpointRobotLocation.X + (dblTempCos * nTemp) 'Update the (x,y) position of the robot.
        mpointRobotLocation.Y = mpointRobotLocation.Y - (dblTempSin * nTemp)

        pointLocationScaled.X = mdblScaleFactor * mpointRobotLocation.X + mnPlotWidth_div2 'Compute the location to plot
        pointLocationScaled.Y = mdblScaleFactor * mpointRobotLocation.Y + mnPlotHeigth_div2 'the symbol of the robot on
        'the display area.

        pointEnd.X = pointLocationScaled.X + mnRobotSize * dblTempCos   'The following instructions draw a symbol of
        pointEnd.Y = pointLocationScaled.Y - mnRobotSize * dblTempSin   'the robot in the display area.  The symbol
        graphicPlot.DrawLine(mpenMainGreen, pointLocationScaled, pointEnd)   'consists of a small circle and line.
        rectTemp.X = pointLocationScaled.X - _ROBOT_ICON_SIZE_DIV2
        rectTemp.Y = pointLocationScaled.Y - _ROBOT_ICON_SIZE_DIV2
        rectTemp.Width = _ROBOT_ICON_SIZE
        rectTemp.Height = _ROBOT_ICON_SIZE
        If mblnCollision = True Then
            graphicPlot.DrawEllipse(mpenMainRed, rectTemp)
        Else
            graphicPlot.DrawEllipse(mpenMainGreen, rectTemp)
        End If


        nXoffset = _SENSOR_MARKER_SIZE_WITH_OFFSET * dblTempSin
        nYoffset = _SENSOR_MARKER_SIZE_WITH_OFFSET * dblTempCos
        mrectCsen.X = pointEnd.X - _SENSOR_MARER_SIZE_DIV2
        mrectCsen.Y = pointEnd.Y - _SENSOR_MARER_SIZE_DIV2
        mrectLsen.X = mrectCsen.X - nXoffset
        mrectLsen.Y = mrectCsen.Y - nYoffset
        mrectRsen.X = mrectCsen.X + nXoffset
        mrectRsen.Y = mrectCsen.Y + nYoffset

        If mblnCenterSensor = True Then
            graphicPlot.FillRectangle(mbrushRed, mrectCsen)
        Else
            graphicPlot.FillRectangle(mbrushGreen, mrectCsen)
        End If
        If mblnLeftSensor = True Then
            graphicPlot.FillRectangle(mbrushRed, mrectLsen)
        Else
            graphicPlot.FillRectangle(mbrushGreen, mrectLsen)
        End If
        If mblnRightSensor = True Then
            graphicPlot.FillRectangle(mbrushRed, mrectRsen)
        Else
            graphicPlot.FillRectangle(mbrushGreen, mrectRsen)
        End If


        ToolStripStatusLabel1.Text = "(x,y) = (" & CStr(mpointRobotLocation.X) & "," & CStr(-mpointRobotLocation.Y) & ")"
    End Sub

    Private Sub PictureBoxLocation_Resize(sender As Object, e As EventArgs) Handles PictureBoxLocation.Resize
        mnPlotHeigth_div2 = PictureBoxLocation.Height / 2
        mnPlotWidth_div2 = PictureBoxLocation.Width / 2
    End Sub

End Class