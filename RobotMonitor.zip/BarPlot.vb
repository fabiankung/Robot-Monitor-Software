﻿'--- Class BarPlot ---
'Author         : Fabian Kung
'Last Modified  : 15 Sep 2019
'Version        : 1.00
'Description    : 
'

Public Class BarPlot
    Inherits System.Windows.Forms.Form

    'Public fields
    Public mN As Integer = 8                         'The default number of bars to display.
    Public mnX(0 To 9) As Integer

    'Private fields
    Private intXrange As Integer
    Private intYrange As Integer
    Private intYinterval As Integer = 10    'Interval of horizontal grid lines in pixels.
    Private intYgridNo As Integer
    Private mpenMain As New Pen(Color.Red, 1)
    Private mGridPen As New Pen(Color.Black, 1)
    Private mbrush As New SolidBrush(Color.Red)
    Private mHeightOffset As Integer = 18 'Offset from bottom of window in pixels
    Private mBarWidth As Integer = 10 'Width of each bar in pixels
    Private mBarSpacing As Integer = 6 'Edge-to-edge spacing between bars in pixels

    Private Sub BarPlot_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Setup the draw parameters.
        PictureBoxBar.BackColor = Color.White
        'Get the size of XYPlot Picturebox based on size of the form
        intXrange = PictureBoxBar.Width   'Get x-axis range
        intYrange = PictureBoxBar.Height  'Get y-axis range
        intYinterval = 10                 'Set default no. of y grid lines.  
        intYgridNo = intYrange / intYinterval
        If mN > 9 Then                    'Limit the maximum no. of bar to show to 10.  
            mN = 9
        End If
    End Sub

    Private Sub PictureBoxBar_Resize(sender As Object, e As EventArgs) Handles PictureBoxBar.Resize

        'Get the size of XYPlot Picturebox based on size of the form
        intXrange = PictureBoxBar.Width   'Get x-axis range
        intYrange = PictureBoxBar.Height  'Get y-axis range
        intYgridNo = intYrange / intYinterval

    End Sub

    Private Sub PictureBoxBar_Paint(sender As Object, e As PaintEventArgs) Handles PictureBoxBar.Paint
        Dim WaveformGraphic As Graphics = e.Graphics 'Declare a graphics object provided by the paint event object.
        Dim nIndex As Integer
        Dim rectTemp As Rectangle
        Dim graphicPlot As Graphics = e.Graphics
        Dim Grid1Point As Point
        Dim Grid2Point As Point


        'Plot Y grid lines
        If intYgridNo < 2 Then
            intYgridNo = 2
        End If
        For intIndex = 2 To intYgridNo
            Grid1Point.X = 0
            Grid2Point.X = intXrange
            Grid1Point.Y = PictureBoxBar.Height - (intIndex * intYinterval) + 1
            Grid2Point.Y = Grid1Point.Y
            WaveformGraphic.DrawLine(mGridPen, Grid1Point, Grid2Point)
        Next

        rectTemp.Width = mBarWidth     'Width of each bar is 10 pixels.
        rectTemp.X = mBarSpacing          'Spacing between each bar is 5 pixels.

        For nIndex = 1 To mN   'Plot each frequency component as a bar.
            rectTemp.Height = mnX(nIndex - 1)
            rectTemp.X = rectTemp.X + mBarWidth + mBarSpacing
            rectTemp.Y = PictureBoxBar.Height - rectTemp.Height - mHeightOffset
            'graphicPlot.DrawRectangle(mpenMain, rectTemp)
            graphicPlot.FillRectangle(mbrush, rectTemp)
        Next nIndex

    End Sub
End Class