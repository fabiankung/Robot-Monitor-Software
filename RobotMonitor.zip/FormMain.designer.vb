﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormMain))
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.ButtonOpen = New System.Windows.Forms.Button()
        Me.LabelMain = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.ComboBoxComPort = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.StatusStripLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.StatusStripLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.GroupBoxCoefficients = New System.Windows.Forms.GroupBox()
        Me.ButtonRestoreFactoryDefault = New System.Windows.Forms.Button()
        Me.ButtonPlay3 = New System.Windows.Forms.Button()
        Me.ButtonPlay2 = New System.Windows.Forms.Button()
        Me.ButtonPlay1 = New System.Windows.Forms.Button()
        Me.TrackBarC10 = New System.Windows.Forms.TrackBar()
        Me.TrackBarC9 = New System.Windows.Forms.TrackBar()
        Me.ButtonC10Up = New System.Windows.Forms.Button()
        Me.ButtonC9Up = New System.Windows.Forms.Button()
        Me.ButtonStore = New System.Windows.Forms.Button()
        Me.ButtonC10Down = New System.Windows.Forms.Button()
        Me.ButtonC9Down = New System.Windows.Forms.Button()
        Me.LabelC10 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.LabelC10Val = New System.Windows.Forms.Label()
        Me.LabelMotorSequence = New System.Windows.Forms.Label()
        Me.LabelC9 = New System.Windows.Forms.Label()
        Me.LabelC9Val = New System.Windows.Forms.Label()
        Me.ButtonC8Up = New System.Windows.Forms.Button()
        Me.TrackBarC8 = New System.Windows.Forms.TrackBar()
        Me.ButtonC8Down = New System.Windows.Forms.Button()
        Me.LabelC8 = New System.Windows.Forms.Label()
        Me.LabelC8Val = New System.Windows.Forms.Label()
        Me.ButtonC7Up = New System.Windows.Forms.Button()
        Me.TrackBarC7 = New System.Windows.Forms.TrackBar()
        Me.ButtonC7Down = New System.Windows.Forms.Button()
        Me.LabelC7 = New System.Windows.Forms.Label()
        Me.TrackBarC6 = New System.Windows.Forms.TrackBar()
        Me.TrackBarC5 = New System.Windows.Forms.TrackBar()
        Me.TrackBarC4 = New System.Windows.Forms.TrackBar()
        Me.TrackBarC3 = New System.Windows.Forms.TrackBar()
        Me.TrackBarC2 = New System.Windows.Forms.TrackBar()
        Me.TrackBarC1 = New System.Windows.Forms.TrackBar()
        Me.LabelC7Val = New System.Windows.Forms.Label()
        Me.LabelC6 = New System.Windows.Forms.Label()
        Me.ButtonC6Up = New System.Windows.Forms.Button()
        Me.ButtonC6Down = New System.Windows.Forms.Button()
        Me.LabelC6Val = New System.Windows.Forms.Label()
        Me.LabelC5 = New System.Windows.Forms.Label()
        Me.ButtonC5Down = New System.Windows.Forms.Button()
        Me.ButtonC5Up = New System.Windows.Forms.Button()
        Me.LabelC5Val = New System.Windows.Forms.Label()
        Me.LabelC4 = New System.Windows.Forms.Label()
        Me.LabelC3 = New System.Windows.Forms.Label()
        Me.LabelC2 = New System.Windows.Forms.Label()
        Me.LabelC1 = New System.Windows.Forms.Label()
        Me.ButtonC4Down = New System.Windows.Forms.Button()
        Me.ButtonC4Up = New System.Windows.Forms.Button()
        Me.LabelC4Val = New System.Windows.Forms.Label()
        Me.ButtonC3Down = New System.Windows.Forms.Button()
        Me.ButtonC3Up = New System.Windows.Forms.Button()
        Me.LabelC3Val = New System.Windows.Forms.Label()
        Me.ButtonC2Down = New System.Windows.Forms.Button()
        Me.ButtonC2Up = New System.Windows.Forms.Button()
        Me.LabelC2Val = New System.Windows.Forms.Label()
        Me.ButtonC1Down = New System.Windows.Forms.Button()
        Me.ButonC1Up = New System.Windows.Forms.Button()
        Me.LabelC1Val = New System.Windows.Forms.Label()
        Me.ButtonConnect = New System.Windows.Forms.Button()
        Me.LabelData1 = New System.Windows.Forms.Label()
        Me.LabelData2 = New System.Windows.Forms.Label()
        Me.LabelData3 = New System.Windows.Forms.Label()
        Me.LabelData5 = New System.Windows.Forms.Label()
        Me.Data1Label = New System.Windows.Forms.Label()
        Me.Data2Label = New System.Windows.Forms.Label()
        Me.Data3Label = New System.Windows.Forms.Label()
        Me.Data5Label = New System.Windows.Forms.Label()
        Me.MainRichTextBox = New System.Windows.Forms.RichTextBox()
        Me.ButtonForwardFast = New System.Windows.Forms.Button()
        Me.ButtonBackward = New System.Windows.Forms.Button()
        Me.ButtonModeNormal = New System.Windows.Forms.Button()
        Me.ButtonModeTest1 = New System.Windows.Forms.Button()
        Me.ButtonModeTest2 = New System.Windows.Forms.Button()
        Me.LabelData6 = New System.Windows.Forms.Label()
        Me.LabelData7 = New System.Windows.Forms.Label()
        Me.Data6Label = New System.Windows.Forms.Label()
        Me.Data7Label = New System.Windows.Forms.Label()
        Me.GroupBoxRobotMode = New System.Windows.Forms.GroupBox()
        Me.LabelGPFlag13 = New System.Windows.Forms.Label()
        Me.Trace1GroupBox = New System.Windows.Forms.GroupBox()
        Me.Trace1RadioButton12 = New System.Windows.Forms.RadioButton()
        Me.Trace1RadioButton11 = New System.Windows.Forms.RadioButton()
        Me.Trace1RadioButton10 = New System.Windows.Forms.RadioButton()
        Me.Trace1RadioButton9 = New System.Windows.Forms.RadioButton()
        Me.Trace1RadioButton8 = New System.Windows.Forms.RadioButton()
        Me.Trace1RadioButton7 = New System.Windows.Forms.RadioButton()
        Me.Trace1RadioButton6 = New System.Windows.Forms.RadioButton()
        Me.Trace1RadioButton5 = New System.Windows.Forms.RadioButton()
        Me.Trace1RadioButton4 = New System.Windows.Forms.RadioButton()
        Me.Trace1RadioButton3 = New System.Windows.Forms.RadioButton()
        Me.Trace1RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.Trace1RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.Trace2GroupBox = New System.Windows.Forms.GroupBox()
        Me.Trace2RadioButton9 = New System.Windows.Forms.RadioButton()
        Me.Trace2RadioButton8 = New System.Windows.Forms.RadioButton()
        Me.Trace2RadioButton7 = New System.Windows.Forms.RadioButton()
        Me.Trace2RadioButton6 = New System.Windows.Forms.RadioButton()
        Me.Trace2RadioButton5 = New System.Windows.Forms.RadioButton()
        Me.Trace2RadioButton4 = New System.Windows.Forms.RadioButton()
        Me.Trace2RadioButton3 = New System.Windows.Forms.RadioButton()
        Me.Trace2RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.Trace2RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.Trace3GroupBox = New System.Windows.Forms.GroupBox()
        Me.Trace3RadioButton4 = New System.Windows.Forms.RadioButton()
        Me.Trace3RadioButton5 = New System.Windows.Forms.RadioButton()
        Me.Trace3RadioButton3 = New System.Windows.Forms.RadioButton()
        Me.Trace3RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.Trace3RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.GroupBoxAction = New System.Windows.Forms.GroupBox()
        Me.ButtonForwardSlow = New System.Windows.Forms.Button()
        Me.ButtonTest = New System.Windows.Forms.Button()
        Me.ButtonTurnRightCont = New System.Windows.Forms.Button()
        Me.ButtonTurnLeftCont = New System.Windows.Forms.Button()
        Me.ButtonForwardNormal = New System.Windows.Forms.Button()
        Me.ButtonStop = New System.Windows.Forms.Button()
        Me.ButtonManualAuto = New System.Windows.Forms.Button()
        Me.ButtonTurnRight = New System.Windows.Forms.Button()
        Me.ButtonTurnLeft = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Trace4GroupBox = New System.Windows.Forms.GroupBox()
        Me.Trace4RadioButton4 = New System.Windows.Forms.RadioButton()
        Me.Trace4RadioButton5 = New System.Windows.Forms.RadioButton()
        Me.Trace4RadioButton3 = New System.Windows.Forms.RadioButton()
        Me.Trace4RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.Trace4RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.TurnAnglePerUnitLabel = New System.Windows.Forms.Label()
        Me.DegPerWheelTickLabel = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Data4Label = New System.Windows.Forms.Label()
        Me.LabelData4 = New System.Windows.Forms.Label()
        Me.LabelData8 = New System.Windows.Forms.Label()
        Me.Data8Label = New System.Windows.Forms.Label()
        Me.P2Trace1CheckBox = New System.Windows.Forms.CheckBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.P2Trace2CheckBox = New System.Windows.Forms.CheckBox()
        Me.P2Trace3CheckBox = New System.Windows.Forms.CheckBox()
        Me.LabelGPFlag11 = New System.Windows.Forms.Label()
        Me.LabelGPFlag12 = New System.Windows.Forms.Label()
        Me.LabelGPFlag14 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GroupBoxGeneralFlag = New System.Windows.Forms.GroupBox()
        Me.LabelGPFlag31 = New System.Windows.Forms.Label()
        Me.LabelGPFlag32 = New System.Windows.Forms.Label()
        Me.LabelGPFlag33 = New System.Windows.Forms.Label()
        Me.LabelGPFlag34 = New System.Windows.Forms.Label()
        Me.LabelGPFlag21 = New System.Windows.Forms.Label()
        Me.LabelGPFlag22 = New System.Windows.Forms.Label()
        Me.LabelGPFlag23 = New System.Windows.Forms.Label()
        Me.LabelGPFlag24 = New System.Windows.Forms.Label()
        Me.ButtonSelectParam = New System.Windows.Forms.Button()
        Me.ButtonModeTest3 = New System.Windows.Forms.Button()
        Me.StatusStrip1.SuspendLayout()
        Me.GroupBoxCoefficients.SuspendLayout()
        CType(Me.TrackBarC10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBarC9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBarC8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBarC7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBarC6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBarC5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBarC4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBarC3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBarC2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBarC1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBoxRobotMode.SuspendLayout()
        Me.Trace1GroupBox.SuspendLayout()
        Me.Trace2GroupBox.SuspendLayout()
        Me.Trace3GroupBox.SuspendLayout()
        Me.GroupBoxAction.SuspendLayout()
        Me.Trace4GroupBox.SuspendLayout()
        Me.GroupBoxGeneralFlag.SuspendLayout()
        Me.SuspendLayout()
        '
        'SerialPort1
        '
        Me.SerialPort1.BaudRate = 115200
        Me.SerialPort1.ReadTimeout = 1000
        Me.SerialPort1.WriteTimeout = 500
        '
        'ButtonOpen
        '
        Me.ButtonOpen.Location = New System.Drawing.Point(113, 8)
        Me.ButtonOpen.Name = "ButtonOpen"
        Me.ButtonOpen.Size = New System.Drawing.Size(68, 43)
        Me.ButtonOpen.TabIndex = 0
        Me.ButtonOpen.Text = "OPEN"
        Me.ToolTip1.SetToolTip(Me.ButtonOpen, "Open a virtual COM port")
        Me.ButtonOpen.UseVisualStyleBackColor = True
        '
        'LabelMain
        '
        Me.LabelMain.AutoSize = True
        Me.LabelMain.Location = New System.Drawing.Point(66, 23)
        Me.LabelMain.Name = "LabelMain"
        Me.LabelMain.Size = New System.Drawing.Size(0, 13)
        Me.LabelMain.TabIndex = 2
        '
        'Timer1
        '
        Me.Timer1.Interval = 5
        '
        'ComboBoxComPort
        '
        Me.ComboBoxComPort.FormattingEnabled = True
        Me.ComboBoxComPort.Location = New System.Drawing.Point(13, 69)
        Me.ComboBoxComPort.Name = "ComboBoxComPort"
        Me.ComboBoxComPort.Size = New System.Drawing.Size(84, 21)
        Me.ComboBoxComPort.TabIndex = 10
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 44)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(86, 13)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Select COM Port"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StatusStripLabel1, Me.StatusStripLabel2})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 516)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1116, 22)
        Me.StatusStrip1.TabIndex = 18
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'StatusStripLabel1
        '
        Me.StatusStripLabel1.Name = "StatusStripLabel1"
        Me.StatusStripLabel1.Size = New System.Drawing.Size(0, 17)
        '
        'StatusStripLabel2
        '
        Me.StatusStripLabel2.Name = "StatusStripLabel2"
        Me.StatusStripLabel2.Size = New System.Drawing.Size(0, 17)
        '
        'GroupBoxCoefficients
        '
        Me.GroupBoxCoefficients.Controls.Add(Me.ButtonRestoreFactoryDefault)
        Me.GroupBoxCoefficients.Controls.Add(Me.ButtonPlay3)
        Me.GroupBoxCoefficients.Controls.Add(Me.ButtonPlay2)
        Me.GroupBoxCoefficients.Controls.Add(Me.ButtonPlay1)
        Me.GroupBoxCoefficients.Controls.Add(Me.TrackBarC10)
        Me.GroupBoxCoefficients.Controls.Add(Me.TrackBarC9)
        Me.GroupBoxCoefficients.Controls.Add(Me.ButtonC10Up)
        Me.GroupBoxCoefficients.Controls.Add(Me.ButtonC9Up)
        Me.GroupBoxCoefficients.Controls.Add(Me.ButtonStore)
        Me.GroupBoxCoefficients.Controls.Add(Me.ButtonC10Down)
        Me.GroupBoxCoefficients.Controls.Add(Me.ButtonC9Down)
        Me.GroupBoxCoefficients.Controls.Add(Me.LabelC10)
        Me.GroupBoxCoefficients.Controls.Add(Me.Label4)
        Me.GroupBoxCoefficients.Controls.Add(Me.LabelC10Val)
        Me.GroupBoxCoefficients.Controls.Add(Me.LabelMotorSequence)
        Me.GroupBoxCoefficients.Controls.Add(Me.LabelC9)
        Me.GroupBoxCoefficients.Controls.Add(Me.LabelC9Val)
        Me.GroupBoxCoefficients.Controls.Add(Me.ButtonC8Up)
        Me.GroupBoxCoefficients.Controls.Add(Me.TrackBarC8)
        Me.GroupBoxCoefficients.Controls.Add(Me.ButtonC8Down)
        Me.GroupBoxCoefficients.Controls.Add(Me.LabelC8)
        Me.GroupBoxCoefficients.Controls.Add(Me.LabelC8Val)
        Me.GroupBoxCoefficients.Controls.Add(Me.ButtonC7Up)
        Me.GroupBoxCoefficients.Controls.Add(Me.TrackBarC7)
        Me.GroupBoxCoefficients.Controls.Add(Me.ButtonC7Down)
        Me.GroupBoxCoefficients.Controls.Add(Me.LabelC7)
        Me.GroupBoxCoefficients.Controls.Add(Me.TrackBarC6)
        Me.GroupBoxCoefficients.Controls.Add(Me.TrackBarC5)
        Me.GroupBoxCoefficients.Controls.Add(Me.TrackBarC4)
        Me.GroupBoxCoefficients.Controls.Add(Me.TrackBarC3)
        Me.GroupBoxCoefficients.Controls.Add(Me.TrackBarC2)
        Me.GroupBoxCoefficients.Controls.Add(Me.TrackBarC1)
        Me.GroupBoxCoefficients.Controls.Add(Me.LabelC7Val)
        Me.GroupBoxCoefficients.Controls.Add(Me.LabelC6)
        Me.GroupBoxCoefficients.Controls.Add(Me.ButtonC6Up)
        Me.GroupBoxCoefficients.Controls.Add(Me.ButtonC6Down)
        Me.GroupBoxCoefficients.Controls.Add(Me.LabelC6Val)
        Me.GroupBoxCoefficients.Controls.Add(Me.LabelC5)
        Me.GroupBoxCoefficients.Controls.Add(Me.ButtonC5Down)
        Me.GroupBoxCoefficients.Controls.Add(Me.ButtonC5Up)
        Me.GroupBoxCoefficients.Controls.Add(Me.LabelC5Val)
        Me.GroupBoxCoefficients.Controls.Add(Me.LabelC4)
        Me.GroupBoxCoefficients.Controls.Add(Me.LabelC3)
        Me.GroupBoxCoefficients.Controls.Add(Me.LabelC2)
        Me.GroupBoxCoefficients.Controls.Add(Me.LabelC1)
        Me.GroupBoxCoefficients.Controls.Add(Me.ButtonC4Down)
        Me.GroupBoxCoefficients.Controls.Add(Me.ButtonC4Up)
        Me.GroupBoxCoefficients.Controls.Add(Me.LabelC4Val)
        Me.GroupBoxCoefficients.Controls.Add(Me.ButtonC3Down)
        Me.GroupBoxCoefficients.Controls.Add(Me.ButtonC3Up)
        Me.GroupBoxCoefficients.Controls.Add(Me.LabelC3Val)
        Me.GroupBoxCoefficients.Controls.Add(Me.ButtonC2Down)
        Me.GroupBoxCoefficients.Controls.Add(Me.ButtonC2Up)
        Me.GroupBoxCoefficients.Controls.Add(Me.LabelC2Val)
        Me.GroupBoxCoefficients.Controls.Add(Me.ButtonC1Down)
        Me.GroupBoxCoefficients.Controls.Add(Me.ButonC1Up)
        Me.GroupBoxCoefficients.Controls.Add(Me.LabelC1Val)
        Me.GroupBoxCoefficients.Location = New System.Drawing.Point(656, 12)
        Me.GroupBoxCoefficients.Name = "GroupBoxCoefficients"
        Me.GroupBoxCoefficients.Size = New System.Drawing.Size(458, 487)
        Me.GroupBoxCoefficients.TabIndex = 33
        Me.GroupBoxCoefficients.TabStop = False
        Me.GroupBoxCoefficients.Text = "Coefficients Adjust"
        '
        'ButtonRestoreFactoryDefault
        '
        Me.ButtonRestoreFactoryDefault.Location = New System.Drawing.Point(6, 242)
        Me.ButtonRestoreFactoryDefault.Name = "ButtonRestoreFactoryDefault"
        Me.ButtonRestoreFactoryDefault.Size = New System.Drawing.Size(69, 56)
        Me.ButtonRestoreFactoryDefault.TabIndex = 52
        Me.ButtonRestoreFactoryDefault.Text = "Restore Factory Default"
        Me.ButtonRestoreFactoryDefault.UseVisualStyleBackColor = True
        '
        'ButtonPlay3
        '
        Me.ButtonPlay3.Location = New System.Drawing.Point(6, 185)
        Me.ButtonPlay3.Name = "ButtonPlay3"
        Me.ButtonPlay3.Size = New System.Drawing.Size(70, 43)
        Me.ButtonPlay3.TabIndex = 51
        Me.ButtonPlay3.Text = "Restore 3"
        Me.ButtonPlay3.UseVisualStyleBackColor = True
        '
        'ButtonPlay2
        '
        Me.ButtonPlay2.Location = New System.Drawing.Point(6, 136)
        Me.ButtonPlay2.Name = "ButtonPlay2"
        Me.ButtonPlay2.Size = New System.Drawing.Size(70, 43)
        Me.ButtonPlay2.TabIndex = 50
        Me.ButtonPlay2.Text = "Restore 2"
        Me.ButtonPlay2.UseVisualStyleBackColor = True
        '
        'ButtonPlay1
        '
        Me.ButtonPlay1.Location = New System.Drawing.Point(6, 87)
        Me.ButtonPlay1.Name = "ButtonPlay1"
        Me.ButtonPlay1.Size = New System.Drawing.Size(70, 43)
        Me.ButtonPlay1.TabIndex = 45
        Me.ButtonPlay1.Text = "Restore 1"
        Me.ButtonPlay1.UseVisualStyleBackColor = True
        '
        'TrackBarC10
        '
        Me.TrackBarC10.Location = New System.Drawing.Point(222, 436)
        Me.TrackBarC10.Maximum = 180
        Me.TrackBarC10.Name = "TrackBarC10"
        Me.TrackBarC10.Size = New System.Drawing.Size(172, 45)
        Me.TrackBarC10.TabIndex = 49
        Me.TrackBarC10.TickFrequency = 10
        Me.TrackBarC10.Value = 90
        '
        'TrackBarC9
        '
        Me.TrackBarC9.Location = New System.Drawing.Point(222, 393)
        Me.TrackBarC9.Maximum = 180
        Me.TrackBarC9.Name = "TrackBarC9"
        Me.TrackBarC9.Size = New System.Drawing.Size(172, 45)
        Me.TrackBarC9.TabIndex = 48
        Me.TrackBarC9.TickFrequency = 10
        Me.TrackBarC9.Value = 90
        '
        'ButtonC10Up
        '
        Me.ButtonC10Up.Location = New System.Drawing.Point(400, 434)
        Me.ButtonC10Up.Name = "ButtonC10Up"
        Me.ButtonC10Up.Size = New System.Drawing.Size(50, 41)
        Me.ButtonC10Up.TabIndex = 47
        Me.ButtonC10Up.Text = "Up"
        Me.ButtonC10Up.UseVisualStyleBackColor = True
        '
        'ButtonC9Up
        '
        Me.ButtonC9Up.Location = New System.Drawing.Point(400, 387)
        Me.ButtonC9Up.Name = "ButtonC9Up"
        Me.ButtonC9Up.Size = New System.Drawing.Size(50, 41)
        Me.ButtonC9Up.TabIndex = 46
        Me.ButtonC9Up.Text = "Up"
        Me.ButtonC9Up.UseVisualStyleBackColor = True
        '
        'ButtonStore
        '
        Me.ButtonStore.Location = New System.Drawing.Point(6, 35)
        Me.ButtonStore.Name = "ButtonStore"
        Me.ButtonStore.Size = New System.Drawing.Size(70, 46)
        Me.ButtonStore.TabIndex = 41
        Me.ButtonStore.Text = "Store Coefficients"
        Me.ButtonStore.UseVisualStyleBackColor = True
        '
        'ButtonC10Down
        '
        Me.ButtonC10Down.Location = New System.Drawing.Point(166, 437)
        Me.ButtonC10Down.Name = "ButtonC10Down"
        Me.ButtonC10Down.Size = New System.Drawing.Size(50, 41)
        Me.ButtonC10Down.TabIndex = 45
        Me.ButtonC10Down.Text = "Down"
        Me.ButtonC10Down.UseVisualStyleBackColor = True
        '
        'ButtonC9Down
        '
        Me.ButtonC9Down.Location = New System.Drawing.Point(166, 390)
        Me.ButtonC9Down.Name = "ButtonC9Down"
        Me.ButtonC9Down.Size = New System.Drawing.Size(50, 41)
        Me.ButtonC9Down.TabIndex = 44
        Me.ButtonC9Down.Text = "Down"
        Me.ButtonC9Down.UseVisualStyleBackColor = True
        '
        'LabelC10
        '
        Me.LabelC10.AutoSize = True
        Me.LabelC10.Location = New System.Drawing.Point(126, 441)
        Me.LabelC10.Name = "LabelC10"
        Me.LabelC10.Size = New System.Drawing.Size(19, 13)
        Me.LabelC10.TabIndex = 43
        Me.LabelC10.Text = "10"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 311)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(76, 13)
        Me.Label4.TabIndex = 44
        Me.Label4.Text = "Sequence No."
        '
        'LabelC10Val
        '
        Me.LabelC10Val.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelC10Val.Location = New System.Drawing.Point(82, 440)
        Me.LabelC10Val.Name = "LabelC10Val"
        Me.LabelC10Val.Size = New System.Drawing.Size(44, 21)
        Me.LabelC10Val.TabIndex = 42
        '
        'LabelMotorSequence
        '
        Me.LabelMotorSequence.AutoSize = True
        Me.LabelMotorSequence.Location = New System.Drawing.Point(35, 335)
        Me.LabelMotorSequence.Name = "LabelMotorSequence"
        Me.LabelMotorSequence.Size = New System.Drawing.Size(13, 13)
        Me.LabelMotorSequence.TabIndex = 43
        Me.LabelMotorSequence.Text = "0"
        '
        'LabelC9
        '
        Me.LabelC9.AutoSize = True
        Me.LabelC9.Location = New System.Drawing.Point(132, 401)
        Me.LabelC9.Name = "LabelC9"
        Me.LabelC9.Size = New System.Drawing.Size(13, 13)
        Me.LabelC9.TabIndex = 41
        Me.LabelC9.Text = "9"
        '
        'LabelC9Val
        '
        Me.LabelC9Val.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelC9Val.Location = New System.Drawing.Point(82, 396)
        Me.LabelC9Val.Name = "LabelC9Val"
        Me.LabelC9Val.Size = New System.Drawing.Size(44, 21)
        Me.LabelC9Val.TabIndex = 40
        '
        'ButtonC8Up
        '
        Me.ButtonC8Up.Location = New System.Drawing.Point(400, 340)
        Me.ButtonC8Up.Name = "ButtonC8Up"
        Me.ButtonC8Up.Size = New System.Drawing.Size(50, 41)
        Me.ButtonC8Up.TabIndex = 39
        Me.ButtonC8Up.Text = "Up"
        Me.ButtonC8Up.UseVisualStyleBackColor = True
        '
        'TrackBarC8
        '
        Me.TrackBarC8.Location = New System.Drawing.Point(222, 342)
        Me.TrackBarC8.Maximum = 180
        Me.TrackBarC8.Name = "TrackBarC8"
        Me.TrackBarC8.Size = New System.Drawing.Size(172, 45)
        Me.TrackBarC8.TabIndex = 38
        Me.TrackBarC8.TickFrequency = 10
        Me.TrackBarC8.Value = 90
        '
        'ButtonC8Down
        '
        Me.ButtonC8Down.Location = New System.Drawing.Point(166, 341)
        Me.ButtonC8Down.Name = "ButtonC8Down"
        Me.ButtonC8Down.Size = New System.Drawing.Size(50, 41)
        Me.ButtonC8Down.TabIndex = 37
        Me.ButtonC8Down.Text = "Down"
        Me.ButtonC8Down.UseVisualStyleBackColor = True
        '
        'LabelC8
        '
        Me.LabelC8.AutoSize = True
        Me.LabelC8.Location = New System.Drawing.Point(132, 354)
        Me.LabelC8.Name = "LabelC8"
        Me.LabelC8.Size = New System.Drawing.Size(13, 13)
        Me.LabelC8.TabIndex = 36
        Me.LabelC8.Text = "8"
        '
        'LabelC8Val
        '
        Me.LabelC8Val.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelC8Val.Location = New System.Drawing.Point(82, 351)
        Me.LabelC8Val.Name = "LabelC8Val"
        Me.LabelC8Val.Size = New System.Drawing.Size(44, 21)
        Me.LabelC8Val.TabIndex = 35
        '
        'ButtonC7Up
        '
        Me.ButtonC7Up.Location = New System.Drawing.Point(400, 293)
        Me.ButtonC7Up.Name = "ButtonC7Up"
        Me.ButtonC7Up.Size = New System.Drawing.Size(50, 41)
        Me.ButtonC7Up.TabIndex = 34
        Me.ButtonC7Up.Text = "Up"
        Me.ButtonC7Up.UseVisualStyleBackColor = True
        '
        'TrackBarC7
        '
        Me.TrackBarC7.Location = New System.Drawing.Point(222, 298)
        Me.TrackBarC7.Maximum = 180
        Me.TrackBarC7.Name = "TrackBarC7"
        Me.TrackBarC7.Size = New System.Drawing.Size(172, 45)
        Me.TrackBarC7.TabIndex = 33
        Me.TrackBarC7.TickFrequency = 10
        Me.TrackBarC7.Value = 90
        '
        'ButtonC7Down
        '
        Me.ButtonC7Down.Location = New System.Drawing.Point(166, 293)
        Me.ButtonC7Down.Name = "ButtonC7Down"
        Me.ButtonC7Down.Size = New System.Drawing.Size(50, 41)
        Me.ButtonC7Down.TabIndex = 32
        Me.ButtonC7Down.Text = "Down"
        Me.ButtonC7Down.UseVisualStyleBackColor = True
        '
        'LabelC7
        '
        Me.LabelC7.AutoSize = True
        Me.LabelC7.Location = New System.Drawing.Point(132, 307)
        Me.LabelC7.Name = "LabelC7"
        Me.LabelC7.Size = New System.Drawing.Size(13, 13)
        Me.LabelC7.TabIndex = 31
        Me.LabelC7.Text = "7"
        '
        'TrackBarC6
        '
        Me.TrackBarC6.Location = New System.Drawing.Point(222, 250)
        Me.TrackBarC6.Maximum = 180
        Me.TrackBarC6.Name = "TrackBarC6"
        Me.TrackBarC6.Size = New System.Drawing.Size(172, 45)
        Me.TrackBarC6.TabIndex = 30
        Me.TrackBarC6.TickFrequency = 10
        Me.TrackBarC6.Value = 90
        '
        'TrackBarC5
        '
        Me.TrackBarC5.Location = New System.Drawing.Point(222, 199)
        Me.TrackBarC5.Maximum = 180
        Me.TrackBarC5.Name = "TrackBarC5"
        Me.TrackBarC5.Size = New System.Drawing.Size(172, 45)
        Me.TrackBarC5.TabIndex = 29
        Me.TrackBarC5.TickFrequency = 10
        Me.TrackBarC5.Value = 90
        '
        'TrackBarC4
        '
        Me.TrackBarC4.Location = New System.Drawing.Point(222, 150)
        Me.TrackBarC4.Maximum = 180
        Me.TrackBarC4.Name = "TrackBarC4"
        Me.TrackBarC4.Size = New System.Drawing.Size(172, 45)
        Me.TrackBarC4.TabIndex = 28
        Me.TrackBarC4.TickFrequency = 10
        Me.TrackBarC4.Value = 90
        '
        'TrackBarC3
        '
        Me.TrackBarC3.Location = New System.Drawing.Point(222, 101)
        Me.TrackBarC3.Maximum = 180
        Me.TrackBarC3.Name = "TrackBarC3"
        Me.TrackBarC3.Size = New System.Drawing.Size(172, 45)
        Me.TrackBarC3.TabIndex = 27
        Me.TrackBarC3.TickFrequency = 10
        Me.TrackBarC3.Value = 90
        '
        'TrackBarC2
        '
        Me.TrackBarC2.Location = New System.Drawing.Point(222, 58)
        Me.TrackBarC2.Maximum = 180
        Me.TrackBarC2.Name = "TrackBarC2"
        Me.TrackBarC2.Size = New System.Drawing.Size(172, 45)
        Me.TrackBarC2.TabIndex = 26
        Me.TrackBarC2.TickFrequency = 10
        Me.TrackBarC2.Value = 90
        '
        'TrackBarC1
        '
        Me.TrackBarC1.Location = New System.Drawing.Point(222, 14)
        Me.TrackBarC1.Maximum = 180
        Me.TrackBarC1.Name = "TrackBarC1"
        Me.TrackBarC1.Size = New System.Drawing.Size(172, 45)
        Me.TrackBarC1.TabIndex = 25
        Me.TrackBarC1.TickFrequency = 10
        Me.TrackBarC1.Value = 90
        '
        'LabelC7Val
        '
        Me.LabelC7Val.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelC7Val.Location = New System.Drawing.Point(82, 306)
        Me.LabelC7Val.Name = "LabelC7Val"
        Me.LabelC7Val.Size = New System.Drawing.Size(44, 21)
        Me.LabelC7Val.TabIndex = 24
        '
        'LabelC6
        '
        Me.LabelC6.AutoSize = True
        Me.LabelC6.Location = New System.Drawing.Point(132, 260)
        Me.LabelC6.Name = "LabelC6"
        Me.LabelC6.Size = New System.Drawing.Size(13, 13)
        Me.LabelC6.TabIndex = 23
        Me.LabelC6.Text = "6"
        '
        'ButtonC6Up
        '
        Me.ButtonC6Up.Location = New System.Drawing.Point(400, 246)
        Me.ButtonC6Up.Name = "ButtonC6Up"
        Me.ButtonC6Up.Size = New System.Drawing.Size(50, 41)
        Me.ButtonC6Up.TabIndex = 22
        Me.ButtonC6Up.Text = "Up"
        Me.ButtonC6Up.UseVisualStyleBackColor = True
        '
        'ButtonC6Down
        '
        Me.ButtonC6Down.Location = New System.Drawing.Point(166, 246)
        Me.ButtonC6Down.Name = "ButtonC6Down"
        Me.ButtonC6Down.Size = New System.Drawing.Size(50, 41)
        Me.ButtonC6Down.TabIndex = 21
        Me.ButtonC6Down.Text = "Down"
        Me.ButtonC6Down.UseVisualStyleBackColor = True
        '
        'LabelC6Val
        '
        Me.LabelC6Val.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelC6Val.Location = New System.Drawing.Point(82, 256)
        Me.LabelC6Val.Name = "LabelC6Val"
        Me.LabelC6Val.Size = New System.Drawing.Size(44, 21)
        Me.LabelC6Val.TabIndex = 20
        '
        'LabelC5
        '
        Me.LabelC5.AutoSize = True
        Me.LabelC5.Location = New System.Drawing.Point(132, 213)
        Me.LabelC5.Name = "LabelC5"
        Me.LabelC5.Size = New System.Drawing.Size(13, 13)
        Me.LabelC5.TabIndex = 19
        Me.LabelC5.Text = "5"
        '
        'ButtonC5Down
        '
        Me.ButtonC5Down.Location = New System.Drawing.Point(166, 199)
        Me.ButtonC5Down.Name = "ButtonC5Down"
        Me.ButtonC5Down.Size = New System.Drawing.Size(50, 41)
        Me.ButtonC5Down.TabIndex = 18
        Me.ButtonC5Down.Text = "Down"
        Me.ButtonC5Down.UseVisualStyleBackColor = True
        '
        'ButtonC5Up
        '
        Me.ButtonC5Up.Location = New System.Drawing.Point(400, 199)
        Me.ButtonC5Up.Name = "ButtonC5Up"
        Me.ButtonC5Up.Size = New System.Drawing.Size(50, 41)
        Me.ButtonC5Up.TabIndex = 17
        Me.ButtonC5Up.Text = "Up"
        Me.ButtonC5Up.UseVisualStyleBackColor = True
        '
        'LabelC5Val
        '
        Me.LabelC5Val.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelC5Val.Location = New System.Drawing.Point(82, 209)
        Me.LabelC5Val.Name = "LabelC5Val"
        Me.LabelC5Val.Size = New System.Drawing.Size(44, 21)
        Me.LabelC5Val.TabIndex = 16
        '
        'LabelC4
        '
        Me.LabelC4.AutoSize = True
        Me.LabelC4.Location = New System.Drawing.Point(132, 168)
        Me.LabelC4.Name = "LabelC4"
        Me.LabelC4.Size = New System.Drawing.Size(13, 13)
        Me.LabelC4.TabIndex = 15
        Me.LabelC4.Text = "4"
        '
        'LabelC3
        '
        Me.LabelC3.AutoSize = True
        Me.LabelC3.Location = New System.Drawing.Point(132, 122)
        Me.LabelC3.Name = "LabelC3"
        Me.LabelC3.Size = New System.Drawing.Size(13, 13)
        Me.LabelC3.TabIndex = 14
        Me.LabelC3.Text = "3"
        '
        'LabelC2
        '
        Me.LabelC2.AutoSize = True
        Me.LabelC2.Location = New System.Drawing.Point(132, 72)
        Me.LabelC2.Name = "LabelC2"
        Me.LabelC2.Size = New System.Drawing.Size(13, 13)
        Me.LabelC2.TabIndex = 13
        Me.LabelC2.Text = "2"
        '
        'LabelC1
        '
        Me.LabelC1.AutoSize = True
        Me.LabelC1.Location = New System.Drawing.Point(132, 26)
        Me.LabelC1.Name = "LabelC1"
        Me.LabelC1.Size = New System.Drawing.Size(13, 13)
        Me.LabelC1.TabIndex = 12
        Me.LabelC1.Text = "1"
        '
        'ButtonC4Down
        '
        Me.ButtonC4Down.Location = New System.Drawing.Point(166, 152)
        Me.ButtonC4Down.Name = "ButtonC4Down"
        Me.ButtonC4Down.Size = New System.Drawing.Size(50, 41)
        Me.ButtonC4Down.TabIndex = 11
        Me.ButtonC4Down.Text = "Down"
        Me.ButtonC4Down.UseVisualStyleBackColor = True
        '
        'ButtonC4Up
        '
        Me.ButtonC4Up.Location = New System.Drawing.Point(400, 152)
        Me.ButtonC4Up.Name = "ButtonC4Up"
        Me.ButtonC4Up.Size = New System.Drawing.Size(50, 41)
        Me.ButtonC4Up.TabIndex = 10
        Me.ButtonC4Up.Text = "Up"
        Me.ButtonC4Up.UseVisualStyleBackColor = True
        '
        'LabelC4Val
        '
        Me.LabelC4Val.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelC4Val.Location = New System.Drawing.Point(82, 167)
        Me.LabelC4Val.Name = "LabelC4Val"
        Me.LabelC4Val.Size = New System.Drawing.Size(44, 21)
        Me.LabelC4Val.TabIndex = 9
        '
        'ButtonC3Down
        '
        Me.ButtonC3Down.Location = New System.Drawing.Point(166, 105)
        Me.ButtonC3Down.Name = "ButtonC3Down"
        Me.ButtonC3Down.Size = New System.Drawing.Size(50, 41)
        Me.ButtonC3Down.TabIndex = 8
        Me.ButtonC3Down.Text = "Down"
        Me.ButtonC3Down.UseVisualStyleBackColor = True
        '
        'ButtonC3Up
        '
        Me.ButtonC3Up.Location = New System.Drawing.Point(400, 105)
        Me.ButtonC3Up.Name = "ButtonC3Up"
        Me.ButtonC3Up.Size = New System.Drawing.Size(50, 41)
        Me.ButtonC3Up.TabIndex = 7
        Me.ButtonC3Up.Text = "Up"
        Me.ButtonC3Up.UseVisualStyleBackColor = True
        '
        'LabelC3Val
        '
        Me.LabelC3Val.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelC3Val.Location = New System.Drawing.Point(82, 118)
        Me.LabelC3Val.Name = "LabelC3Val"
        Me.LabelC3Val.Size = New System.Drawing.Size(44, 21)
        Me.LabelC3Val.TabIndex = 6
        '
        'ButtonC2Down
        '
        Me.ButtonC2Down.Location = New System.Drawing.Point(166, 58)
        Me.ButtonC2Down.Name = "ButtonC2Down"
        Me.ButtonC2Down.Size = New System.Drawing.Size(50, 41)
        Me.ButtonC2Down.TabIndex = 5
        Me.ButtonC2Down.Text = "Down"
        Me.ButtonC2Down.UseVisualStyleBackColor = True
        '
        'ButtonC2Up
        '
        Me.ButtonC2Up.Location = New System.Drawing.Point(400, 58)
        Me.ButtonC2Up.Name = "ButtonC2Up"
        Me.ButtonC2Up.Size = New System.Drawing.Size(50, 41)
        Me.ButtonC2Up.TabIndex = 4
        Me.ButtonC2Up.Text = "Up"
        Me.ButtonC2Up.UseVisualStyleBackColor = True
        '
        'LabelC2Val
        '
        Me.LabelC2Val.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelC2Val.Location = New System.Drawing.Point(82, 68)
        Me.LabelC2Val.Name = "LabelC2Val"
        Me.LabelC2Val.Size = New System.Drawing.Size(44, 21)
        Me.LabelC2Val.TabIndex = 3
        '
        'ButtonC1Down
        '
        Me.ButtonC1Down.Location = New System.Drawing.Point(166, 14)
        Me.ButtonC1Down.Name = "ButtonC1Down"
        Me.ButtonC1Down.Size = New System.Drawing.Size(50, 41)
        Me.ButtonC1Down.TabIndex = 2
        Me.ButtonC1Down.Text = "Down"
        Me.ButtonC1Down.UseVisualStyleBackColor = True
        '
        'ButonC1Up
        '
        Me.ButonC1Up.Location = New System.Drawing.Point(400, 12)
        Me.ButonC1Up.Name = "ButonC1Up"
        Me.ButonC1Up.Size = New System.Drawing.Size(50, 41)
        Me.ButonC1Up.TabIndex = 1
        Me.ButonC1Up.Text = "Up"
        Me.ButonC1Up.UseVisualStyleBackColor = True
        '
        'LabelC1Val
        '
        Me.LabelC1Val.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelC1Val.Location = New System.Drawing.Point(82, 25)
        Me.LabelC1Val.Name = "LabelC1Val"
        Me.LabelC1Val.Size = New System.Drawing.Size(44, 21)
        Me.LabelC1Val.TabIndex = 0
        '
        'ButtonConnect
        '
        Me.ButtonConnect.Location = New System.Drawing.Point(113, 55)
        Me.ButtonConnect.Name = "ButtonConnect"
        Me.ButtonConnect.Size = New System.Drawing.Size(68, 48)
        Me.ButtonConnect.TabIndex = 34
        Me.ButtonConnect.Text = "&Connect"
        Me.ToolTip1.SetToolTip(Me.ButtonConnect, "Initiate bi-directional data transfer with robot")
        Me.ButtonConnect.UseVisualStyleBackColor = True
        '
        'LabelData1
        '
        Me.LabelData1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelData1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelData1.Location = New System.Drawing.Point(461, 412)
        Me.LabelData1.Name = "LabelData1"
        Me.LabelData1.Size = New System.Drawing.Size(43, 21)
        Me.LabelData1.TabIndex = 36
        '
        'LabelData2
        '
        Me.LabelData2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelData2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelData2.Location = New System.Drawing.Point(461, 435)
        Me.LabelData2.Name = "LabelData2"
        Me.LabelData2.Size = New System.Drawing.Size(43, 19)
        Me.LabelData2.TabIndex = 37
        '
        'LabelData3
        '
        Me.LabelData3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelData3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelData3.Location = New System.Drawing.Point(461, 458)
        Me.LabelData3.Name = "LabelData3"
        Me.LabelData3.Size = New System.Drawing.Size(43, 20)
        Me.LabelData3.TabIndex = 38
        '
        'LabelData5
        '
        Me.LabelData5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelData5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelData5.Location = New System.Drawing.Point(602, 399)
        Me.LabelData5.Name = "LabelData5"
        Me.LabelData5.Size = New System.Drawing.Size(49, 24)
        Me.LabelData5.TabIndex = 45
        '
        'Data1Label
        '
        Me.Data1Label.AutoSize = True
        Me.Data1Label.Location = New System.Drawing.Point(360, 413)
        Me.Data1Label.Name = "Data1Label"
        Me.Data1Label.Size = New System.Drawing.Size(95, 13)
        Me.Data1Label.TabIndex = 46
        Me.Data1Label.Text = "Param 1 Received"
        '
        'Data2Label
        '
        Me.Data2Label.AutoSize = True
        Me.Data2Label.Location = New System.Drawing.Point(360, 437)
        Me.Data2Label.Name = "Data2Label"
        Me.Data2Label.Size = New System.Drawing.Size(95, 13)
        Me.Data2Label.TabIndex = 47
        Me.Data2Label.Text = "Param 2 Received"
        '
        'Data3Label
        '
        Me.Data3Label.AutoSize = True
        Me.Data3Label.Location = New System.Drawing.Point(360, 459)
        Me.Data3Label.Name = "Data3Label"
        Me.Data3Label.Size = New System.Drawing.Size(95, 13)
        Me.Data3Label.TabIndex = 48
        Me.Data3Label.Text = "Param 3 Received"
        '
        'Data5Label
        '
        Me.Data5Label.AutoSize = True
        Me.Data5Label.Location = New System.Drawing.Point(510, 411)
        Me.Data5Label.Name = "Data5Label"
        Me.Data5Label.Size = New System.Drawing.Size(80, 13)
        Me.Data5Label.TabIndex = 49
        Me.Data5Label.Text = "ADC Channel 1"
        '
        'MainRichTextBox
        '
        Me.MainRichTextBox.Location = New System.Drawing.Point(12, 226)
        Me.MainRichTextBox.Name = "MainRichTextBox"
        Me.MainRichTextBox.Size = New System.Drawing.Size(267, 246)
        Me.MainRichTextBox.TabIndex = 50
        Me.MainRichTextBox.Text = ""
        '
        'ButtonForwardFast
        '
        Me.ButtonForwardFast.Location = New System.Drawing.Point(6, 12)
        Me.ButtonForwardFast.Name = "ButtonForwardFast"
        Me.ButtonForwardFast.Size = New System.Drawing.Size(55, 41)
        Me.ButtonForwardFast.TabIndex = 51
        Me.ButtonForwardFast.Text = "Forward Fast"
        Me.ButtonForwardFast.UseVisualStyleBackColor = True
        '
        'ButtonBackward
        '
        Me.ButtonBackward.Location = New System.Drawing.Point(194, 13)
        Me.ButtonBackward.Name = "ButtonBackward"
        Me.ButtonBackward.Size = New System.Drawing.Size(74, 40)
        Me.ButtonBackward.TabIndex = 54
        Me.ButtonBackward.Text = "Backward"
        Me.ButtonBackward.UseVisualStyleBackColor = True
        '
        'ButtonModeNormal
        '
        Me.ButtonModeNormal.Location = New System.Drawing.Point(12, 19)
        Me.ButtonModeNormal.Name = "ButtonModeNormal"
        Me.ButtonModeNormal.Size = New System.Drawing.Size(59, 25)
        Me.ButtonModeNormal.TabIndex = 55
        Me.ButtonModeNormal.Text = "Normal"
        Me.ToolTip1.SetToolTip(Me.ButtonModeNormal, "Normal mode")
        Me.ButtonModeNormal.UseVisualStyleBackColor = True
        '
        'ButtonModeTest1
        '
        Me.ButtonModeTest1.Location = New System.Drawing.Point(77, 19)
        Me.ButtonModeTest1.Name = "ButtonModeTest1"
        Me.ButtonModeTest1.Size = New System.Drawing.Size(57, 25)
        Me.ButtonModeTest1.TabIndex = 56
        Me.ButtonModeTest1.Text = "Test1"
        Me.ToolTip1.SetToolTip(Me.ButtonModeTest1, "Turn both wheels forward and backward repeatedly")
        Me.ButtonModeTest1.UseVisualStyleBackColor = True
        '
        'ButtonModeTest2
        '
        Me.ButtonModeTest2.Location = New System.Drawing.Point(78, 47)
        Me.ButtonModeTest2.Name = "ButtonModeTest2"
        Me.ButtonModeTest2.Size = New System.Drawing.Size(57, 26)
        Me.ButtonModeTest2.TabIndex = 57
        Me.ButtonModeTest2.Text = "Test2"
        Me.ToolTip1.SetToolTip(Me.ButtonModeTest2, "Shuts down both wheels")
        Me.ButtonModeTest2.UseVisualStyleBackColor = True
        '
        'LabelData6
        '
        Me.LabelData6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelData6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelData6.Location = New System.Drawing.Point(602, 426)
        Me.LabelData6.Name = "LabelData6"
        Me.LabelData6.Size = New System.Drawing.Size(49, 24)
        Me.LabelData6.TabIndex = 58
        '
        'LabelData7
        '
        Me.LabelData7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelData7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelData7.Location = New System.Drawing.Point(602, 457)
        Me.LabelData7.Name = "LabelData7"
        Me.LabelData7.Size = New System.Drawing.Size(48, 24)
        Me.LabelData7.TabIndex = 59
        '
        'Data6Label
        '
        Me.Data6Label.AutoSize = True
        Me.Data6Label.Location = New System.Drawing.Point(510, 438)
        Me.Data6Label.Name = "Data6Label"
        Me.Data6Label.Size = New System.Drawing.Size(80, 13)
        Me.Data6Label.TabIndex = 60
        Me.Data6Label.Text = "ADC Channel 2"
        '
        'Data7Label
        '
        Me.Data7Label.AutoSize = True
        Me.Data7Label.Location = New System.Drawing.Point(510, 461)
        Me.Data7Label.Name = "Data7Label"
        Me.Data7Label.Size = New System.Drawing.Size(80, 13)
        Me.Data7Label.TabIndex = 61
        Me.Data7Label.Text = "ADC Channel 3"
        '
        'GroupBoxRobotMode
        '
        Me.GroupBoxRobotMode.Controls.Add(Me.ButtonModeTest3)
        Me.GroupBoxRobotMode.Controls.Add(Me.LabelMain)
        Me.GroupBoxRobotMode.Controls.Add(Me.ButtonModeTest1)
        Me.GroupBoxRobotMode.Controls.Add(Me.ButtonModeTest2)
        Me.GroupBoxRobotMode.Controls.Add(Me.ButtonModeNormal)
        Me.GroupBoxRobotMode.Location = New System.Drawing.Point(12, 115)
        Me.GroupBoxRobotMode.Name = "GroupBoxRobotMode"
        Me.GroupBoxRobotMode.Size = New System.Drawing.Size(143, 84)
        Me.GroupBoxRobotMode.TabIndex = 63
        Me.GroupBoxRobotMode.TabStop = False
        Me.GroupBoxRobotMode.Text = "Robot Mode"
        '
        'LabelGPFlag13
        '
        Me.LabelGPFlag13.BackColor = System.Drawing.Color.Aqua
        Me.LabelGPFlag13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelGPFlag13.Location = New System.Drawing.Point(54, 15)
        Me.LabelGPFlag13.Name = "LabelGPFlag13"
        Me.LabelGPFlag13.Size = New System.Drawing.Size(22, 22)
        Me.LabelGPFlag13.TabIndex = 69
        Me.LabelGPFlag13.Text = "   "
        '
        'Trace1GroupBox
        '
        Me.Trace1GroupBox.Controls.Add(Me.Trace1RadioButton12)
        Me.Trace1GroupBox.Controls.Add(Me.Trace1RadioButton11)
        Me.Trace1GroupBox.Controls.Add(Me.Trace1RadioButton10)
        Me.Trace1GroupBox.Controls.Add(Me.Trace1RadioButton9)
        Me.Trace1GroupBox.Controls.Add(Me.Trace1RadioButton8)
        Me.Trace1GroupBox.Controls.Add(Me.Trace1RadioButton7)
        Me.Trace1GroupBox.Controls.Add(Me.Trace1RadioButton6)
        Me.Trace1GroupBox.Controls.Add(Me.Trace1RadioButton5)
        Me.Trace1GroupBox.Controls.Add(Me.Trace1RadioButton4)
        Me.Trace1GroupBox.Controls.Add(Me.Trace1RadioButton3)
        Me.Trace1GroupBox.Controls.Add(Me.Trace1RadioButton2)
        Me.Trace1GroupBox.Controls.Add(Me.Trace1RadioButton1)
        Me.Trace1GroupBox.Location = New System.Drawing.Point(285, 134)
        Me.Trace1GroupBox.Name = "Trace1GroupBox"
        Me.Trace1GroupBox.Size = New System.Drawing.Size(115, 230)
        Me.Trace1GroupBox.TabIndex = 80
        Me.Trace1GroupBox.TabStop = False
        Me.Trace1GroupBox.Text = "Trace1 Assignment"
        Me.ToolTip1.SetToolTip(Me.Trace1GroupBox, "Select the type of data to for Trace 1")
        '
        'Trace1RadioButton12
        '
        Me.Trace1RadioButton12.AutoSize = True
        Me.Trace1RadioButton12.Location = New System.Drawing.Point(6, 210)
        Me.Trace1RadioButton12.Name = "Trace1RadioButton12"
        Me.Trace1RadioButton12.Size = New System.Drawing.Size(84, 17)
        Me.Trace1RadioButton12.TabIndex = 90
        Me.Trace1RadioButton12.Text = "Set Heading"
        Me.Trace1RadioButton12.UseVisualStyleBackColor = True
        '
        'Trace1RadioButton11
        '
        Me.Trace1RadioButton11.AutoSize = True
        Me.Trace1RadioButton11.Location = New System.Drawing.Point(6, 193)
        Me.Trace1RadioButton11.Name = "Trace1RadioButton11"
        Me.Trace1RadioButton11.Size = New System.Drawing.Size(94, 17)
        Me.Trace1RadioButton11.TabIndex = 89
        Me.Trace1RadioButton11.Text = "Set Average X"
        Me.Trace1RadioButton11.UseVisualStyleBackColor = True
        '
        'Trace1RadioButton10
        '
        Me.Trace1RadioButton10.AutoSize = True
        Me.Trace1RadioButton10.Location = New System.Drawing.Point(6, 177)
        Me.Trace1RadioButton10.Name = "Trace1RadioButton10"
        Me.Trace1RadioButton10.Size = New System.Drawing.Size(94, 17)
        Me.Trace1RadioButton10.TabIndex = 88
        Me.Trace1RadioButton10.Text = "Set Average V"
        Me.Trace1RadioButton10.UseVisualStyleBackColor = True
        '
        'Trace1RadioButton9
        '
        Me.Trace1RadioButton9.AutoSize = True
        Me.Trace1RadioButton9.Location = New System.Drawing.Point(6, 161)
        Me.Trace1RadioButton9.Name = "Trace1RadioButton9"
        Me.Trace1RadioButton9.Size = New System.Drawing.Size(88, 17)
        Me.Trace1RadioButton9.TabIndex = 87
        Me.Trace1RadioButton9.Text = "Set Tilt Angle"
        Me.Trace1RadioButton9.UseVisualStyleBackColor = True
        '
        'Trace1RadioButton8
        '
        Me.Trace1RadioButton8.AutoSize = True
        Me.Trace1RadioButton8.Location = New System.Drawing.Point(6, 143)
        Me.Trace1RadioButton8.Name = "Trace1RadioButton8"
        Me.Trace1RadioButton8.Size = New System.Drawing.Size(65, 17)
        Me.Trace1RadioButton8.TabIndex = 86
        Me.Trace1RadioButton8.Text = "Heading"
        Me.Trace1RadioButton8.UseVisualStyleBackColor = True
        '
        'Trace1RadioButton7
        '
        Me.Trace1RadioButton7.AutoSize = True
        Me.Trace1RadioButton7.Location = New System.Drawing.Point(6, 126)
        Me.Trace1RadioButton7.Name = "Trace1RadioButton7"
        Me.Trace1RadioButton7.Size = New System.Drawing.Size(109, 17)
        Me.Trace1RadioButton7.TabIndex = 85
        Me.Trace1RadioButton7.Text = "Average Wheel X"
        Me.Trace1RadioButton7.UseVisualStyleBackColor = True
        '
        'Trace1RadioButton6
        '
        Me.Trace1RadioButton6.AutoSize = True
        Me.Trace1RadioButton6.Location = New System.Drawing.Point(6, 109)
        Me.Trace1RadioButton6.Name = "Trace1RadioButton6"
        Me.Trace1RadioButton6.Size = New System.Drawing.Size(87, 17)
        Me.Trace1RadioButton6.TabIndex = 83
        Me.Trace1RadioButton6.Text = "Left Wheel X"
        Me.Trace1RadioButton6.UseVisualStyleBackColor = True
        '
        'Trace1RadioButton5
        '
        Me.Trace1RadioButton5.AutoSize = True
        Me.Trace1RadioButton5.Location = New System.Drawing.Point(6, 91)
        Me.Trace1RadioButton5.Name = "Trace1RadioButton5"
        Me.Trace1RadioButton5.Size = New System.Drawing.Size(94, 17)
        Me.Trace1RadioButton5.TabIndex = 82
        Me.Trace1RadioButton5.Text = "Right Wheel X"
        Me.Trace1RadioButton5.UseVisualStyleBackColor = True
        '
        'Trace1RadioButton4
        '
        Me.Trace1RadioButton4.AutoSize = True
        Me.Trace1RadioButton4.Location = New System.Drawing.Point(6, 72)
        Me.Trace1RadioButton4.Name = "Trace1RadioButton4"
        Me.Trace1RadioButton4.Size = New System.Drawing.Size(109, 17)
        Me.Trace1RadioButton4.TabIndex = 81
        Me.Trace1RadioButton4.Text = "Average Wheel V"
        Me.Trace1RadioButton4.UseVisualStyleBackColor = True
        '
        'Trace1RadioButton3
        '
        Me.Trace1RadioButton3.AutoSize = True
        Me.Trace1RadioButton3.Location = New System.Drawing.Point(6, 55)
        Me.Trace1RadioButton3.Name = "Trace1RadioButton3"
        Me.Trace1RadioButton3.Size = New System.Drawing.Size(87, 17)
        Me.Trace1RadioButton3.TabIndex = 80
        Me.Trace1RadioButton3.Text = "Left Wheel V"
        Me.Trace1RadioButton3.UseVisualStyleBackColor = True
        '
        'Trace1RadioButton2
        '
        Me.Trace1RadioButton2.AutoSize = True
        Me.Trace1RadioButton2.Location = New System.Drawing.Point(6, 37)
        Me.Trace1RadioButton2.Name = "Trace1RadioButton2"
        Me.Trace1RadioButton2.Size = New System.Drawing.Size(94, 17)
        Me.Trace1RadioButton2.TabIndex = 79
        Me.Trace1RadioButton2.Text = "Right Wheel V"
        Me.Trace1RadioButton2.UseVisualStyleBackColor = True
        '
        'Trace1RadioButton1
        '
        Me.Trace1RadioButton1.AutoSize = True
        Me.Trace1RadioButton1.Checked = True
        Me.Trace1RadioButton1.Location = New System.Drawing.Point(6, 19)
        Me.Trace1RadioButton1.Name = "Trace1RadioButton1"
        Me.Trace1RadioButton1.Size = New System.Drawing.Size(69, 17)
        Me.Trace1RadioButton1.TabIndex = 78
        Me.Trace1RadioButton1.TabStop = True
        Me.Trace1RadioButton1.Text = "Tilt Angle"
        Me.Trace1RadioButton1.UseVisualStyleBackColor = True
        '
        'Trace2GroupBox
        '
        Me.Trace2GroupBox.Controls.Add(Me.Trace2RadioButton9)
        Me.Trace2GroupBox.Controls.Add(Me.Trace2RadioButton8)
        Me.Trace2GroupBox.Controls.Add(Me.Trace2RadioButton7)
        Me.Trace2GroupBox.Controls.Add(Me.Trace2RadioButton6)
        Me.Trace2GroupBox.Controls.Add(Me.Trace2RadioButton5)
        Me.Trace2GroupBox.Controls.Add(Me.Trace2RadioButton4)
        Me.Trace2GroupBox.Controls.Add(Me.Trace2RadioButton3)
        Me.Trace2GroupBox.Controls.Add(Me.Trace2RadioButton2)
        Me.Trace2GroupBox.Controls.Add(Me.Trace2RadioButton1)
        Me.Trace2GroupBox.Location = New System.Drawing.Point(407, 134)
        Me.Trace2GroupBox.Name = "Trace2GroupBox"
        Me.Trace2GroupBox.Size = New System.Drawing.Size(118, 182)
        Me.Trace2GroupBox.TabIndex = 81
        Me.Trace2GroupBox.TabStop = False
        Me.Trace2GroupBox.Text = "Trace2 Assignment"
        Me.ToolTip1.SetToolTip(Me.Trace2GroupBox, "Select the type of data for Trace 2")
        '
        'Trace2RadioButton9
        '
        Me.Trace2RadioButton9.AutoSize = True
        Me.Trace2RadioButton9.Location = New System.Drawing.Point(6, 160)
        Me.Trace2RadioButton9.Name = "Trace2RadioButton9"
        Me.Trace2RadioButton9.Size = New System.Drawing.Size(51, 17)
        Me.Trace2RadioButton9.TabIndex = 87
        Me.Trace2RadioButton9.Text = "None"
        Me.Trace2RadioButton9.UseVisualStyleBackColor = True
        '
        'Trace2RadioButton8
        '
        Me.Trace2RadioButton8.AutoSize = True
        Me.Trace2RadioButton8.Location = New System.Drawing.Point(6, 143)
        Me.Trace2RadioButton8.Name = "Trace2RadioButton8"
        Me.Trace2RadioButton8.Size = New System.Drawing.Size(65, 17)
        Me.Trace2RadioButton8.TabIndex = 86
        Me.Trace2RadioButton8.Text = "Heading"
        Me.Trace2RadioButton8.UseVisualStyleBackColor = True
        '
        'Trace2RadioButton7
        '
        Me.Trace2RadioButton7.AutoSize = True
        Me.Trace2RadioButton7.Location = New System.Drawing.Point(6, 126)
        Me.Trace2RadioButton7.Name = "Trace2RadioButton7"
        Me.Trace2RadioButton7.Size = New System.Drawing.Size(109, 17)
        Me.Trace2RadioButton7.TabIndex = 85
        Me.Trace2RadioButton7.Text = "Average Wheel X"
        Me.Trace2RadioButton7.UseVisualStyleBackColor = True
        '
        'Trace2RadioButton6
        '
        Me.Trace2RadioButton6.AutoSize = True
        Me.Trace2RadioButton6.Location = New System.Drawing.Point(6, 109)
        Me.Trace2RadioButton6.Name = "Trace2RadioButton6"
        Me.Trace2RadioButton6.Size = New System.Drawing.Size(87, 17)
        Me.Trace2RadioButton6.TabIndex = 83
        Me.Trace2RadioButton6.Text = "Left Wheel X"
        Me.Trace2RadioButton6.UseVisualStyleBackColor = True
        '
        'Trace2RadioButton5
        '
        Me.Trace2RadioButton5.AutoSize = True
        Me.Trace2RadioButton5.Location = New System.Drawing.Point(6, 91)
        Me.Trace2RadioButton5.Name = "Trace2RadioButton5"
        Me.Trace2RadioButton5.Size = New System.Drawing.Size(94, 17)
        Me.Trace2RadioButton5.TabIndex = 82
        Me.Trace2RadioButton5.Text = "Right Wheel X"
        Me.Trace2RadioButton5.UseVisualStyleBackColor = True
        '
        'Trace2RadioButton4
        '
        Me.Trace2RadioButton4.AutoSize = True
        Me.Trace2RadioButton4.Checked = True
        Me.Trace2RadioButton4.Location = New System.Drawing.Point(6, 72)
        Me.Trace2RadioButton4.Name = "Trace2RadioButton4"
        Me.Trace2RadioButton4.Size = New System.Drawing.Size(109, 17)
        Me.Trace2RadioButton4.TabIndex = 81
        Me.Trace2RadioButton4.TabStop = True
        Me.Trace2RadioButton4.Text = "Average Wheel V"
        Me.Trace2RadioButton4.UseVisualStyleBackColor = True
        '
        'Trace2RadioButton3
        '
        Me.Trace2RadioButton3.AutoSize = True
        Me.Trace2RadioButton3.Location = New System.Drawing.Point(6, 55)
        Me.Trace2RadioButton3.Name = "Trace2RadioButton3"
        Me.Trace2RadioButton3.Size = New System.Drawing.Size(87, 17)
        Me.Trace2RadioButton3.TabIndex = 80
        Me.Trace2RadioButton3.Text = "Left Wheel V"
        Me.Trace2RadioButton3.UseVisualStyleBackColor = True
        '
        'Trace2RadioButton2
        '
        Me.Trace2RadioButton2.AutoSize = True
        Me.Trace2RadioButton2.Location = New System.Drawing.Point(6, 37)
        Me.Trace2RadioButton2.Name = "Trace2RadioButton2"
        Me.Trace2RadioButton2.Size = New System.Drawing.Size(94, 17)
        Me.Trace2RadioButton2.TabIndex = 79
        Me.Trace2RadioButton2.Text = "Right Wheel V"
        Me.Trace2RadioButton2.UseVisualStyleBackColor = True
        '
        'Trace2RadioButton1
        '
        Me.Trace2RadioButton1.AutoSize = True
        Me.Trace2RadioButton1.Location = New System.Drawing.Point(6, 19)
        Me.Trace2RadioButton1.Name = "Trace2RadioButton1"
        Me.Trace2RadioButton1.Size = New System.Drawing.Size(69, 17)
        Me.Trace2RadioButton1.TabIndex = 78
        Me.Trace2RadioButton1.Text = "Tilt Angle"
        Me.Trace2RadioButton1.UseVisualStyleBackColor = True
        '
        'Trace3GroupBox
        '
        Me.Trace3GroupBox.Controls.Add(Me.Trace3RadioButton4)
        Me.Trace3GroupBox.Controls.Add(Me.Trace3RadioButton5)
        Me.Trace3GroupBox.Controls.Add(Me.Trace3RadioButton3)
        Me.Trace3GroupBox.Controls.Add(Me.Trace3RadioButton2)
        Me.Trace3GroupBox.Controls.Add(Me.Trace3RadioButton1)
        Me.Trace3GroupBox.Location = New System.Drawing.Point(531, 138)
        Me.Trace3GroupBox.Name = "Trace3GroupBox"
        Me.Trace3GroupBox.Size = New System.Drawing.Size(120, 111)
        Me.Trace3GroupBox.TabIndex = 82
        Me.Trace3GroupBox.TabStop = False
        Me.Trace3GroupBox.Text = "Trace3 Assignment"
        Me.ToolTip1.SetToolTip(Me.Trace3GroupBox, "Select the type of data for Trace 3")
        '
        'Trace3RadioButton4
        '
        Me.Trace3RadioButton4.AutoSize = True
        Me.Trace3RadioButton4.Location = New System.Drawing.Point(7, 69)
        Me.Trace3RadioButton4.Name = "Trace3RadioButton4"
        Me.Trace3RadioButton4.Size = New System.Drawing.Size(126, 17)
        Me.Trace3RadioButton4.TabIndex = 88
        Me.Trace3RadioButton4.Text = "Tilt Angle from Wheel"
        Me.Trace3RadioButton4.UseVisualStyleBackColor = True
        '
        'Trace3RadioButton5
        '
        Me.Trace3RadioButton5.AutoSize = True
        Me.Trace3RadioButton5.Location = New System.Drawing.Point(8, 87)
        Me.Trace3RadioButton5.Name = "Trace3RadioButton5"
        Me.Trace3RadioButton5.Size = New System.Drawing.Size(51, 17)
        Me.Trace3RadioButton5.TabIndex = 87
        Me.Trace3RadioButton5.Text = "None"
        Me.Trace3RadioButton5.UseVisualStyleBackColor = True
        '
        'Trace3RadioButton3
        '
        Me.Trace3RadioButton3.AutoSize = True
        Me.Trace3RadioButton3.Location = New System.Drawing.Point(8, 52)
        Me.Trace3RadioButton3.Name = "Trace3RadioButton3"
        Me.Trace3RadioButton3.Size = New System.Drawing.Size(65, 17)
        Me.Trace3RadioButton3.TabIndex = 86
        Me.Trace3RadioButton3.Text = "Heading"
        Me.Trace3RadioButton3.UseVisualStyleBackColor = True
        '
        'Trace3RadioButton2
        '
        Me.Trace3RadioButton2.AutoSize = True
        Me.Trace3RadioButton2.Checked = True
        Me.Trace3RadioButton2.Location = New System.Drawing.Point(7, 35)
        Me.Trace3RadioButton2.Name = "Trace3RadioButton2"
        Me.Trace3RadioButton2.Size = New System.Drawing.Size(109, 17)
        Me.Trace3RadioButton2.TabIndex = 85
        Me.Trace3RadioButton2.TabStop = True
        Me.Trace3RadioButton2.Text = "Average Wheel X"
        Me.Trace3RadioButton2.UseVisualStyleBackColor = True
        '
        'Trace3RadioButton1
        '
        Me.Trace3RadioButton1.AutoSize = True
        Me.Trace3RadioButton1.Location = New System.Drawing.Point(7, 19)
        Me.Trace3RadioButton1.Name = "Trace3RadioButton1"
        Me.Trace3RadioButton1.Size = New System.Drawing.Size(109, 17)
        Me.Trace3RadioButton1.TabIndex = 83
        Me.Trace3RadioButton1.Text = "Average Wheel V"
        Me.Trace3RadioButton1.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(164, 492)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(119, 13)
        Me.Label11.TabIndex = 89
        Me.Label11.Text = "Degree Per Wheel Tick"
        '
        'GroupBoxAction
        '
        Me.GroupBoxAction.Controls.Add(Me.ButtonForwardSlow)
        Me.GroupBoxAction.Controls.Add(Me.ButtonTest)
        Me.GroupBoxAction.Controls.Add(Me.ButtonTurnRightCont)
        Me.GroupBoxAction.Controls.Add(Me.ButtonTurnLeftCont)
        Me.GroupBoxAction.Controls.Add(Me.ButtonForwardNormal)
        Me.GroupBoxAction.Controls.Add(Me.ButtonStop)
        Me.GroupBoxAction.Controls.Add(Me.ButtonManualAuto)
        Me.GroupBoxAction.Controls.Add(Me.ButtonTurnRight)
        Me.GroupBoxAction.Controls.Add(Me.ButtonTurnLeft)
        Me.GroupBoxAction.Controls.Add(Me.ButtonForwardFast)
        Me.GroupBoxAction.Controls.Add(Me.ButtonBackward)
        Me.GroupBoxAction.Location = New System.Drawing.Point(187, 3)
        Me.GroupBoxAction.Name = "GroupBoxAction"
        Me.GroupBoxAction.Size = New System.Drawing.Size(460, 108)
        Me.GroupBoxAction.TabIndex = 83
        Me.GroupBoxAction.TabStop = False
        Me.GroupBoxAction.Text = "Actions"
        '
        'ButtonForwardSlow
        '
        Me.ButtonForwardSlow.Location = New System.Drawing.Point(194, 56)
        Me.ButtonForwardSlow.Name = "ButtonForwardSlow"
        Me.ButtonForwardSlow.Size = New System.Drawing.Size(73, 47)
        Me.ButtonForwardSlow.TabIndex = 70
        Me.ButtonForwardSlow.Text = "Forward Slow"
        Me.ButtonForwardSlow.UseVisualStyleBackColor = True
        '
        'ButtonTest
        '
        Me.ButtonTest.Location = New System.Drawing.Point(309, 57)
        Me.ButtonTest.Name = "ButtonTest"
        Me.ButtonTest.Size = New System.Drawing.Size(83, 44)
        Me.ButtonTest.TabIndex = 69
        Me.ButtonTest.Text = "Test"
        Me.ButtonTest.UseVisualStyleBackColor = True
        '
        'ButtonTurnRightCont
        '
        Me.ButtonTurnRightCont.Location = New System.Drawing.Point(398, 58)
        Me.ButtonTurnRightCont.Name = "ButtonTurnRightCont"
        Me.ButtonTurnRightCont.Size = New System.Drawing.Size(56, 42)
        Me.ButtonTurnRightCont.TabIndex = 68
        Me.ButtonTurnRightCont.Text = "Cont. Right"
        Me.ButtonTurnRightCont.UseVisualStyleBackColor = True
        '
        'ButtonTurnLeftCont
        '
        Me.ButtonTurnLeftCont.Location = New System.Drawing.Point(398, 13)
        Me.ButtonTurnLeftCont.Name = "ButtonTurnLeftCont"
        Me.ButtonTurnLeftCont.Size = New System.Drawing.Size(56, 42)
        Me.ButtonTurnLeftCont.TabIndex = 67
        Me.ButtonTurnLeftCont.Text = "Cont. Left"
        Me.ButtonTurnLeftCont.UseVisualStyleBackColor = True
        '
        'ButtonForwardNormal
        '
        Me.ButtonForwardNormal.Location = New System.Drawing.Point(6, 56)
        Me.ButtonForwardNormal.Name = "ButtonForwardNormal"
        Me.ButtonForwardNormal.Size = New System.Drawing.Size(55, 44)
        Me.ButtonForwardNormal.TabIndex = 66
        Me.ButtonForwardNormal.Text = "Forward Normal"
        Me.ButtonForwardNormal.UseVisualStyleBackColor = True
        '
        'ButtonStop
        '
        Me.ButtonStop.Location = New System.Drawing.Point(68, 58)
        Me.ButtonStop.Name = "ButtonStop"
        Me.ButtonStop.Size = New System.Drawing.Size(120, 45)
        Me.ButtonStop.TabIndex = 64
        Me.ButtonStop.Text = "&Stop"
        Me.ButtonStop.UseVisualStyleBackColor = True
        '
        'ButtonManualAuto
        '
        Me.ButtonManualAuto.Location = New System.Drawing.Point(309, 13)
        Me.ButtonManualAuto.Name = "ButtonManualAuto"
        Me.ButtonManualAuto.Size = New System.Drawing.Size(83, 41)
        Me.ButtonManualAuto.TabIndex = 63
        Me.ButtonManualAuto.Text = "Manual/Auto"
        Me.ToolTip1.SetToolTip(Me.ButtonManualAuto, "Switch between Manual and Autonomous modes")
        Me.ButtonManualAuto.UseVisualStyleBackColor = True
        '
        'ButtonTurnRight
        '
        Me.ButtonTurnRight.Location = New System.Drawing.Point(131, 13)
        Me.ButtonTurnRight.Name = "ButtonTurnRight"
        Me.ButtonTurnRight.Size = New System.Drawing.Size(57, 39)
        Me.ButtonTurnRight.TabIndex = 56
        Me.ButtonTurnRight.Text = "Turn Right"
        Me.ButtonTurnRight.UseVisualStyleBackColor = True
        '
        'ButtonTurnLeft
        '
        Me.ButtonTurnLeft.Location = New System.Drawing.Point(68, 12)
        Me.ButtonTurnLeft.Name = "ButtonTurnLeft"
        Me.ButtonTurnLeft.Size = New System.Drawing.Size(57, 39)
        Me.ButtonTurnLeft.TabIndex = 55
        Me.ButtonTurnLeft.Text = "Turn Left"
        Me.ButtonTurnLeft.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(304, 115)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(221, 16)
        Me.Label2.TabIndex = 84
        Me.Label2.Text = "Trace Assignment for XY Plot 1"
        '
        'Trace4GroupBox
        '
        Me.Trace4GroupBox.Controls.Add(Me.Trace4RadioButton4)
        Me.Trace4GroupBox.Controls.Add(Me.Trace4RadioButton5)
        Me.Trace4GroupBox.Controls.Add(Me.Trace4RadioButton3)
        Me.Trace4GroupBox.Controls.Add(Me.Trace4RadioButton2)
        Me.Trace4GroupBox.Controls.Add(Me.Trace4RadioButton1)
        Me.Trace4GroupBox.Location = New System.Drawing.Point(531, 251)
        Me.Trace4GroupBox.Name = "Trace4GroupBox"
        Me.Trace4GroupBox.Size = New System.Drawing.Size(120, 104)
        Me.Trace4GroupBox.TabIndex = 89
        Me.Trace4GroupBox.TabStop = False
        Me.Trace4GroupBox.Text = "Trace 4 Assignment"
        Me.ToolTip1.SetToolTip(Me.Trace4GroupBox, "Select the type of data for Trace 3")
        '
        'Trace4RadioButton4
        '
        Me.Trace4RadioButton4.AutoSize = True
        Me.Trace4RadioButton4.Location = New System.Drawing.Point(7, 69)
        Me.Trace4RadioButton4.Name = "Trace4RadioButton4"
        Me.Trace4RadioButton4.Size = New System.Drawing.Size(84, 17)
        Me.Trace4RadioButton4.TabIndex = 88
        Me.Trace4RadioButton4.Text = "Set Heading"
        Me.Trace4RadioButton4.UseVisualStyleBackColor = True
        '
        'Trace4RadioButton5
        '
        Me.Trace4RadioButton5.AutoSize = True
        Me.Trace4RadioButton5.Checked = True
        Me.Trace4RadioButton5.Location = New System.Drawing.Point(8, 87)
        Me.Trace4RadioButton5.Name = "Trace4RadioButton5"
        Me.Trace4RadioButton5.Size = New System.Drawing.Size(51, 17)
        Me.Trace4RadioButton5.TabIndex = 87
        Me.Trace4RadioButton5.TabStop = True
        Me.Trace4RadioButton5.Text = "None"
        Me.Trace4RadioButton5.UseVisualStyleBackColor = True
        '
        'Trace4RadioButton3
        '
        Me.Trace4RadioButton3.AutoSize = True
        Me.Trace4RadioButton3.Location = New System.Drawing.Point(8, 52)
        Me.Trace4RadioButton3.Name = "Trace4RadioButton3"
        Me.Trace4RadioButton3.Size = New System.Drawing.Size(94, 17)
        Me.Trace4RadioButton3.TabIndex = 86
        Me.Trace4RadioButton3.Text = "Set Average X"
        Me.Trace4RadioButton3.UseVisualStyleBackColor = True
        '
        'Trace4RadioButton2
        '
        Me.Trace4RadioButton2.AutoSize = True
        Me.Trace4RadioButton2.Location = New System.Drawing.Point(7, 35)
        Me.Trace4RadioButton2.Name = "Trace4RadioButton2"
        Me.Trace4RadioButton2.Size = New System.Drawing.Size(94, 17)
        Me.Trace4RadioButton2.TabIndex = 85
        Me.Trace4RadioButton2.Text = "Set Average V"
        Me.Trace4RadioButton2.UseVisualStyleBackColor = True
        '
        'Trace4RadioButton1
        '
        Me.Trace4RadioButton1.AutoSize = True
        Me.Trace4RadioButton1.Location = New System.Drawing.Point(7, 19)
        Me.Trace4RadioButton1.Name = "Trace4RadioButton1"
        Me.Trace4RadioButton1.Size = New System.Drawing.Size(88, 17)
        Me.Trace4RadioButton1.TabIndex = 83
        Me.Trace4RadioButton1.Text = "Set Tilt Angle"
        Me.Trace4RadioButton1.UseVisualStyleBackColor = True
        '
        'TurnAnglePerUnitLabel
        '
        Me.TurnAnglePerUnitLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TurnAnglePerUnitLabel.Location = New System.Drawing.Point(103, 488)
        Me.TurnAnglePerUnitLabel.Name = "TurnAnglePerUnitLabel"
        Me.TurnAnglePerUnitLabel.Size = New System.Drawing.Size(44, 22)
        Me.TurnAnglePerUnitLabel.TabIndex = 85
        '
        'DegPerWheelTickLabel
        '
        Me.DegPerWheelTickLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DegPerWheelTickLabel.Location = New System.Drawing.Point(288, 492)
        Me.DegPerWheelTickLabel.Name = "DegPerWheelTickLabel"
        Me.DegPerWheelTickLabel.Size = New System.Drawing.Size(39, 20)
        Me.DegPerWheelTickLabel.TabIndex = 90
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(-2, 489)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(100, 13)
        Me.Label12.TabIndex = 91
        Me.Label12.Text = "Turn Angle Per Unit"
        '
        'Data4Label
        '
        Me.Data4Label.AutoSize = True
        Me.Data4Label.Location = New System.Drawing.Point(360, 482)
        Me.Data4Label.Name = "Data4Label"
        Me.Data4Label.Size = New System.Drawing.Size(95, 13)
        Me.Data4Label.TabIndex = 93
        Me.Data4Label.Text = "Param 4 Received"
        '
        'LabelData4
        '
        Me.LabelData4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelData4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelData4.Location = New System.Drawing.Point(461, 482)
        Me.LabelData4.Name = "LabelData4"
        Me.LabelData4.Size = New System.Drawing.Size(43, 20)
        Me.LabelData4.TabIndex = 94
        '
        'LabelData8
        '
        Me.LabelData8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelData8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelData8.Location = New System.Drawing.Point(602, 486)
        Me.LabelData8.Name = "LabelData8"
        Me.LabelData8.Size = New System.Drawing.Size(48, 24)
        Me.LabelData8.TabIndex = 95
        '
        'Data8Label
        '
        Me.Data8Label.AutoSize = True
        Me.Data8Label.Location = New System.Drawing.Point(514, 489)
        Me.Data8Label.Name = "Data8Label"
        Me.Data8Label.Size = New System.Drawing.Size(47, 13)
        Me.Data8Label.TabIndex = 96
        Me.Data8Label.Text = "VControl"
        '
        'P2Trace1CheckBox
        '
        Me.P2Trace1CheckBox.AutoSize = True
        Me.P2Trace1CheckBox.Checked = True
        Me.P2Trace1CheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.P2Trace1CheckBox.Location = New System.Drawing.Point(296, 387)
        Me.P2Trace1CheckBox.Name = "P2Trace1CheckBox"
        Me.P2Trace1CheckBox.Size = New System.Drawing.Size(93, 17)
        Me.P2Trace1CheckBox.TabIndex = 97
        Me.P2Trace1CheckBox.Text = "Show Trace 1"
        Me.P2Trace1CheckBox.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(307, 367)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(221, 16)
        Me.Label5.TabIndex = 98
        Me.Label5.Text = "Trace Assignment for XY Plot 2"
        '
        'P2Trace2CheckBox
        '
        Me.P2Trace2CheckBox.AutoSize = True
        Me.P2Trace2CheckBox.Checked = True
        Me.P2Trace2CheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.P2Trace2CheckBox.Location = New System.Drawing.Point(395, 388)
        Me.P2Trace2CheckBox.Name = "P2Trace2CheckBox"
        Me.P2Trace2CheckBox.Size = New System.Drawing.Size(93, 17)
        Me.P2Trace2CheckBox.TabIndex = 99
        Me.P2Trace2CheckBox.Text = "Show Trace 2"
        Me.P2Trace2CheckBox.UseVisualStyleBackColor = True
        '
        'P2Trace3CheckBox
        '
        Me.P2Trace3CheckBox.AutoSize = True
        Me.P2Trace3CheckBox.Checked = True
        Me.P2Trace3CheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.P2Trace3CheckBox.Location = New System.Drawing.Point(503, 388)
        Me.P2Trace3CheckBox.Name = "P2Trace3CheckBox"
        Me.P2Trace3CheckBox.Size = New System.Drawing.Size(93, 17)
        Me.P2Trace3CheckBox.TabIndex = 100
        Me.P2Trace3CheckBox.Text = "Show Trace 3"
        Me.P2Trace3CheckBox.UseVisualStyleBackColor = True
        '
        'LabelGPFlag11
        '
        Me.LabelGPFlag11.BackColor = System.Drawing.Color.Aqua
        Me.LabelGPFlag11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelGPFlag11.Location = New System.Drawing.Point(6, 15)
        Me.LabelGPFlag11.Name = "LabelGPFlag11"
        Me.LabelGPFlag11.Size = New System.Drawing.Size(22, 22)
        Me.LabelGPFlag11.TabIndex = 101
        Me.LabelGPFlag11.Text = "   "
        '
        'LabelGPFlag12
        '
        Me.LabelGPFlag12.BackColor = System.Drawing.Color.Aqua
        Me.LabelGPFlag12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelGPFlag12.Location = New System.Drawing.Point(30, 15)
        Me.LabelGPFlag12.Name = "LabelGPFlag12"
        Me.LabelGPFlag12.Size = New System.Drawing.Size(22, 22)
        Me.LabelGPFlag12.TabIndex = 102
        Me.LabelGPFlag12.Text = "   "
        '
        'LabelGPFlag14
        '
        Me.LabelGPFlag14.BackColor = System.Drawing.Color.Aqua
        Me.LabelGPFlag14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelGPFlag14.Location = New System.Drawing.Point(78, 15)
        Me.LabelGPFlag14.Name = "LabelGPFlag14"
        Me.LabelGPFlag14.Size = New System.Drawing.Size(22, 22)
        Me.LabelGPFlag14.TabIndex = 103
        Me.LabelGPFlag14.Text = "   "
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(293, 432)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(36, 13)
        Me.Label1.TabIndex = 53
        Me.Label1.Text = "Flag 1"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(288, 413)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(36, 13)
        Me.Label6.TabIndex = 104
        Me.Label6.Text = "Flag 2"
        '
        'GroupBoxGeneralFlag
        '
        Me.GroupBoxGeneralFlag.Controls.Add(Me.LabelGPFlag31)
        Me.GroupBoxGeneralFlag.Controls.Add(Me.LabelGPFlag32)
        Me.GroupBoxGeneralFlag.Controls.Add(Me.LabelGPFlag33)
        Me.GroupBoxGeneralFlag.Controls.Add(Me.LabelGPFlag34)
        Me.GroupBoxGeneralFlag.Controls.Add(Me.LabelGPFlag21)
        Me.GroupBoxGeneralFlag.Controls.Add(Me.LabelGPFlag22)
        Me.GroupBoxGeneralFlag.Controls.Add(Me.LabelGPFlag23)
        Me.GroupBoxGeneralFlag.Controls.Add(Me.LabelGPFlag24)
        Me.GroupBoxGeneralFlag.Controls.Add(Me.LabelGPFlag11)
        Me.GroupBoxGeneralFlag.Controls.Add(Me.LabelGPFlag12)
        Me.GroupBoxGeneralFlag.Controls.Add(Me.LabelGPFlag13)
        Me.GroupBoxGeneralFlag.Controls.Add(Me.LabelGPFlag14)
        Me.GroupBoxGeneralFlag.Location = New System.Drawing.Point(167, 117)
        Me.GroupBoxGeneralFlag.Name = "GroupBoxGeneralFlag"
        Me.GroupBoxGeneralFlag.Size = New System.Drawing.Size(110, 103)
        Me.GroupBoxGeneralFlag.TabIndex = 105
        Me.GroupBoxGeneralFlag.TabStop = False
        Me.GroupBoxGeneralFlag.Text = "General Flags"
        '
        'LabelGPFlag31
        '
        Me.LabelGPFlag31.BackColor = System.Drawing.Color.Aqua
        Me.LabelGPFlag31.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelGPFlag31.Location = New System.Drawing.Point(6, 68)
        Me.LabelGPFlag31.Name = "LabelGPFlag31"
        Me.LabelGPFlag31.Size = New System.Drawing.Size(22, 22)
        Me.LabelGPFlag31.TabIndex = 109
        Me.LabelGPFlag31.Text = "   "
        '
        'LabelGPFlag32
        '
        Me.LabelGPFlag32.BackColor = System.Drawing.Color.Aqua
        Me.LabelGPFlag32.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelGPFlag32.Location = New System.Drawing.Point(30, 68)
        Me.LabelGPFlag32.Name = "LabelGPFlag32"
        Me.LabelGPFlag32.Size = New System.Drawing.Size(22, 22)
        Me.LabelGPFlag32.TabIndex = 110
        Me.LabelGPFlag32.Text = "   "
        '
        'LabelGPFlag33
        '
        Me.LabelGPFlag33.BackColor = System.Drawing.Color.Aqua
        Me.LabelGPFlag33.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelGPFlag33.Location = New System.Drawing.Point(54, 68)
        Me.LabelGPFlag33.Name = "LabelGPFlag33"
        Me.LabelGPFlag33.Size = New System.Drawing.Size(22, 22)
        Me.LabelGPFlag33.TabIndex = 108
        Me.LabelGPFlag33.Text = "   "
        '
        'LabelGPFlag34
        '
        Me.LabelGPFlag34.BackColor = System.Drawing.Color.Aqua
        Me.LabelGPFlag34.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelGPFlag34.Location = New System.Drawing.Point(78, 68)
        Me.LabelGPFlag34.Name = "LabelGPFlag34"
        Me.LabelGPFlag34.Size = New System.Drawing.Size(22, 22)
        Me.LabelGPFlag34.TabIndex = 111
        Me.LabelGPFlag34.Text = "   "
        '
        'LabelGPFlag21
        '
        Me.LabelGPFlag21.BackColor = System.Drawing.Color.Aqua
        Me.LabelGPFlag21.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelGPFlag21.Location = New System.Drawing.Point(6, 42)
        Me.LabelGPFlag21.Name = "LabelGPFlag21"
        Me.LabelGPFlag21.Size = New System.Drawing.Size(22, 22)
        Me.LabelGPFlag21.TabIndex = 105
        Me.LabelGPFlag21.Text = "   "
        '
        'LabelGPFlag22
        '
        Me.LabelGPFlag22.BackColor = System.Drawing.Color.Aqua
        Me.LabelGPFlag22.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelGPFlag22.Location = New System.Drawing.Point(30, 42)
        Me.LabelGPFlag22.Name = "LabelGPFlag22"
        Me.LabelGPFlag22.Size = New System.Drawing.Size(22, 22)
        Me.LabelGPFlag22.TabIndex = 106
        Me.LabelGPFlag22.Text = "   "
        '
        'LabelGPFlag23
        '
        Me.LabelGPFlag23.BackColor = System.Drawing.Color.Aqua
        Me.LabelGPFlag23.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelGPFlag23.Location = New System.Drawing.Point(54, 42)
        Me.LabelGPFlag23.Name = "LabelGPFlag23"
        Me.LabelGPFlag23.Size = New System.Drawing.Size(22, 22)
        Me.LabelGPFlag23.TabIndex = 104
        Me.LabelGPFlag23.Text = "   "
        '
        'LabelGPFlag24
        '
        Me.LabelGPFlag24.BackColor = System.Drawing.Color.Aqua
        Me.LabelGPFlag24.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelGPFlag24.Location = New System.Drawing.Point(78, 42)
        Me.LabelGPFlag24.Name = "LabelGPFlag24"
        Me.LabelGPFlag24.Size = New System.Drawing.Size(22, 22)
        Me.LabelGPFlag24.TabIndex = 107
        Me.LabelGPFlag24.Text = "   "
        '
        'ButtonSelectParam
        '
        Me.ButtonSelectParam.Location = New System.Drawing.Point(566, 361)
        Me.ButtonSelectParam.Name = "ButtonSelectParam"
        Me.ButtonSelectParam.Size = New System.Drawing.Size(75, 28)
        Me.ButtonSelectParam.TabIndex = 106
        Me.ButtonSelectParam.Text = "Parameter"
        Me.ButtonSelectParam.UseVisualStyleBackColor = True
        '
        'ButtonModeTest3
        '
        Me.ButtonModeTest3.Location = New System.Drawing.Point(12, 47)
        Me.ButtonModeTest3.Name = "ButtonModeTest3"
        Me.ButtonModeTest3.Size = New System.Drawing.Size(59, 25)
        Me.ButtonModeTest3.TabIndex = 58
        Me.ButtonModeTest3.Text = "Test3"
        Me.ToolTip1.SetToolTip(Me.ButtonModeTest3, "Normal mode")
        Me.ButtonModeTest3.UseVisualStyleBackColor = True
        '
        'FormMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1116, 538)
        Me.Controls.Add(Me.ButtonSelectParam)
        Me.Controls.Add(Me.GroupBoxGeneralFlag)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.P2Trace3CheckBox)
        Me.Controls.Add(Me.P2Trace2CheckBox)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.P2Trace1CheckBox)
        Me.Controls.Add(Me.Data8Label)
        Me.Controls.Add(Me.LabelData8)
        Me.Controls.Add(Me.LabelData4)
        Me.Controls.Add(Me.Data4Label)
        Me.Controls.Add(Me.Trace4GroupBox)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.DegPerWheelTickLabel)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.TurnAnglePerUnitLabel)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.GroupBoxAction)
        Me.Controls.Add(Me.Trace3GroupBox)
        Me.Controls.Add(Me.Trace2GroupBox)
        Me.Controls.Add(Me.Trace1GroupBox)
        Me.Controls.Add(Me.GroupBoxRobotMode)
        Me.Controls.Add(Me.Data7Label)
        Me.Controls.Add(Me.Data6Label)
        Me.Controls.Add(Me.LabelData7)
        Me.Controls.Add(Me.LabelData6)
        Me.Controls.Add(Me.MainRichTextBox)
        Me.Controls.Add(Me.Data5Label)
        Me.Controls.Add(Me.Data3Label)
        Me.Controls.Add(Me.Data2Label)
        Me.Controls.Add(Me.Data1Label)
        Me.Controls.Add(Me.LabelData5)
        Me.Controls.Add(Me.LabelData3)
        Me.Controls.Add(Me.LabelData2)
        Me.Controls.Add(Me.LabelData1)
        Me.Controls.Add(Me.ButtonConnect)
        Me.Controls.Add(Me.GroupBoxCoefficients)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.ComboBoxComPort)
        Me.Controls.Add(Me.ButtonOpen)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FormMain"
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.GroupBoxCoefficients.ResumeLayout(False)
        Me.GroupBoxCoefficients.PerformLayout()
        CType(Me.TrackBarC10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBarC9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBarC8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBarC7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBarC6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBarC5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBarC4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBarC3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBarC2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBarC1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBoxRobotMode.ResumeLayout(False)
        Me.GroupBoxRobotMode.PerformLayout()
        Me.Trace1GroupBox.ResumeLayout(False)
        Me.Trace1GroupBox.PerformLayout()
        Me.Trace2GroupBox.ResumeLayout(False)
        Me.Trace2GroupBox.PerformLayout()
        Me.Trace3GroupBox.ResumeLayout(False)
        Me.Trace3GroupBox.PerformLayout()
        Me.GroupBoxAction.ResumeLayout(False)
        Me.Trace4GroupBox.ResumeLayout(False)
        Me.Trace4GroupBox.PerformLayout()
        Me.GroupBoxGeneralFlag.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents SerialPort1 As System.IO.Ports.SerialPort
    Friend WithEvents ButtonOpen As System.Windows.Forms.Button
    Friend WithEvents LabelMain As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents ComboBoxComPort As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents GroupBoxCoefficients As System.Windows.Forms.GroupBox
    Friend WithEvents ButtonConnect As System.Windows.Forms.Button
    Friend WithEvents LabelData1 As System.Windows.Forms.Label
    Friend WithEvents LabelData2 As System.Windows.Forms.Label
    Friend WithEvents LabelData3 As System.Windows.Forms.Label
    Friend WithEvents StatusStripLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents StatusStripLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ButtonC1Down As System.Windows.Forms.Button
    Friend WithEvents ButonC1Up As System.Windows.Forms.Button
    Friend WithEvents LabelC1Val As System.Windows.Forms.Label
    Friend WithEvents ButtonC3Down As System.Windows.Forms.Button
    Friend WithEvents ButtonC3Up As System.Windows.Forms.Button
    Friend WithEvents LabelC3Val As System.Windows.Forms.Label
    Friend WithEvents ButtonC2Down As System.Windows.Forms.Button
    Friend WithEvents ButtonC2Up As System.Windows.Forms.Button
    Friend WithEvents LabelC2Val As System.Windows.Forms.Label
    Friend WithEvents ButtonC4Down As System.Windows.Forms.Button
    Friend WithEvents ButtonC4Up As System.Windows.Forms.Button
    Friend WithEvents LabelC4Val As System.Windows.Forms.Label
    Friend WithEvents LabelC4 As System.Windows.Forms.Label
    Friend WithEvents LabelC3 As System.Windows.Forms.Label
    Friend WithEvents LabelC2 As System.Windows.Forms.Label
    Friend WithEvents LabelC1 As System.Windows.Forms.Label
    Friend WithEvents ButtonC5Down As System.Windows.Forms.Button
    Friend WithEvents ButtonC5Up As System.Windows.Forms.Button
    Friend WithEvents LabelC5Val As System.Windows.Forms.Label
    Friend WithEvents LabelC5 As System.Windows.Forms.Label
    Friend WithEvents ButtonC6Up As System.Windows.Forms.Button
    Friend WithEvents ButtonC6Down As System.Windows.Forms.Button
    Friend WithEvents LabelC6Val As System.Windows.Forms.Label
    Friend WithEvents LabelC6 As System.Windows.Forms.Label
    Friend WithEvents LabelC7Val As System.Windows.Forms.Label
    Friend WithEvents TrackBarC1 As System.Windows.Forms.TrackBar
    Friend WithEvents ButtonC7Down As System.Windows.Forms.Button
    Friend WithEvents LabelC7 As System.Windows.Forms.Label
    Friend WithEvents TrackBarC6 As System.Windows.Forms.TrackBar
    Friend WithEvents TrackBarC5 As System.Windows.Forms.TrackBar
    Friend WithEvents TrackBarC4 As System.Windows.Forms.TrackBar
    Friend WithEvents TrackBarC3 As System.Windows.Forms.TrackBar
    Friend WithEvents TrackBarC2 As System.Windows.Forms.TrackBar
    Friend WithEvents ButtonC7Up As System.Windows.Forms.Button
    Friend WithEvents TrackBarC7 As System.Windows.Forms.TrackBar
    Friend WithEvents LabelC8Val As System.Windows.Forms.Label
    Friend WithEvents LabelC8 As System.Windows.Forms.Label
    Friend WithEvents ButtonC8Up As System.Windows.Forms.Button
    Friend WithEvents TrackBarC8 As System.Windows.Forms.TrackBar
    Friend WithEvents ButtonC8Down As System.Windows.Forms.Button
    Friend WithEvents ButtonStore As System.Windows.Forms.Button
    Friend WithEvents LabelMotorSequence As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents LabelC9 As System.Windows.Forms.Label
    Friend WithEvents LabelC9Val As System.Windows.Forms.Label
    Friend WithEvents LabelC10 As System.Windows.Forms.Label
    Friend WithEvents LabelC10Val As System.Windows.Forms.Label
    Friend WithEvents TrackBarC10 As System.Windows.Forms.TrackBar
    Friend WithEvents TrackBarC9 As System.Windows.Forms.TrackBar
    Friend WithEvents ButtonC10Up As System.Windows.Forms.Button
    Friend WithEvents ButtonC9Up As System.Windows.Forms.Button
    Friend WithEvents ButtonC10Down As System.Windows.Forms.Button
    Friend WithEvents ButtonC9Down As System.Windows.Forms.Button
    Friend WithEvents ButtonPlay1 As System.Windows.Forms.Button
    Friend WithEvents ButtonPlay2 As System.Windows.Forms.Button
    Friend WithEvents ButtonPlay3 As System.Windows.Forms.Button
    Friend WithEvents LabelData5 As System.Windows.Forms.Label
    Friend WithEvents Data1Label As System.Windows.Forms.Label
    Friend WithEvents Data2Label As System.Windows.Forms.Label
    Friend WithEvents Data3Label As System.Windows.Forms.Label
    Friend WithEvents Data5Label As System.Windows.Forms.Label
    Friend WithEvents MainRichTextBox As System.Windows.Forms.RichTextBox
    Friend WithEvents ButtonForwardFast As System.Windows.Forms.Button
    Friend WithEvents ButtonBackward As System.Windows.Forms.Button
    Friend WithEvents ButtonModeNormal As System.Windows.Forms.Button
    Friend WithEvents ButtonModeTest1 As System.Windows.Forms.Button
    Friend WithEvents ButtonModeTest2 As System.Windows.Forms.Button
    Friend WithEvents LabelData6 As System.Windows.Forms.Label
    Friend WithEvents LabelData7 As System.Windows.Forms.Label
    Friend WithEvents Data6Label As System.Windows.Forms.Label
    Friend WithEvents Data7Label As System.Windows.Forms.Label
    Friend WithEvents GroupBoxRobotMode As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBoxRobotHead As PictureBox
    Friend WithEvents LabelGPFlag13 As Label
    Friend WithEvents Trace1GroupBox As GroupBox
    Friend WithEvents Trace1RadioButton3 As RadioButton
    Friend WithEvents Trace1RadioButton2 As RadioButton
    Friend WithEvents Trace1RadioButton1 As RadioButton
    Friend WithEvents Trace1RadioButton4 As RadioButton
    Friend WithEvents Trace1RadioButton7 As RadioButton
    Friend WithEvents Trace1RadioButton6 As RadioButton
    Friend WithEvents Trace1RadioButton5 As RadioButton
    Friend WithEvents Trace1RadioButton8 As RadioButton
    Friend WithEvents Trace1RadioButton12 As RadioButton
    Friend WithEvents Trace1RadioButton11 As RadioButton
    Friend WithEvents Trace1RadioButton10 As RadioButton
    Friend WithEvents Trace1RadioButton9 As RadioButton
    Friend WithEvents Trace2GroupBox As GroupBox
    Friend WithEvents Trace2RadioButton8 As RadioButton
    Friend WithEvents Trace2RadioButton7 As RadioButton
    Friend WithEvents Trace2RadioButton6 As RadioButton
    Friend WithEvents Trace2RadioButton5 As RadioButton
    Friend WithEvents Trace2RadioButton4 As RadioButton
    Friend WithEvents Trace2RadioButton3 As RadioButton
    Friend WithEvents Trace2RadioButton2 As RadioButton
    Friend WithEvents Trace2RadioButton1 As RadioButton
    Friend WithEvents Trace3GroupBox As GroupBox
    Friend WithEvents Trace3RadioButton3 As RadioButton
    Friend WithEvents Trace3RadioButton2 As RadioButton
    Friend WithEvents Trace3RadioButton1 As RadioButton
    Friend WithEvents Trace2RadioButton9 As RadioButton
    Friend WithEvents Trace3RadioButton5 As RadioButton
    Friend WithEvents GroupBoxAction As GroupBox
    Friend WithEvents ButtonStop As Button
    Friend WithEvents ButtonManualAuto As Button
    Friend WithEvents ButtonTurnRight As Button
    Friend WithEvents ButtonTurnLeft As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents ButtonForwardNormal As Button
    Friend WithEvents Trace3RadioButton4 As RadioButton
    Friend WithEvents Label11 As Label
    Friend WithEvents TurnAnglePerUnitLabel As Label
    Friend WithEvents DegPerWheelTickLabel As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents ButtonTurnRightCont As Button
    Friend WithEvents ButtonTurnLeftCont As Button
    Friend WithEvents ButtonTest As Button
    Friend WithEvents ButtonRestoreFactoryDefault As Button
    Friend WithEvents Trace4GroupBox As GroupBox
    Friend WithEvents Trace4RadioButton4 As RadioButton
    Friend WithEvents Trace4RadioButton5 As RadioButton
    Friend WithEvents Trace4RadioButton3 As RadioButton
    Friend WithEvents Trace4RadioButton2 As RadioButton
    Friend WithEvents Trace4RadioButton1 As RadioButton
    Friend WithEvents Data4Label As Label
    Friend WithEvents LabelData4 As Label
    Friend WithEvents LabelData8 As Label
    Friend WithEvents Data8Label As Label
    Friend WithEvents P2Trace1CheckBox As CheckBox
    Friend WithEvents Label5 As Label
    Friend WithEvents P2Trace2CheckBox As CheckBox
    Friend WithEvents P2Trace3CheckBox As CheckBox
    Friend WithEvents LabelGPFlag11 As Label
    Friend WithEvents LabelGPFlag12 As Label
    Friend WithEvents LabelGPFlag14 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents ButtonForwardSlow As Button
    Friend WithEvents GroupBoxGeneralFlag As GroupBox
    Friend WithEvents LabelGPFlag31 As Label
    Friend WithEvents LabelGPFlag32 As Label
    Friend WithEvents LabelGPFlag33 As Label
    Friend WithEvents LabelGPFlag34 As Label
    Friend WithEvents LabelGPFlag21 As Label
    Friend WithEvents LabelGPFlag22 As Label
    Friend WithEvents LabelGPFlag23 As Label
    Friend WithEvents LabelGPFlag24 As Label
    Friend WithEvents ButtonSelectParam As Button
    Friend WithEvents ButtonModeTest3 As Button
End Class
