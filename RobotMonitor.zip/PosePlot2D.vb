﻿Imports System.Math
'--- Class FormBitmap ---
'Author         : Fabian Kung
'Last Modified  : 27 Feb 2018
'Version        : 1.00
'Description    : This object is used to plot the 2D pose (e.g. orientation and location) of the robot
'                 on an XY plane or window.
' 
'Example of usage:
' Suppose we creat an instance of the class as follows:
' 
' Private mfrmLocation As New PosePlot2DForm
'
' We then initialize the object:
' mfrmLocation.mpointRobotLocation.X = 0
' mfrmLocation.mpointRobotLocation.Y = 0
' mfrmLocation.mdblScaleFactor = 0.1
' mfrmLocation.Show()
'
' As needed, we can update the display of pose as follows:
' mfrmLocation.mdblRobotOrientation = nOrientation
' mfrmLocation.mnChangeDistanceTick = nChangeInDistance
' mfrmLocation.Refresh()


Public Class PosePlot2DForm

    'Public fields
    Public mdblRobotOrientation As Double = 90      'Initial orientation in degree.  Angle measured with
    Public mnChangeDistanceTick As Integer = 0
    Public mpointRobotLocation As New Point(0, 0)   'Actual location (x,y) of robot in cm from the origins.
    Public mdblScaleFactor As Double = 0.125        'Scale factor.  The actual position is scaled by
    'mnScaleFactor before being plotted into a 2D window.  The allows a large area to be mapped to
    'a scale surface area on a 2D window, otherwise the current robot location may go beyond the
    'surface area of the 2D window.

    'Private fields
    Private mnPlotWidth_div2 As Integer             'Plot area width / 2
    Private mnPlotHeigth_div2 As Integer            'Plot area heigth / 2
    Private mpenMain As New Pen(Color.Red, 6)
    Private mnRobotSize As Integer = 28 'Length of robot is represented as 16 pixels.
    'Private mdblRobotOrientation As Double = 90 'Initial orientation in degree.  Angle measured with
    'respect to x-axis.

    Private Sub FormBitmap_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Setup the draw parameters and initial position/pose of robot.
        PictureBoxLocation.BackColor = Color.White
        mnPlotHeigth_div2 = PictureBoxLocation.Height / 2
        mnPlotWidth_div2 = PictureBoxLocation.Width / 2
    End Sub

    Private Sub PictureBoxLocation_Paint(sender As Object, e As PaintEventArgs) Handles PictureBoxLocation.Paint
        Dim graphicPlot As Graphics = e.Graphics 'Declare a graphics object provided by the paint event object.
        Dim pointEnd As Point
        Dim dblOrientation As Double
        Dim dblTempCos As Double
        Dim dblTempSin As Double
        Dim nTemp As Integer
        Dim pointLocationScaled As Point
        Dim rectTemp As Rectangle

        dblOrientation = (mdblRobotOrientation / 180) * PI  ' Update the orientation of the robot.
        dblTempCos = Cos(dblOrientation)                    ' Store the sine and cosine of orientation
        dblTempSin = Sin(dblOrientation)                    ' angle in temperory variables to improve efficiency.
        nTemp = mnChangeDistanceTick

        mpointRobotLocation.X = mpointRobotLocation.X + (dblTempCos * nTemp) 'Update the (x,y) position of the robot.
        mpointRobotLocation.Y = mpointRobotLocation.Y - (dblTempSin * nTemp)

        pointLocationScaled.X = mdblScaleFactor * mpointRobotLocation.X + mnPlotWidth_div2 'Compute the location to plot
        pointLocationScaled.Y = mdblScaleFactor * mpointRobotLocation.Y + mnPlotHeigth_div2 'the symbol of the robot on
        'the display area.

        pointEnd.X = pointLocationScaled.X + mnRobotSize * dblTempCos   'The following instructions draw a symbol of
        pointEnd.Y = pointLocationScaled.Y - mnRobotSize * dblTempSin   'the robot in the display area.  The symbol
        graphicPlot.DrawLine(mpenMain, pointLocationScaled, pointEnd)   'consists of a small circle and line.
        rectTemp.X = pointLocationScaled.X - 3
        rectTemp.Y = pointLocationScaled.Y - 3
        rectTemp.Width = 10
        rectTemp.Height = 10
        graphicPlot.DrawEllipse(mpenMain, rectTemp)

        'rectTemp.X = pointLocationScaled.X
        'rectTemp.Y = pointLocationScaled.Y
        'rectTemp.Width = 1
        'rectTemp.Height = 1
        'graphicPlot.DrawRectangle(mpenMain, rectTemp)

        ToolStripStatusLabel1.Text = "(x,y) = (" & CStr(mpointRobotLocation.X) & "," & CStr(-mpointRobotLocation.Y) & ")"
    End Sub

    Private Sub PictureBoxLocation_Resize(sender As Object, e As EventArgs) Handles PictureBoxLocation.Resize
        mnPlotHeigth_div2 = PictureBoxLocation.Height / 2
        mnPlotWidth_div2 = PictureBoxLocation.Width / 2
    End Sub

End Class