﻿
Public Class FormMain

    'Global public datatypes declaration 
    Public Const mstrSoftwareTitle = "Two-Wheels Robot Monitor and Control"
    Public Const mstrSoftwareVersion = "Version 1.52"
    Public Const mstrSoftwareAuthor = "Fabian Kung Wai Lee"
    Public Const mstrSoftwareDate = "15 June 2021"
    Public Const mstrCompany = "Multimedia University"
    Public Const mstrAddress = "Faculty of Engineering, Jalan Multimedia, Cyberjaya, Selangor, MALAYSIA"
    Public Const mstrWebpage = "http://foe.mmu.edu.my"

    'Global private datatypes declaration 
    Private Const cintTimerInterval = 10 'Timer clock tick interval in msec.

    Private bytReceiveData As Byte
    Private bytSendData As Byte
    Private mstrComPortName As String
    Private bytSlaveID As Byte

    Private mintState As Integer
    Private mblnConnectButton As Boolean 'True = Request to connect to remote unit.
    'False = Request to disconnect from remote unit. 

    Public gnDataReceiveFlag As Integer '0 = No data, 1 = New data.
    Public gnSerialReceiveThreshold As Integer 'Received bytes trigger threshold.

    'Global private object
    Private mfrmXYplot1 As New XYPlotForm
    Private mfrmXYplot2 As New XYPlotForm
    Private mfrmLocation As New PosePlot2DForm
    Private mfrmBarPlot1 As New BarPlot
    Private mintXYplot1Trace1Select As New Integer
    Private mintXYPlot1Trace2Select As New Integer
    Private mintXYPlot1Trace3Select As New Integer
    Private mintXYPlot1Trace4Select As New Integer

    'Coefficients and their intervals.
    Private mdblC(0 To 9) As Double
    Private mdblCDelta(0 To 9) As Double
    Private mintCTrackBarValueBackUp(0 To 9) As Integer
    Private mintMotorSequenceNo As Integer

    Const _TRACKBAR_OFFSET As Byte = 90

    'Coefficient sequence storage
    Const _MAX_COEFF_SEQUENCE = 5
    Private mdblCRes(0 To (_MAX_COEFF_SEQUENCE - 1))() As Double
    Private mintTrackBarValueRes(0 To (_MAX_COEFF_SEQUENCE - 1))() As Integer

    'Physical parameters
    Private mdblTurnAngleDegPerUnit As Double
    Private mdblWheelDiameterMM As Double
    Private mdblRotationAnglePerAverageTick As Double

    'RF wireless link Command.
    Private mbytRFCommand As Byte
    Private mbytRFArgument As Byte
    Private mbytRFArgument2 As Byte

    'Data packet type
    Const _COMMAND As Byte = &H55
    Const _DATA_ASCII As Byte = &HAA
    Const _DATA_BIN As Byte = &HAB

    'Commands

    Const _ERROR_TIMEOUT As Byte = &H13
    Const _SPP_ESTABLISH_LINK As Byte = &H10
    Const _SPP_LINK_ESTABLISHED As Byte = &H11
    Const _TUNABLE_COEFFICIENT_INFO As Byte = &H12
    Const _COEFFICENT_INFO As Byte = &H13
    Const _DEVICE_RESET As Byte = &H0
    Const _RES_COEFFICIENT As Byte = &H1
    Const _SET_COEFFICIENT As Byte = &H2

    'Texts and labels
    Const _PARAM1_TEXT As String = "Tilt Angle"
    Const _PARAM2_TEXT As String = "Right Wheel V"
    Const _PARAM3_TEXT As String = "Left Wheel V"
    Const _PARAM4_TEXT As String = "Average Wheel V"
    Const _PARAM5_TEXT As String = "Right Wheel X"
    Const _PARAM6_TEXT As String = "Left Wheel X"
    Const _PARAM7_TEXT As String = "Average Wheel X"
    Const _PARAM8_TEXT As String = "Heading"
    Const _PARAM9_TEXT As String = "Set Tilt Angle"
    Const _PARAM10_TEXT As String = "Set Average V"
    Const _PARAM11_TEXT As String = "Set Average X"
    Const _PARAM12_TEXT As String = "Set Heading"

    Private Sub FormMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim nxIndex As Integer
        Dim nPortCount As Integer

        Try

            Me.Text = mstrSoftwareTitle & " " & mstrSoftwareVersion & " (" & mstrSoftwareDate & ")"
            mintState = 0 'State = RESET.

            'Initialize all module level parameters.
            gnDataReceiveFlag = 0
            Timer1.Interval = cintTimerInterval 'Load timer interval in miliseconds.
            Timer1.Enabled = True 'Enable timer.

            'intSpeed = 3 'The default speed.
            bytSlaveID = 1 'The default remote device ID.
            StatusStripLabel1.Text = "No COM port open"
            mblnConnectButton = False


            mintXYplot1Trace1Select = 0             'Select the default data to display in XY plot window 1.
            Trace1RadioButton1.Checked = True       'Also update the corresponding label text.
            Data1Label.Text = _PARAM1_TEXT
            mintXYPlot1Trace2Select = 3
            Trace2RadioButton4.Checked = True
            Data2Label.Text = _PARAM4_TEXT
            mintXYPlot1Trace3Select = 1
            Trace3RadioButton2.Checked = True
            Data3Label.Text = _PARAM7_TEXT
            mintXYPlot1Trace4Select = 4
            Trace4RadioButton5.Checked = True
            Data4Label.Text = ""

            'Initialize coefficients.
            For nxIndex = 0 To 9
                mdblC(nxIndex) = 0.0
                mdblCDelta(nxIndex) = 1.0
                mintCTrackBarValueBackUp(nxIndex) = 90
            Next

            'Initialize memory for storing backup values of coefficients, for restoring purpose.
            For nxIndex = 0 To (_MAX_COEFF_SEQUENCE - 1)
                ReDim mdblCRes(nxIndex)(9)
                ReDim mintTrackBarValueRes(nxIndex)(9)
            Next

            mintMotorSequenceNo = 0
            LabelMotorSequence.Text = CStr(mintMotorSequenceNo)

            'Initialize the status of all controls.
            ButtonConnect.Enabled = False
            GroupBoxAction.Enabled = False
            GroupBoxCoefficients.Enabled = False

            'List all available serial port in the Combobox items and initialize the selection.
            For Each strSerialPortName As String In My.Computer.Ports.SerialPortNames
                ComboBoxComPort.Items.Add(strSerialPortName)
                nPortCount += 1
            Next

            If nPortCount = 0 Then 'Check if serial port exist.
                MessageBox.Show("No serial port found, please setup a serial port", "ERROR", MessageBoxButtons.OK)
            Else
                mstrComPortName = ComboBoxComPort.Items(0) 'The default COM Port name.
                ComboBoxComPort.SelectedIndex = 0
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, "ERROR", MessageBoxButtons.OK)
        End Try

    End Sub

    Private Sub ButtonOpen_Click(sender As Object, e As EventArgs) Handles ButtonOpen.Click

        Dim bytTxData(0 To 7) As Byte

        Try

            If SerialPort1.IsOpen = False Then 'Check if Serial Port is opened, if not open the port.
                SerialPort1.PortName = mstrComPortName 'Set the COM port name.

                SerialPort1.BaudRate = 115200
                SerialPort1.Parity = IO.Ports.Parity.None
                SerialPort1.StopBits = IO.Ports.StopBits.One
                SerialPort1.DataBits = 8
                SerialPort1.Handshake = IO.Ports.Handshake.None
                SerialPort1.ReceivedBytesThreshold = 8 'Only generate a system interrupt when multiple of 8 bytes are received in the receive buffer.
                'Need to ensure that data from remote unit is in multiples of 8 bytes.        

                SerialPort1.Open()

                SerialPort1.DiscardInBuffer() 'Flush buffer after initialization.
                gnDataReceiveFlag = 0 'Clear flag.
                gnSerialReceiveThreshold = 8 'Default packet length.

                If SerialPort1.IsOpen = True Then   'Change the status of the Open Button once the Serial Port is opened.
                    ButtonOpen.Text = "CLOSE"
                    StatusStrip1.Text = mstrComPortName & " is opened"

                    'Enable all relevant controls.
                    'ButtonStart.Enabled = True
                    'ButtonStop.Enabled = True
                    ButtonConnect.Enabled = True
                    GroupBoxCoefficients.Enabled = False
                    GroupBoxAction.Enabled = False

                    mintState = 0
                End If

            Else 'Serial port is already opened.

                bytTxData(0) = bytSlaveID 'Send reset command to slave device.
                bytTxData(1) = _COMMAND
                bytTxData(2) = _DEVICE_RESET
                bytTxData(3) = 0
                bytTxData(4) = 0
                SerialPort1.Write(bytTxData, 0, 5)  'Write 5 bytes of data to serial port.

                Do While SerialPort1.BytesToWrite > 0 'Wait until all data in the transmit buffer is send out.
                Loop                                  'before closing the serial port.

                SerialPort1.Close() 'Close the Serial Port.
                StatusStrip1.Text = "No COM port open"
                ButtonOpen.Text = "OPEN"
                ButtonConnect.Enabled = False
                mblnConnectButton = False
                GroupBoxCoefficients.Enabled = False

                mintState = 0 'Reset system state machine.

            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Open Error!", MessageBoxButtons.OK)
        End Try

    End Sub

    Private Sub FormMain_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed

        If SerialPort1.IsOpen = True Then
            SerialPort1.Close()
        End If

    End Sub

    Private Sub ComboBoxComPort_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBoxComPort.SelectedIndexChanged

        mstrComPortName = ComboBoxComPort.Items(ComboBoxComPort.SelectedIndex)    'Update the name of the selected COM Port, i.e. "COMX", where X = 1,2,3...
        ShowTextData(mstrComPortName & " is selected.", Me.ForeColor)

    End Sub

    'Subroutine to monitor the input bufffer of the virtual UART port.  Trigger the system if minimum number of bytes are received.
    Private Sub SerialPort1_DataReceived(sender As Object, e As IO.Ports.SerialDataReceivedEventArgs) Handles SerialPort1.DataReceived

        If (SerialPort1.BytesToRead >= gnSerialReceiveThreshold) Then  'The receive data packet larger than the threshold?.
            gnDataReceiveFlag = 1   'Assert data receive flag.
        End If

    End Sub

    'Initiate link-up with Remote Client.  This will start a series of hand-shaking event between the
    'Host and Client to established a SPP (Serial Port Protocol) for wireless communication.
    'The global variable mblnConnectButton should be set to False whenever the virtual serial port is closed.
    Private Sub ButtonConnect_Click(sender As Object, e As EventArgs) Handles ButtonConnect.Click

        Dim bytTxData(0 To 7) As Byte

        Try
            ButtonConnect.Enabled = False

            bytTxData(0) = bytSlaveID
            bytTxData(1) = _COMMAND
            bytTxData(2) = _SPP_ESTABLISH_LINK
            bytTxData(3) = 0    '0 for PC or tablet, 1 for smartphone of other devices.
            bytTxData(4) = 0
            SerialPort1.Write(bytTxData, 0, 5)  'Write 5 bytes of data to serial port.
            gnSerialReceiveThreshold = 8    'Set serial port received buffer trigger threshold.
            mblnConnectButton = True

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Connect Error!", MessageBoxButtons.OK)
            ButtonConnect.Enabled = True
            MessageBox.Show("Please quit the software and try another port", "Connect Error!", MessageBoxButtons.OK)
        End Try

    End Sub

    'Main state-machine - This handles display of data received from the remote machine.
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        Static Dim intCount As Integer
        Dim strRxData As String = ""

        Static Dim strTemp As String
        Static Dim nDataBitLength1 As Integer
        Static Dim nDataBitLength2 As Integer

        Dim bytTxData(0 To 7) As Byte
        Dim bytRxData(0 To 100) As Byte
        Dim bytTemp As Byte
        Dim nTemp As Integer
        Dim nTemp2 As Integer
        Dim nTemp3 As Integer
        Dim nTemp4 As Integer
        Dim nTemp5 As Integer
        Dim nTemp6 As Integer
        Dim nTemp7 As Integer
        Dim nTemp8 As Integer
        Dim nIndex As Integer


        Try
            If SerialPort1.IsOpen = True Then 'Only proceed if serial port is opened.
                'Blink an indicator (the word "BT") on the main window status.
                intCount = intCount + 1
                If (intCount > 31) Then                     'Check if counter overflows.
                    intCount = 0
                    If StatusStripLabel1.Text = "" Then
                        StatusStripLabel1.Text = "BT"       'Show the word "BT".
                    Else
                        StatusStripLabel1.Text = ""         'Empty the status.
                    End If
                End If

                'Main state machine.
                Select Case mintState
                    Case 0 'Reset
                        ButtonConnect.Enabled = True
                        gnSerialReceiveThreshold = 8 'Default length for data packet from remote unit.
                        mintState = 1 'Next state = 1.

                    Case 1 'Check if Connect button is pressed.  Initialize SPP link with remote unit.
                        If mblnConnectButton = True Then
                            mblnConnectButton = False

                            mintState = 2 'Next state = 2.
                        Else
                            mintState = 1 'Remain in state 1.
                        End If

                    Case 2 'Check if the remote unit response.
                        ' The remote unit should response with the Command _SPP_LINK_ESTABLISHED, in addition the remote
                        ' unit will also indicate the length of the sensor data to be displayed.  Byte 3 contains the bit 
                        ' length for data 1, 2 and 3, Byte 4 contains the bit length for data 3, 4 and 5.  
                        ' Format for bit length:
                        ' 0 = 16 bits unsigned integer data.
                        ' 1 = 15 bits unsigned integer data.
                        ' 2 = 14 bits unsigned integer data.
                        ' ...
                        ' 7 = 9 bits unsigned integer data.
                        ' 8 = 8 bits unsigned integer data.

                        If gnDataReceiveFlag = 1 Then 'Check if new data arrived from Comm Port.
                            SerialPort1.Read(bytRxData, 0, 5) 'Read 5 bytes of data from serial port receive buffer.
                            SerialPort1.DiscardInBuffer() 'Flush buffer
                            gnDataReceiveFlag = 0 'Clear flag.

                            If (bytRxData(0) = bytSlaveID) Then 'Remote unit responded.  Check if it is the correct response.
                                If ((bytRxData(1) = _COMMAND) And (bytRxData(2) = _SPP_LINK_ESTABLISHED)) Then
                                    mintState = 3 'Next state = 3.
                                    gnSerialReceiveThreshold = 64 'Length for data packet from remote unit after SPP link is established.
                                    'gnSerialReceiveThreshold = 16 'Length for data packet from remote unit after SPP link is established.

                                    nDataBitLength1 = bytRxData(3) 'Get the bit length for unsigned integer data 1, 2 and 3.  
                                    nDataBitLength2 = bytRxData(4) 'Get the bit length for unsigned integer data 4, 5 and 6.

                                    GroupBoxCoefficients.Enabled = True     'Enable the coefficients tuning groupbox.
                                    TrackBarC1.Value = 90   'Return all trackbars to the middle position.
                                    TrackBarC2.Value = 90
                                    TrackBarC3.Value = 90
                                    TrackBarC4.Value = 90
                                    TrackBarC5.Value = 90
                                    TrackBarC6.Value = 90
                                    TrackBarC7.Value = 90
                                    TrackBarC8.Value = 90
                                    TrackBarC9.Value = 90
                                    TrackBarC10.Value = 90

                                    'Initialize trackbar backup value.
                                    For nxIndex = 0 To 9
                                        mintCTrackBarValueBackUp(nxIndex) = 90
                                    Next

                                    GroupBoxAction.Enabled = True

                                    StatusStripLabel2.Text = "Remote Unit responded"

                                    'Initialize XY plot 1 object windows.  Set the y-axis max 
                                    'limit based on the number of data bits of the data. 
                                    'The minimum is 0 as the data is unsigned integer.
                                    Select Case (nDataBitLength1)
                                        Case 0 '16 bits
                                            mfrmXYplot1.Text = "16-bits Unsigned Data"
                                            mfrmXYplot1.dblYmax = 65535
                                        Case 1
                                            mfrmXYplot1.Text = "15-bits Unsigned Data"
                                            mfrmXYplot1.dblYmax = 32767
                                        Case 2
                                            mfrmXYplot1.Text = "14-bits Unsigned Data"
                                            mfrmXYplot1.dblYmax = 616383
                                        Case 3
                                            mfrmXYplot1.Text = "13-bits Unsigned Data"
                                            mfrmXYplot1.dblYmax = 8191
                                        Case 4
                                            mfrmXYplot1.Text = "12-bits Unsigned Data"
                                            mfrmXYplot1.dblYmax = 4095
                                        Case 5
                                            mfrmXYplot1.Text = "11-bits Unsigned Data"
                                            mfrmXYplot1.dblYmax = 2047
                                        Case 6
                                            mfrmXYplot1.Text = "10-bits Unsigned Data"
                                            mfrmXYplot1.dblYmax = 1023
                                        Case 7
                                            mfrmXYplot1.Text = "9-bits Unsigned Data"
                                            mfrmXYplot1.dblYmax = 511
                                        Case Else
                                            mfrmXYplot1.Text = "8-bits Unsigned Data"
                                            mfrmXYplot1.dblYmax = 255
                                    End Select

                                    mfrmXYplot1.strXDivision = "Samples"
                                    mfrmXYplot1.dblYmin = 0
                                    mfrmXYplot1.Show()

                                    'Initialize XY plot 2 object windows.  Set the y-axis max 
                                    'limit based on the number of data bits of the data. 
                                    'The minimum is 0 as the data is unsigned integer.
                                    Select Case (nDataBitLength2)
                                        Case 0 '16 bits
                                            mfrmXYplot2.Text = "16-bits Unsigned Data"
                                            mfrmXYplot2.dblYmax = 65535
                                        Case 1
                                            mfrmXYplot2.Text = "15-bits Unsigned Data"
                                            mfrmXYplot2.dblYmax = 32767
                                        Case 2
                                            mfrmXYplot2.Text = "14-bits Unsigned Data"
                                            mfrmXYplot2.dblYmax = 616383
                                        Case 3
                                            mfrmXYplot2.Text = "13-bits Unsigned Data"
                                            mfrmXYplot2.dblYmax = 8191
                                        Case 4
                                            mfrmXYplot2.Text = "12-bits Unsigned Data"
                                            mfrmXYplot2.dblYmax = 4095
                                        Case 5
                                            mfrmXYplot2.Text = "11-bits Unsigned Data"
                                            mfrmXYplot2.dblYmax = 2047
                                        Case 6
                                            mfrmXYplot2.Text = "10-bits Unsigned Data"
                                            mfrmXYplot2.dblYmax = 1023
                                        Case 7
                                            mfrmXYplot2.Text = "9-bits Unsigned Data"
                                            mfrmXYplot2.dblYmax = 511
                                        Case Else
                                            mfrmXYplot2.Text = "8-bits Unsigned Data"
                                            mfrmXYplot2.dblYmax = 255
                                    End Select

                                    mfrmXYplot2.strXDivision = "Samples"
                                    mfrmXYplot2.dblYmin = 0
                                    mfrmXYplot2.Show()

                                    'Initialize Bitmap window (for localization/pose indicator).
                                    mfrmLocation.mpointRobotLocation.X = 0
                                    mfrmLocation.mpointRobotLocation.Y = 0
                                    mfrmLocation.mdblScaleFactor = 0.1
                                    mfrmLocation.Show()

                                    'Initialize Bar Plot.
                                    mfrmBarPlot1.Text = "FFT Magnitude Squared /2"
                                    mfrmBarPlot1.Show()
                                Else
                                    mintState = 0
                                End If
                            Else
                                mintState = 0
                            End If
                        Else
                            mintState = 2 'No response from remote unit, remain in state 2.
                        End If

                    Case 3 'Main listening routines, handles binary, ASCII and command payloads.
                        If gnDataReceiveFlag = 1 Then 'Check if new data arrived from Comm Port.
                            SerialPort1.Read(bytRxData, 0, 64) 'Read 64 bytes of data from serial port receive buffer
                            'SerialPort1.Read(bytRxData, 0, 16) 'Read 16 bytes of data from serial port receive buffer.

                            SerialPort1.DiscardInBuffer() 'Flush buffer
                            gnDataReceiveFlag = 0 'Clear flag.

                            If (bytRxData(0) = bytSlaveID) Then 'Remote unit transmitted.  
                                If bytRxData(1) = _DATA_BIN Then    'Binary data payload.

                                    'Binary data packet format:
                                    ' Byte 0: ID or Address of this unit.
                                    ' Byte 1: Format, i.e. binary or ASCII.
                                    ' Byte 2: 8-bits unsigned integer data 1.
                                    ' Byte 3: 8-bits unsigned integer data 2.
                                    ' Byte 4: 8-bits unsigned integer data 3.
                                    ' Byte 5: 8-bits unsigned integer data 4.
                                    ' Byte 6: 8-bits unsigned integer data 5.
                                    ' Byte 7: 8-bits unsigned integer data 6.
                                    ' Byte 8: 8-bits unsigned integer data 7.
                                    ' Byte 9: 8-bits unsigned integer data 8.
                                    ' Byte 10: 8-bits unsigned integer data 9.
                                    ' Byte 11: 8-bits unsigned integer data 10.
                                    ' Byte 12: 8-bits unsigned integer data 11.
                                    ' Byte 13: 8-bits unsigned integer data 12.
                                    ' Byte 14: Uppder 8-bits of 16-bits unsigned integer data 1.
                                    ' Byte 15: Lower 8-bits of 16-bits unsigned integer data 1.
                                    ' Byte 16: Uppder 8-bits of 16-bits unsigned integer data 2.
                                    ' Byte 17: Lower 8-bits of 16-bits unsigned integer data 2.
                                    ' Byte 18: Uppder 8-bits of 16-bits unsigned integer data 3.
                                    ' Byte 19: Lower 8-bits of 16-bits unsigned integer data 3.
                                    ' Byte 20: Uppder 8-bits of 16-bits unsigned integer data 4.
                                    ' Byte 21: Lower 8-bits of 16-bits unsigned integer data 4.
                                    ' Byte 22: A byte containing general purpose flags.  Each bit in
                                    '          the byte is a flag.
                                    ' Byte 23: Delta distance.
                                    ' Byte 24: Upper 8 bits of offset heading.
                                    ' Byte 25: lower 8 bits of offset heading.
                                    ' Byte 26: Reserved.
                                    ' Byte 27-34: Scaled FFT magnitude output, index 0 to 7.


                                    'Get 16-bits unsigned integer data first.  Here we assume are 16-bits data
                                    'are unsigned integer, offset by 4095 from the remote client.
                                    nTemp = bytRxData(14)                     ' Get upper byte of data.
                                    nTemp = (nTemp << 8) + bytRxData(15)      ' Get lower byte of data and form 16 bits word.

                                    nTemp2 = bytRxData(16)                     ' Get upper byte of data.
                                    nTemp2 = (nTemp2 << 8) + bytRxData(17)     ' Get lower byte of data and form 16 bits word.

                                    nTemp3 = bytRxData(18)                     ' Get upper byte of data.
                                    nTemp3 = (nTemp3 << 8) + bytRxData(19)     ' Get lower byte of data and form 16 bits word.

                                    nTemp8 = bytRxData(20)                     ' Get upper byte of data.
                                    nTemp8 = (nTemp8 << 8) + bytRxData(21)     ' Get lower byte of data and form 16 bits word.

                                    'Assign data to Trace 1 of Display 1.
                                    Select Case mintXYplot1Trace1Select
                                        Case 0
                                            nTemp4 = bytRxData(2)
                                        Case 1
                                            nTemp4 = bytRxData(3)
                                        Case 2
                                            nTemp4 = bytRxData(4)
                                        Case 3
                                            nTemp4 = bytRxData(5)
                                        Case 4
                                            nTemp4 = bytRxData(6)
                                        Case 5
                                            nTemp4 = bytRxData(7)
                                        Case 6
                                            nTemp4 = bytRxData(8)
                                        Case 7
                                            nTemp4 = bytRxData(9)
                                        Case 8
                                            nTemp4 = bytRxData(10)
                                        Case 9
                                            nTemp4 = bytRxData(11)
                                        Case 10
                                            nTemp4 = bytRxData(12)
                                        Case Else
                                            nTemp4 = bytRxData(13)
                                    End Select

                                    'Assign data to Trace 2 of Display 1.
                                    Select Case mintXYPlot1Trace2Select
                                        Case 0
                                            nTemp5 = bytRxData(2)
                                        Case 1
                                            nTemp5 = bytRxData(3)
                                        Case 2
                                            nTemp5 = bytRxData(4)
                                        Case 3
                                            nTemp5 = bytRxData(5)
                                        Case 4
                                            nTemp5 = bytRxData(6)
                                        Case 5
                                            nTemp5 = bytRxData(7)
                                        Case 6
                                            nTemp5 = bytRxData(8)
                                        Case 7
                                            nTemp5 = bytRxData(9)
                                        Case Else 'None
                                            nTemp5 = 127
                                    End Select

                                    'Assign data to Trace 3 of Display 1.
                                    Select Case mintXYPlot1Trace3Select
                                        Case 0
                                            nTemp6 = bytRxData(5)
                                        Case 1
                                            nTemp6 = bytRxData(8)
                                        Case 2
                                            nTemp6 = bytRxData(9)
                                        Case 3
                                            nTemp6 = ((nTemp2 - 4095) * (-mdblRotationAnglePerAverageTick)) + 127 'Convert average wheel tick to tilt angle
                                            'angle in degree, limited to 0 to 255 degrees.
                                        Case Else 'None
                                            nTemp6 = 127
                                    End Select

                                    'Assign data to Trace 4 of Display 1.
                                    Select Case mintXYPlot1Trace4Select
                                        Case 0
                                            nTemp7 = bytRxData(10)
                                        Case 1
                                            nTemp7 = bytRxData(11)
                                        Case 2
                                            nTemp7 = bytRxData(12)
                                        Case 3
                                            nTemp7 = bytRxData(13)
                                        Case Else 'None
                                            nTemp7 = 127
                                    End Select

                                    LabelData1.Text = CStr(nTemp4 - 127)      'Display instantaneous Data 1 of Display 1 value in window
                                    LabelData2.Text = CStr(nTemp5 - 127)      'Display instantaneous Data 2 of Display 1 value in window
                                    LabelData3.Text = CStr(nTemp6 - 127)      'Display instantaneous Data 3 of Display 1 value in window
                                    LabelData4.Text = CStr(nTemp7 - 127)      'Display instantaneous Data 4 of Display 1 value in window

                                    'Check whether to display traces 1-3 of Display 2.
                                    If P2Trace1CheckBox.Checked = False Then
                                        nTemp = 4095 '4095 is the offset added in the robot to make the data positive, so we need to remove it.
                                    End If
                                    If P2Trace2CheckBox.Checked = False Then
                                        nTemp2 = 4095
                                    End If
                                    If P2Trace3CheckBox.Checked = False Then
                                        nTemp3 = 4095
                                    End If

                                    LabelData5.Text = CStr(nTemp - 4095)      'Display instantaneous Data 1 of Display 2 value in window  
                                    LabelData6.Text = CStr(nTemp2 - 4095)     'Display instantaneous Data 2 of Display 2 value in window  
                                    LabelData7.Text = CStr(nTemp3 - 4095)     'Display instantaneous Data 3 of Display 2 value in window 
                                    LabelData8.Text = CStr(nTemp8 - 4095)     'Display instantaneous Data 4 of Display 2 value in window

                                    'Shift the data according to their valid no. of bits, and show in graph.  The data accepted by function
                                    'UpdataLevelIndicator is 16 bits unsigned integer value from 0 to 65535.                                                                    
                                    UpdateLevelIndicator(nTemp4 << nDataBitLength1, nTemp5 << nDataBitLength1, nTemp6 << nDataBitLength1, nTemp7 << nDataBitLength1,
                                                         nTemp << nDataBitLength2, nTemp2 << nDataBitLength2, nTemp3 << nDataBitLength2, nTemp8 << nDataBitLength2)

                                    'Get 16-bits unsigned integer data first.
                                    nTemp = bytRxData(24)                     ' Get upper byte of data.
                                    nTemp = (nTemp << 8) + bytRxData(25)      ' Get lower byte of data and form 16 bits word.
                                    mfrmLocation.mdblRobotOrientation = (nTemp - 4095) * mdblTurnAngleDegPerUnit + 90
                                    ' Note: The integer data is added with 127 in the robot to make it positive value.
                                    ' Also orientation is measured with respect to x-axis, while in the robot it is measured
                                    ' with respect to the y-axis, thus the additional 90 degree.
                                    mfrmLocation.mnChangeDistanceTick = bytRxData(23) - 127 'Get change in distance travelled in ticks, remove offset.
                                    mfrmLocation.Refresh()

                                    'Byte 22 indicates general purpose flag status. Each bit in the bit corresponds to a true or false status, and is display
                                    'in each square.
                                    bytTemp = bytRxData(22) And &HF  'Mask out all bits except bit3 to bit 0
                                    Select Case bytTemp
                                        Case 0 'b0000
                                            LabelGPFlag11.BackColor = Color.Aqua
                                            LabelGPFlag12.BackColor = Color.Aqua
                                            LabelGPFlag13.BackColor = Color.Aqua
                                            LabelGPFlag14.BackColor = Color.Aqua
                                        Case 1 'b0001
                                            LabelGPFlag11.BackColor = Color.Red
                                            LabelGPFlag12.BackColor = Color.Aqua
                                            LabelGPFlag13.BackColor = Color.Aqua
                                            LabelGPFlag14.BackColor = Color.Aqua
                                        Case 2 'b0010
                                            LabelGPFlag11.BackColor = Color.Aqua
                                            LabelGPFlag12.BackColor = Color.Red
                                            LabelGPFlag13.BackColor = Color.Aqua
                                            LabelGPFlag14.BackColor = Color.Aqua
                                        Case 3 'b0011
                                            LabelGPFlag11.BackColor = Color.Red
                                            LabelGPFlag12.BackColor = Color.Red
                                            LabelGPFlag13.BackColor = Color.Aqua
                                            LabelGPFlag14.BackColor = Color.Aqua
                                        Case 4 'b0100
                                            LabelGPFlag11.BackColor = Color.Aqua
                                            LabelGPFlag12.BackColor = Color.Aqua
                                            LabelGPFlag13.BackColor = Color.Red
                                            LabelGPFlag14.BackColor = Color.Aqua
                                        Case 5 'b0101
                                            LabelGPFlag11.BackColor = Color.Red
                                            LabelGPFlag12.BackColor = Color.Aqua
                                            LabelGPFlag13.BackColor = Color.Red
                                            LabelGPFlag14.BackColor = Color.Aqua
                                        Case 6 'b0110
                                            LabelGPFlag11.BackColor = Color.Aqua
                                            LabelGPFlag12.BackColor = Color.Red
                                            LabelGPFlag13.BackColor = Color.Red
                                            LabelGPFlag14.BackColor = Color.Aqua
                                        Case 7 'b0111
                                            LabelGPFlag11.BackColor = Color.Red
                                            LabelGPFlag12.BackColor = Color.Red
                                            LabelGPFlag13.BackColor = Color.Red
                                            LabelGPFlag14.BackColor = Color.Aqua
                                        Case 8 'b1000
                                            LabelGPFlag11.BackColor = Color.Aqua
                                            LabelGPFlag12.BackColor = Color.Aqua
                                            LabelGPFlag13.BackColor = Color.Aqua
                                            LabelGPFlag14.BackColor = Color.Red
                                        Case 9 'b1001
                                            LabelGPFlag11.BackColor = Color.Red
                                            LabelGPFlag12.BackColor = Color.Aqua
                                            LabelGPFlag13.BackColor = Color.Aqua
                                            LabelGPFlag14.BackColor = Color.Red
                                        Case 10 'b1010
                                            LabelGPFlag11.BackColor = Color.Aqua
                                            LabelGPFlag12.BackColor = Color.Red
                                            LabelGPFlag13.BackColor = Color.Aqua
                                            LabelGPFlag14.BackColor = Color.Red
                                        Case 11 'b1011
                                            LabelGPFlag11.BackColor = Color.Red
                                            LabelGPFlag12.BackColor = Color.Red
                                            LabelGPFlag13.BackColor = Color.Aqua
                                            LabelGPFlag14.BackColor = Color.Red
                                        Case 12 'b1100
                                            LabelGPFlag11.BackColor = Color.Aqua
                                            LabelGPFlag12.BackColor = Color.Aqua
                                            LabelGPFlag13.BackColor = Color.Red
                                            LabelGPFlag14.BackColor = Color.Red
                                        Case 13 'b1101
                                            LabelGPFlag11.BackColor = Color.Red
                                            LabelGPFlag12.BackColor = Color.Aqua
                                            LabelGPFlag13.BackColor = Color.Red
                                            LabelGPFlag14.BackColor = Color.Red
                                        Case 14 'b1110
                                            LabelGPFlag11.BackColor = Color.Aqua
                                            LabelGPFlag12.BackColor = Color.Red
                                            LabelGPFlag13.BackColor = Color.Red
                                            LabelGPFlag14.BackColor = Color.Red
                                        Case Else 'b0111
                                            LabelGPFlag11.BackColor = Color.Red
                                            LabelGPFlag12.BackColor = Color.Red
                                            LabelGPFlag13.BackColor = Color.Red
                                            LabelGPFlag14.BackColor = Color.Red
                                    End Select

                                    bytTemp = (bytRxData(22) And &HF0) >> 4  'Mask out all bits except bit7 to bit 4, shift right 4 bits.
                                    Select Case bytTemp
                                        Case 0 'b0000
                                            LabelGPFlag21.BackColor = Color.Aqua
                                            LabelGPFlag22.BackColor = Color.Aqua
                                            LabelGPFlag23.BackColor = Color.Aqua
                                            LabelGPFlag24.BackColor = Color.Aqua
                                        Case 1 'b0001
                                            LabelGPFlag21.BackColor = Color.Red
                                            LabelGPFlag22.BackColor = Color.Aqua
                                            LabelGPFlag23.BackColor = Color.Aqua
                                            LabelGPFlag24.BackColor = Color.Aqua
                                        Case 2 'b0010
                                            LabelGPFlag21.BackColor = Color.Aqua
                                            LabelGPFlag22.BackColor = Color.Red
                                            LabelGPFlag23.BackColor = Color.Aqua
                                            LabelGPFlag24.BackColor = Color.Aqua
                                        Case 3 'b0011
                                            LabelGPFlag21.BackColor = Color.Red
                                            LabelGPFlag22.BackColor = Color.Red
                                            LabelGPFlag23.BackColor = Color.Aqua
                                            LabelGPFlag24.BackColor = Color.Aqua
                                        Case 4 'b0100
                                            LabelGPFlag21.BackColor = Color.Aqua
                                            LabelGPFlag22.BackColor = Color.Aqua
                                            LabelGPFlag23.BackColor = Color.Red
                                            LabelGPFlag24.BackColor = Color.Aqua
                                        Case 5 'b0101
                                            LabelGPFlag21.BackColor = Color.Red
                                            LabelGPFlag22.BackColor = Color.Aqua
                                            LabelGPFlag23.BackColor = Color.Red
                                            LabelGPFlag24.BackColor = Color.Aqua
                                        Case 6 'b0110
                                            LabelGPFlag21.BackColor = Color.Aqua
                                            LabelGPFlag22.BackColor = Color.Red
                                            LabelGPFlag23.BackColor = Color.Red
                                            LabelGPFlag24.BackColor = Color.Aqua
                                        Case 7 'b0111
                                            LabelGPFlag21.BackColor = Color.Red
                                            LabelGPFlag22.BackColor = Color.Red
                                            LabelGPFlag23.BackColor = Color.Red
                                            LabelGPFlag24.BackColor = Color.Aqua
                                        Case 8 'b1000
                                            LabelGPFlag21.BackColor = Color.Aqua
                                            LabelGPFlag22.BackColor = Color.Aqua
                                            LabelGPFlag23.BackColor = Color.Aqua
                                            LabelGPFlag24.BackColor = Color.Red
                                        Case 9 'b1001
                                            LabelGPFlag21.BackColor = Color.Red
                                            LabelGPFlag22.BackColor = Color.Aqua
                                            LabelGPFlag23.BackColor = Color.Aqua
                                            LabelGPFlag24.BackColor = Color.Red
                                        Case 10 'b1010
                                            LabelGPFlag21.BackColor = Color.Aqua
                                            LabelGPFlag22.BackColor = Color.Red
                                            LabelGPFlag23.BackColor = Color.Aqua
                                            LabelGPFlag24.BackColor = Color.Red
                                        Case 11 'b1011
                                            LabelGPFlag21.BackColor = Color.Red
                                            LabelGPFlag22.BackColor = Color.Red
                                            LabelGPFlag23.BackColor = Color.Aqua
                                            LabelGPFlag24.BackColor = Color.Red
                                        Case 12 'b1100
                                            LabelGPFlag21.BackColor = Color.Aqua
                                            LabelGPFlag22.BackColor = Color.Aqua
                                            LabelGPFlag23.BackColor = Color.Red
                                            LabelGPFlag24.BackColor = Color.Red
                                        Case 13 'b1101
                                            LabelGPFlag21.BackColor = Color.Red
                                            LabelGPFlag22.BackColor = Color.Aqua
                                            LabelGPFlag23.BackColor = Color.Red
                                            LabelGPFlag24.BackColor = Color.Red
                                        Case 14 'b1110
                                            LabelGPFlag21.BackColor = Color.Aqua
                                            LabelGPFlag22.BackColor = Color.Red
                                            LabelGPFlag23.BackColor = Color.Red
                                            LabelGPFlag24.BackColor = Color.Red
                                        Case Else 'b0111
                                            LabelGPFlag21.BackColor = Color.Red
                                            LabelGPFlag22.BackColor = Color.Red
                                            LabelGPFlag23.BackColor = Color.Red
                                            LabelGPFlag24.BackColor = Color.Red
                                    End Select

                                    'Update Bar plot.
                                    mfrmBarPlot1.mnX(0) = bytRxData(27)
                                    mfrmBarPlot1.mnX(1) = bytRxData(28)
                                    mfrmBarPlot1.mnX(2) = bytRxData(29)
                                    mfrmBarPlot1.mnX(3) = bytRxData(30)
                                    mfrmBarPlot1.mnX(4) = bytRxData(31)
                                    mfrmBarPlot1.mnX(5) = bytRxData(32)
                                    mfrmBarPlot1.mnX(6) = bytRxData(33)
                                    mfrmBarPlot1.mnX(7) = bytRxData(34)
                                    mfrmBarPlot1.Refresh()

                                ElseIf bytRxData(1) = _DATA_ASCII Then       'ASCII data payload, show string on display.
                                    'ShowTextData("Test", Me.ForeColor)  'Display the text data from remote client on main text display.
                                    For nIndex = 2 To 63 'Get the data characters.
                                        'Check for 'Enter' character, only display the string if newline or
                                        ''Enter' is detected in the last character.  
                                        If ((bytRxData(nIndex) = &HD)) Then
                                            ShowTextData(strRxData, Me.ForeColor)
                                            strRxData = ""  'Clear the string.
                                            nIndex = 100 'Set the index to a value larger than the for-loop limit, to quit the loop.
                                        Else 'Otherwise keep appending the character to the string.
                                            'Display the received data as ASCII character string.
                                            'strRxData = strRxData & CStr(ChrW(bytData(nIndex)))
                                            strRxData = strRxData & ChrW(bytRxData(nIndex))
                                        End If
                                    Next nIndex

                                ElseIf bytRxData(1) = _COMMAND Then 'Command data packet, show string on display.
                                    If bytRxData(2) = _TUNABLE_COEFFICIENT_INFO Then 'Initialize variable coefficient tuning parameters.
                                        Select Case bytRxData(3) 'Check which coefficient parameters to set.
                                            Case 1 'Coefficient 1
                                                nTemp = bytRxData(4)                     ' Get upper byte of data.
                                                nTemp = (nTemp << 8) + bytRxData(5)      ' Get lower byte of data and form 16 bits word.
                                                mdblC(0) = FractionaltoDouble(nTemp)
                                                nTemp = bytRxData(6)                     ' Get upper byte of data.
                                                nTemp = (nTemp << 8) + bytRxData(7)      ' Get lower byte of data and form 16 bits word.
                                                mdblCDelta(0) = FractionaltoDouble(nTemp)
                                                strTemp = ChrW(bytRxData(8)) & ChrW(bytRxData(9)) & ChrW(bytRxData(10)) 'Get the title.
                                                LabelC1Val.Text = CStr(mdblC(0))         'Display the current value.
                                                LabelC1.Text = strTemp                   'Display the title.

                                            Case 2 'Coefficient 2
                                                nTemp = bytRxData(4)                     ' Get upper byte of data.
                                                nTemp = (nTemp << 8) + bytRxData(5)      ' Get lower byte of data and form 16 bits word.
                                                mdblC(1) = FractionaltoDouble(nTemp)
                                                nTemp = bytRxData(6)                     ' Get upper byte of data.
                                                nTemp = (nTemp << 8) + bytRxData(7)      ' Get lower byte of data and form 16 bits word.
                                                mdblCDelta(1) = FractionaltoDouble(nTemp)
                                                strTemp = ChrW(bytRxData(8)) & ChrW(bytRxData(9)) & ChrW(bytRxData(10)) 'Get the title.
                                                LabelC2Val.Text = CStr(mdblC(1))         'Display the current value.
                                                LabelC2.Text = strTemp                   'Display the title.

                                            Case 3 'Coefficient 3
                                                nTemp = bytRxData(4)                     ' Get upper byte of data.
                                                nTemp = (nTemp << 8) + bytRxData(5)      ' Get lower byte of data and form 16 bits word.
                                                mdblC(2) = FractionaltoDouble(nTemp)
                                                nTemp = bytRxData(6)                     ' Get upper byte of data.
                                                nTemp = (nTemp << 8) + bytRxData(7)      ' Get lower byte of data and form 16 bits word.
                                                mdblCDelta(2) = FractionaltoDouble(nTemp)
                                                strTemp = ChrW(bytRxData(8)) & ChrW(bytRxData(9)) & ChrW(bytRxData(10)) 'Get the title.
                                                LabelC3Val.Text = CStr(mdblC(2))         'Display the current value.
                                                LabelC3.Text = strTemp                   'Display the title.

                                            Case 4 'Coefficient 4
                                                nTemp = bytRxData(4)                     ' Get upper byte of data.
                                                nTemp = (nTemp << 8) + bytRxData(5)      ' Get lower byte of data and form 16 bits word.
                                                mdblC(3) = FractionaltoDouble(nTemp)
                                                nTemp = bytRxData(6)                     ' Get upper byte of data.
                                                nTemp = (nTemp << 8) + bytRxData(7)      ' Get lower byte of data and form 16 bits word.
                                                mdblCDelta(3) = FractionaltoDouble(nTemp)
                                                strTemp = ChrW(bytRxData(8)) & ChrW(bytRxData(9)) & ChrW(bytRxData(10)) 'Get the title.
                                                LabelC4Val.Text = CStr(mdblC(3))         'Display the current value.
                                                LabelC4.Text = strTemp                   'Display the title.

                                            Case 5 'Coefficient 5
                                                nTemp = bytRxData(4)                     ' Get upper byte of data.
                                                nTemp = (nTemp << 8) + bytRxData(5)      ' Get lower byte of data and form 16 bits word.
                                                mdblC(4) = FractionaltoDouble(nTemp)
                                                nTemp = bytRxData(6)                     ' Get upper byte of data.
                                                nTemp = (nTemp << 8) + bytRxData(7)      ' Get lower byte of data and form 16 bits word.
                                                mdblCDelta(4) = FractionaltoDouble(nTemp)
                                                strTemp = ChrW(bytRxData(8)) & ChrW(bytRxData(9)) & ChrW(bytRxData(10)) 'Get the title.
                                                LabelC5Val.Text = CStr(mdblC(4))         'Display the current value.
                                                LabelC5.Text = strTemp                   'Display the title.

                                            Case 6 'Coefficient 6
                                                nTemp = bytRxData(4)                     ' Get upper byte of data.
                                                nTemp = (nTemp << 8) + bytRxData(5)      ' Get lower byte of data and form 16 bits word.
                                                mdblC(5) = FractionaltoDouble(nTemp)
                                                nTemp = bytRxData(6)                     ' Get upper byte of data.
                                                nTemp = (nTemp << 8) + bytRxData(7)      ' Get lower byte of data and form 16 bits word.
                                                mdblCDelta(5) = FractionaltoDouble(nTemp)
                                                strTemp = ChrW(bytRxData(8)) & ChrW(bytRxData(9)) & ChrW(bytRxData(10)) 'Get the title.
                                                LabelC6Val.Text = CStr(mdblC(5))         'Display the current value.
                                                LabelC6.Text = strTemp                   'Display the title.

                                            Case 7 'Coefficient 7
                                                nTemp = bytRxData(4)                     ' Get upper byte of data.
                                                nTemp = (nTemp << 8) + bytRxData(5)      ' Get lower byte of data and form 16 bits word.
                                                mdblC(6) = FractionaltoDouble(nTemp)
                                                nTemp = bytRxData(6)                     ' Get upper byte of data.
                                                nTemp = (nTemp << 8) + bytRxData(7)      ' Get lower byte of data and form 16 bits word.
                                                mdblCDelta(6) = FractionaltoDouble(nTemp)
                                                strTemp = ChrW(bytRxData(8)) & ChrW(bytRxData(9)) & ChrW(bytRxData(10)) 'Get the title.
                                                LabelC7Val.Text = CStr(mdblC(6))         'Display the current value.
                                                LabelC7.Text = strTemp                   'Display the title.

                                            Case 8 'Coefficient 8
                                                nTemp = bytRxData(4)                     ' Get upper byte of data.
                                                nTemp = (nTemp << 8) + bytRxData(5)      ' Get lower byte of data and form 16 bits word.
                                                mdblC(7) = FractionaltoDouble(nTemp)
                                                nTemp = bytRxData(6)                     ' Get upper byte of data.
                                                nTemp = (nTemp << 8) + bytRxData(7)      ' Get lower byte of data and form 16 bits word.
                                                mdblCDelta(7) = FractionaltoDouble(nTemp)
                                                strTemp = ChrW(bytRxData(8)) & ChrW(bytRxData(9)) & ChrW(bytRxData(10)) 'Get the title.
                                                LabelC8Val.Text = CStr(mdblC(7))         'Display the current value.
                                                LabelC8.Text = strTemp                   'Display the title.

                                            Case 9 'Coefficient 9
                                                nTemp = bytRxData(4)                     ' Get upper byte of data.
                                                nTemp = (nTemp << 8) + bytRxData(5)      ' Get lower byte of data and form 16 bits word.
                                                mdblC(8) = FractionaltoDouble(nTemp)
                                                nTemp = bytRxData(6)                     ' Get upper byte of data.
                                                nTemp = (nTemp << 8) + bytRxData(7)      ' Get lower byte of data and form 16 bits word.
                                                mdblCDelta(8) = FractionaltoDouble(nTemp)
                                                strTemp = ChrW(bytRxData(8)) & ChrW(bytRxData(9)) & ChrW(bytRxData(10)) 'Get the title.
                                                LabelC9Val.Text = CStr(mdblC(8))         'Display the current value.
                                                LabelC9.Text = strTemp                   'Display the title.

                                            Case 10 'Coefficient 10
                                                nTemp = bytRxData(4)                     ' Get upper byte of data.
                                                nTemp = (nTemp << 8) + bytRxData(5)      ' Get lower byte of data and form 16 bits word.
                                                mdblC(9) = FractionaltoDouble(nTemp)
                                                nTemp = bytRxData(6)                     ' Get upper byte of data.
                                                nTemp = (nTemp << 8) + bytRxData(7)      ' Get lower byte of data and form 16 bits word.
                                                mdblCDelta(9) = FractionaltoDouble(nTemp)
                                                strTemp = ChrW(bytRxData(8)) & ChrW(bytRxData(9)) & ChrW(bytRxData(10)) 'Get the title.
                                                LabelC10Val.Text = CStr(mdblC(9))         'Display the current value.
                                                LabelC10.Text = strTemp                   'Display the title.

                                            Case Else

                                        End Select
                                    ElseIf bytRxData(2) = _COEFFICENT_INFO Then         'Physical parameters of robot.
                                        nTemp = bytRxData(3)                            'This gives rotation angle (in degree) per 100 ticks.
                                        mdblTurnAngleDegPerUnit = nTemp / 100
                                        TurnAnglePerUnitLabel.Text = CStr(mdblTurnAngleDegPerUnit)
                                        mdblWheelDiameterMM = bytRxData(4)              'This gives the wheel diameter in mm.
                                        nTemp = bytRxData(5)                            'This gives the no. of encoder ticks per rotation.
                                        mdblRotationAnglePerAverageTick = 360 / nTemp   'This gives the rotation angle in degree for tick.
                                        DegPerWheelTickLabel.Text = CStr(-mdblRotationAnglePerAverageTick)

                                    End If 'If bytRxData(2) = _TUNABLE_COEFFICIENT_INFO
                                End If 'bytRxData(1) = _COMMAND
                            End If 'If (bytRxData(0) = bytSlaveID)
                        End If 'If gnDataReceiveFlag = 1 

                        mintState = 3

                    Case 4 'Main transmission routine for ASCII Data
                        bytTxData(0) = bytSlaveID

                        bytTxData(1) = _DATA_ASCII
                        bytTxData(2) = mbytRFCommand
                        bytTxData(3) = mbytRFArgument
                        bytTxData(4) = mbytRFArgument2
                        SerialPort1.Write(bytTxData, 0, 5)  'Write 5 bytes of data to serial port.
                        mintState = 3

                    Case 5 'Main transmission routine for Command
                        bytTxData(0) = bytSlaveID
                        bytTxData(1) = _COMMAND
                        bytTxData(2) = mbytRFCommand
                        bytTxData(3) = mbytRFArgument
                        bytTxData(4) = mbytRFArgument2
                        SerialPort1.Write(bytTxData, 0, 5)  'Write 5 bytes of data to serial port.
                        mintState = 3

                    Case Else
                        mintState = 0 'Return to state 0.

                End Select

            End If
        Catch ex As Exception
            MessageBox.Show("Timer1_Tick: " & ex.Message, "ERROR", MessageBoxButtons.OK)
        End Try

    End Sub

    'Purpose : Function to convert fractional Q8.8 format to double.
    'Date    : 27 Aug 2015
    'Author  : F. Kung
    'Requires: shrtQ8_8 = Q8.8 input in 32-bits integer format.
    'Returns : Double.
    'Descriptions: Convert fixed point number in Q8.8 format to double.
    Private Function FractionaltoDouble(ByVal shrtQ8_8 As Integer) As Double

        Dim dblTemp As Double

        dblTemp = 0.0

        If ((shrtQ8_8 And &H1) > 0) Then  'Test bit 0.
            dblTemp = 0.00390625
        End If
        If ((shrtQ8_8 And &H2) > 0) Then  'Test bit 1.
            dblTemp = dblTemp + 0.0078125
        End If
        If ((shrtQ8_8 And &H4) > 0) Then  'Test bit 2.
            dblTemp = dblTemp + 0.015625
        End If
        If ((shrtQ8_8 And &H8) > 0) Then  'Test bit 3.
            dblTemp = dblTemp + 0.03125
        End If
        If ((shrtQ8_8 And &H10) > 0) Then  'Test bit 4.
            dblTemp = dblTemp + 0.0625
        End If
        If ((shrtQ8_8 And &H20) > 0) Then  'Test bit 5.
            dblTemp = dblTemp + 0.125
        End If
        If ((shrtQ8_8 And &H40) > 0) Then  'Test bit 6.
            dblTemp = dblTemp + 0.25
        End If
        If ((shrtQ8_8 And &H80) > 0) Then  'Test bit 7.
            dblTemp = dblTemp + 0.5
        End If
        If ((shrtQ8_8 And &H100) > 0) Then  'Test bit 8.
            dblTemp = dblTemp + 1
        End If
        If ((shrtQ8_8 And &H200) > 0) Then  'Test bit 9.
            dblTemp = dblTemp + 2
        End If
        If ((shrtQ8_8 And &H400) > 0) Then  'Test bit 10.
            dblTemp = dblTemp + 4
        End If
        If ((shrtQ8_8 And &H800) > 0) Then  'Test bit 11.
            dblTemp = dblTemp + 8
        End If
        If ((shrtQ8_8 And &H1000) > 0) Then  'Test bit 12.
            dblTemp = dblTemp + 16
        End If
        If ((shrtQ8_8 And &H2000) > 0) Then  'Test bit 13.
            dblTemp = dblTemp + 32
        End If
        If ((shrtQ8_8 And &H4000) > 0) Then  'Test bit 14.
            dblTemp = dblTemp + 64
        End If
        If ((shrtQ8_8 And &H8000) > 0) Then  'Test bit 15.
            dblTemp = dblTemp - 128
        End If
        Return dblTemp

    End Function

    'Purpose : Function to display a string of text on the main display.
    'Date    : 20 September 2009
    'Author  : F. Kung
    'Requires: An array of bytes and the text color.
    'Returns : None.
    'Example of usage:
    ' Dim strRxData as string
    '
    ' strRxData = "Hello"
    ' ShowTextData(strRxData, Me.ForeColor) 
    '
    Private Sub ShowTextData(ByRef strText As String, ByRef TextColor As Color)

        Static Dim mintLinePointer As Integer
        Const _NUMBEROFLINES = 16

        MainRichTextBox.ForeColor = TextColor 'Set text color.
        mintLinePointer = mintLinePointer + 1 'Update line pointer.
        If (mintLinePointer > _NUMBEROFLINES) Then  'Limit to _NUMBEROFLINES lines to display.
            MainRichTextBox.Clear() 'Clear text box.
            mintLinePointer = 0 'Reset string array pointer.  Line zero refers to last line.
        End If
        MainRichTextBox.AppendText(strText & Chr(13)) 'Display a line, end with newline character.
    End Sub

    'Purpose : Function to display a numeric data on the secondary display.
    'Date    : 29 Dec 2018
    'Author  : F. Kung
    'Requires: intInput1 = input data 1 (16 bits unsigned integer). Display 1
    '          intInput2 = input data 2 (16 bits unsigned integer). Display 1
    '          intInput3 = input data 3 (16 bits unsigned integer). Display 1
    '          intInput4 = input data 4 (16 bits unsigned integer). Display 2
    '          intInput5 = input data 5 (16 bits unsigned integer). Display 2
    '          intInput6 = input data 6 (16 bits unsigned integer). Display 2
    '
    'Returns : None.
    'Descriptions:
    'This routine is used to show the instantaneous value of 6 inputs on the 2 XY plots, called Plot 1 and Plot 2.
    'intInput1 to intInput3 are plotted in XY plot 1, while intInput4 to intInput6 are plotted in XY plot 2.
    'The data to be plotted is normalized to real value between -1.0 to +1.0 before being plotted.
    Private Sub UpdateLevelIndicator(ByRef intInput11 As Integer, ByRef intInput12 As Integer, ByRef intInput13 As Integer, ByRef intInput14 As Integer,
                                     ByRef intInput21 As Integer, ByRef intInput22 As Integer, ByRef intInput23 As Integer, ByRef intInput24 As Integer)

        Const _MAX_DATA11 = 32768      'Maximum variation for data11, for 16 bits unsigned integer.
        Const _OFFSET_DATA11 = 32768   'Offset for data11.
        Const _MAX_DATA12 = 32768      'Maximum variation for data12, for 16 bits unsigned integer.
        Const _OFFSET_DATA12 = 32768   'Offset for data12.
        Const _MAX_DATA13 = 32768      'Maximum variation for data13, for 16 bits unsigned integer.
        Const _OFFSET_DATA13 = 32768   'Offset for data13.
        Const _MAX_DATA14 = 32768      'Maximum variation for data14, for 16 bits unsigned integer.
        Const _OFFSET_DATA14 = 32768   'Offset for data14.
        Const _MAX_DATA21 = 32768      'Maximum variation for data21, for 16 bits unsigned integer.
        Const _OFFSET_DATA21 = 32768   'Offset for data21.
        Const _MAX_DATA22 = 32768      'Maximum variation for data22, for 16 bits unsigned integer.
        Const _OFFSET_DATA22 = 32768   'Offset for data22.
        Const _MAX_DATA23 = 32768      'Maximum variation for data23, for 16 bits unsigned integer.
        Const _OFFSET_DATA23 = 32768   'Offset for data23.
        Const _MAX_DATA24 = 32768      'Maximum variation for data24, for 16 bits unsigned integer.
        Const _OFFSET_DATA24 = 32768   'Offset for data24.

        Dim dblTemp11 As Double        'Trace data for Plot 1.   
        Dim dblTemp12 As Double
        Dim dblTemp13 As Double
        Dim dblTemp14 As Double

        Dim dblTemp21 As Double       'Trace data for Plot 2.
        Dim dblTemp22 As Double
        Dim dblTemp23 As Double
        Dim dblTemp24 As Double

        'Normalize data to between -1 to +1 for plotting on XY plots.
        dblTemp11 = CDbl(intInput11 - _OFFSET_DATA11) / _MAX_DATA11
        dblTemp12 = CDbl(intInput12 - _OFFSET_DATA12) / _MAX_DATA12
        dblTemp13 = CDbl(intInput13 - _OFFSET_DATA13) / _MAX_DATA13
        dblTemp14 = CDbl(intInput14 - _OFFSET_DATA14) / _MAX_DATA14

        dblTemp21 = CDbl(intInput21 - _OFFSET_DATA21) / _MAX_DATA21
        dblTemp22 = CDbl(intInput22 - _OFFSET_DATA22) / _MAX_DATA22
        dblTemp23 = CDbl(intInput23 - _OFFSET_DATA23) / _MAX_DATA23
        dblTemp24 = CDbl(intInput24 - _OFFSET_DATA24) / _MAX_DATA24

        mfrmXYplot1.dblDatain1 = dblTemp11 'Plot 4 traces for XY chart 1.
        mfrmXYplot1.dblDatain2 = dblTemp12
        mfrmXYplot1.dblDatain3 = dblTemp13
        mfrmXYplot1.dblDatain4 = dblTemp14
        mfrmXYplot1.blnPlot = vbYes
        mfrmXYplot1.Refresh()

        mfrmXYplot2.dblDatain1 = dblTemp21 'Plot 4 traces for XY chart 2.
        mfrmXYplot2.dblDatain2 = dblTemp22
        mfrmXYplot2.dblDatain3 = dblTemp23
        mfrmXYplot2.dblDatain4 = dblTemp24
        mfrmXYplot2.blnPlot = vbYes
        mfrmXYplot2.Refresh()
    End Sub


    Private Sub ButonC1Up_Click(sender As Object, e As EventArgs) Handles ButonC1Up.Click

        If TrackBarC1.Value < TrackBarC1.Maximum Then 'Make sure no overflow!   
            mdblC(0) = mdblC(0) + mdblCDelta(0)             'Compute current coefficient value.
            TrackBarC1.Value = TrackBarC1.Value + 1         'Update trackbar position.
            mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
            mbytRFArgument = 0                              'Indicate coefficient 0
            mbytRFArgument2 = TrackBarC1.Value              'Note: The remote slave should know the starting value of the coefficient and 
            mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
            'the latest coefficient value can be determined.
            LabelC1Val.Text = CStr(mdblC(0))                'Update the coefficient value display.
            mintCTrackBarValueBackUp(0) = TrackBarC1.Value  'Backup current value of Trackbar.
        End If

    End Sub

    Private Sub ButtonC1Down_Click(sender As Object, e As EventArgs) Handles ButtonC1Down.Click

        If TrackBarC1.Value > TrackBarC1.Minimum Then 'Make sure no underflow!
            mdblC(0) = mdblC(0) - mdblCDelta(0)             'Compute current coefficient value.
            TrackBarC1.Value = TrackBarC1.Value - 1         'Update trackbar position.
            mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
            mbytRFArgument = 0                              'Indicate coefficient 0
            mbytRFArgument2 = TrackBarC1.Value              'Note: The remote slave should know the starting value of the coefficient and 
            mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
            'the latest coefficient value can be determined.
            LabelC1Val.Text = CStr(mdblC(0))                'Update the coefficient value display.
            mintCTrackBarValueBackUp(0) = TrackBarC1.Value  'Backup current value of Trackbar.
        End If

    End Sub

    Private Sub ButtonC2Up_Click(sender As Object, e As EventArgs) Handles ButtonC2Up.Click

        If TrackBarC2.Value < TrackBarC2.Maximum Then 'Make sure no overflow!
            mdblC(1) = mdblC(1) + mdblCDelta(1)             'Compute current coefficient value.
            TrackBarC2.Value = TrackBarC2.Value + 1         'Update trackbar position.
            mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
            mbytRFArgument = 1                              'Indicate coefficient 1
            mbytRFArgument2 = TrackBarC2.Value              'Note: The remote slave should know the starting value of the coefficient and 
            mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
            'the latest coefficient value can be determined.
            LabelC2Val.Text = CStr(mdblC(1))                'Update the coefficient value display.
            mintCTrackBarValueBackUp(1) = TrackBarC2.Value  'Backup current value of Trackbar.  
        End If

    End Sub

    Private Sub ButtonC2Down_Click(sender As Object, e As EventArgs) Handles ButtonC2Down.Click

        If TrackBarC2.Value > TrackBarC2.Minimum Then 'Make sure no underflow!
            mdblC(1) = mdblC(1) - mdblCDelta(1)             'Compute current coefficient value.
            TrackBarC2.Value = TrackBarC2.Value - 1         'Update trackbar position.
            mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
            mbytRFArgument = 1                              'Indicate coefficient 1
            mbytRFArgument2 = TrackBarC2.Value              'Note: The remote slave should know the starting value of the coefficient and 
            mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
            'the latest coefficient value can be determined.
            LabelC2Val.Text = CStr(mdblC(1))                'Update the coefficient value display.
            mintCTrackBarValueBackUp(1) = TrackBarC2.Value  'Backup current value of Trackbar.
        End If

    End Sub

    Private Sub ButtonC3Up_Click(sender As Object, e As EventArgs) Handles ButtonC3Up.Click

        If TrackBarC3.Value < TrackBarC3.Maximum Then 'Make sure no overflow!
            mdblC(2) = mdblC(2) + mdblCDelta(2)             'Compute current coefficient value.
            TrackBarC3.Value = TrackBarC3.Value + 1         'Update trackbar position.
            mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
            mbytRFArgument = 2                              'Indicate coefficient 2
            mbytRFArgument2 = TrackBarC3.Value              'Note: The remote slave should know the starting value of the coefficient and 
            mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
            'the latest coefficient value can be determined.
            LabelC3Val.Text = CStr(mdblC(2))                'Update the coefficient value display.
            mintCTrackBarValueBackUp(2) = TrackBarC3.Value  'Backup current value of Trackbar.   
        End If

    End Sub

    Private Sub ButtonC3Down_Click(sender As Object, e As EventArgs) Handles ButtonC3Down.Click

        If TrackBarC3.Value > TrackBarC3.Minimum Then 'Make sure no underflow!
            mdblC(2) = mdblC(2) - mdblCDelta(2)             'Compute current coefficient value.
            TrackBarC3.Value = TrackBarC3.Value - 1         'Update trackbar position.
            mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
            mbytRFArgument = 2                              'Indicate coefficient 2
            mbytRFArgument2 = TrackBarC3.Value              'Note: The remote slave should know the starting value of the coefficient and 
            mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
            'the latest coefficient value can be determined.
            LabelC3Val.Text = CStr(mdblC(2))                'Update the coefficient value display.
            mintCTrackBarValueBackUp(2) = TrackBarC3.Value  'Backup current value of Trackbar.
        End If

    End Sub

    Private Sub ButtonC4Up_Click(sender As Object, e As EventArgs) Handles ButtonC4Up.Click

        If TrackBarC4.Value < TrackBarC4.Maximum Then 'Make sure no overflow!
            mdblC(3) = mdblC(3) + mdblCDelta(3)             'Compute current coefficient value.
            TrackBarC4.Value = TrackBarC4.Value + 1         'Update trackbar position.
            mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
            mbytRFArgument = 3                              'Indicate coefficient 3
            mbytRFArgument2 = TrackBarC4.Value              'Note: The remote slave should know the starting value of the coefficient and 
            mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
            'the latest coefficient value can be determined.
            LabelC4Val.Text = CStr(mdblC(3))                'Update the coefficient value display.
            mintCTrackBarValueBackUp(3) = TrackBarC4.Value  'Backup current value of Trackbar. 
        End If

    End Sub

    Private Sub ButtonC4Down_Click(sender As Object, e As EventArgs) Handles ButtonC4Down.Click

        If TrackBarC4.Value > TrackBarC4.Minimum Then 'Make sure no underflow!
            mdblC(3) = mdblC(3) - mdblCDelta(3)             'Compute current coefficient value.
            TrackBarC4.Value = TrackBarC4.Value - 1         'Update trackbar position.
            mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
            mbytRFArgument = 3                              'Indicate coefficient 3
            mbytRFArgument2 = TrackBarC4.Value              'Note: The remote slave should know the starting value of the coefficient and 
            mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
            'the latest coefficient value can be determined.
            LabelC4Val.Text = CStr(mdblC(3))                'Update the coefficient value display.
            mintCTrackBarValueBackUp(3) = TrackBarC4.Value  'Backup current value of Trackbar.
        End If

    End Sub

    Private Sub ButtonC5Up_Click(sender As Object, e As EventArgs) Handles ButtonC5Up.Click

        If TrackBarC5.Value < TrackBarC5.Maximum Then 'Make sure no overflow!
            mdblC(4) = mdblC(4) + mdblCDelta(4)             'Compute current coefficient value.
            TrackBarC5.Value = TrackBarC5.Value + 1         'Update trackbar position.
            mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
            mbytRFArgument = 4                              'Indicate coefficient 4
            mbytRFArgument2 = TrackBarC5.Value              'Note: The remote slave should know the starting value of the coefficient and 
            mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
            'the latest coefficient value can be determined.
            LabelC5Val.Text = CStr(mdblC(4))                'Update the coefficient value display.
            mintCTrackBarValueBackUp(4) = TrackBarC5.Value  'Backup current value of Trackbar. 
        End If

    End Sub

    Private Sub ButtonC5Down_Click(sender As Object, e As EventArgs) Handles ButtonC5Down.Click

        If TrackBarC5.Value > TrackBarC5.Minimum Then 'Make sure no underflow!
            mdblC(4) = mdblC(4) - mdblCDelta(4)             'Compute current coefficient value.
            TrackBarC5.Value = TrackBarC5.Value - 1         'Update trackbar position.
            mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
            mbytRFArgument = 4                              'Indicate coefficient 4
            mbytRFArgument2 = TrackBarC5.Value              'Note: The remote slave should know the starting value of the coefficient and 
            mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
            'the latest coefficient value can be determined.
            LabelC5Val.Text = CStr(mdblC(4))                'Update the coefficient value display.
            mintCTrackBarValueBackUp(4) = TrackBarC5.Value  'Backup current value of Trackbar.
        End If

    End Sub

    Private Sub ButtonC6Up_Click(sender As Object, e As EventArgs) Handles ButtonC6Up.Click

        If TrackBarC6.Value < TrackBarC6.Maximum Then 'Make sure no overflow!
            mdblC(5) = mdblC(5) + mdblCDelta(5)             'Compute current coefficient value.
            TrackBarC6.Value = TrackBarC6.Value + 1         'Update trackbar position.
            mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
            mbytRFArgument = 5                              'Indicate coefficient 5
            mbytRFArgument2 = TrackBarC6.Value              'Note: The remote slave should know the starting value of the coefficient and 
            mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
            'the latest coefficient value can be determined.
            LabelC6Val.Text = CStr(mdblC(5))                'Update the coefficient value display.
            mintCTrackBarValueBackUp(5) = TrackBarC6.Value  'Backup current value of Trackbar.
        End If

    End Sub

    Private Sub ButtonC6Down_Click(sender As Object, e As EventArgs) Handles ButtonC6Down.Click

        If TrackBarC6.Value > TrackBarC6.Minimum Then 'Make sure no underflow!
            mdblC(5) = mdblC(5) - mdblCDelta(5)             'Compute current coefficient value.
            TrackBarC6.Value = TrackBarC6.Value - 1         'Update trackbar position.
            mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
            mbytRFArgument = 5                              'Indicate coefficient 5
            mbytRFArgument2 = TrackBarC6.Value              'Note: The remote slave should know the starting value of the coefficient and 
            mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
            'the latest coefficient value can be determined.
            LabelC6Val.Text = CStr(mdblC(5))                'Update the coefficient value display.
            mintCTrackBarValueBackUp(5) = TrackBarC6.Value  'Backup current value of Trackbar.
        End If

    End Sub

    Private Sub ButtonC7Up_Click(sender As Object, e As EventArgs) Handles ButtonC7Up.Click

        If TrackBarC7.Value < TrackBarC7.Maximum Then 'Make sure no overflow!
            mdblC(6) = mdblC(6) + mdblCDelta(6)             'Compute current coefficient value.
            TrackBarC7.Value = TrackBarC7.Value + 1         'Update trackbar position.
            mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
            mbytRFArgument = 6                              'Indicate coefficient 6
            mbytRFArgument2 = TrackBarC7.Value              'Note: The remote slave should know the starting value of the coefficient and 
            mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
            'the latest coefficient value can be determined.
            LabelC7Val.Text = CStr(mdblC(6))                'Update the coefficient value display.
            mintCTrackBarValueBackUp(6) = TrackBarC7.Value  'Backup current value of Trackbar.
        End If

    End Sub

    Private Sub ButtonC7Down_Click(sender As Object, e As EventArgs) Handles ButtonC7Down.Click

        If TrackBarC7.Value > TrackBarC7.Minimum Then 'Make sure no underflow!
            mdblC(6) = mdblC(6) - mdblCDelta(6)             'Compute current coefficient value.
            TrackBarC7.Value = TrackBarC7.Value - 1         'Update trackbar position.
            mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
            mbytRFArgument = 6                              'Indicate coefficient 6
            mbytRFArgument2 = TrackBarC7.Value              'Note: The remote slave should know the starting value of the coefficient and 
            mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
            'the latest coefficient value can be determined.
            LabelC7Val.Text = CStr(mdblC(6))                'Update the coefficient value display.
            mintCTrackBarValueBackUp(6) = TrackBarC7.Value  'Backup current value of Trackbar. 
        End If

    End Sub

    Private Sub ButtonC8Up_Click(sender As Object, e As EventArgs) Handles ButtonC8Up.Click

        If TrackBarC8.Value < TrackBarC8.Maximum Then 'Make sure no overflow!
            mdblC(7) = mdblC(7) + mdblCDelta(7)             'Compute current coefficient value.
            TrackBarC8.Value = TrackBarC8.Value + 1         'Update trackbar position.
            mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
            mbytRFArgument = 7                              'Indicate coefficient 7
            mbytRFArgument2 = TrackBarC8.Value              'Note: The remote slave should know the starting value of the coefficient and 
            mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
            'the latest coefficient value can be determined.
            LabelC8Val.Text = CStr(mdblC(7))                'Update the coefficient value display.
            mintCTrackBarValueBackUp(7) = TrackBarC8.Value  'Backup current value of Trackbar.
        End If

    End Sub

    Private Sub ButtonC8Down_Click(sender As Object, e As EventArgs) Handles ButtonC8Down.Click

        If TrackBarC8.Value > TrackBarC8.Minimum Then 'Make sure no underflow!
            mdblC(7) = mdblC(7) - mdblCDelta(7)             'Compute current coefficient value.
            TrackBarC8.Value = TrackBarC8.Value - 1         'Update trackbar position.
            mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
            mbytRFArgument = 7                             'Indicate coefficient 7
            mbytRFArgument2 = TrackBarC8.Value              'Note: The remote slave should know the starting value of the coefficient and 
            mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
            'the latest coefficient value can be determined.
            LabelC8Val.Text = CStr(mdblC(7))                'Update the coefficient value display.
            mintCTrackBarValueBackUp(7) = TrackBarC8.Value  'Backup current value of Trackbar. 
        End If

    End Sub

    Private Sub ButtonC9Up_Click(sender As Object, e As EventArgs) Handles ButtonC9Up.Click

        If TrackBarC9.Value < TrackBarC9.Maximum Then 'Make sure no overflow!
            mdblC(8) = mdblC(8) + mdblCDelta(8)             'Compute current coefficient value.
            TrackBarC9.Value = TrackBarC9.Value + 1         'Update trackbar position.
            mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
            mbytRFArgument = 8                              'Indicate coefficient 8
            mbytRFArgument2 = TrackBarC9.Value              'Note: The remote slave should know the starting value of the coefficient and 
            mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
            'the latest coefficient value can be determined.
            LabelC9Val.Text = CStr(mdblC(8))                'Update the coefficient value display.
            mintCTrackBarValueBackUp(8) = TrackBarC9.Value  'Backup current value of Trackbar.
        End If

    End Sub

    Private Sub ButtonC9Down_Click(sender As Object, e As EventArgs) Handles ButtonC9Down.Click

        If TrackBarC9.Value > TrackBarC9.Minimum Then 'Make sure no underflow!
            mdblC(8) = mdblC(8) - mdblCDelta(8)             'Compute current coefficient value.
            TrackBarC9.Value = TrackBarC9.Value - 1         'Update trackbar position.
            mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
            mbytRFArgument = 8                             'Indicate coefficient 8
            mbytRFArgument2 = TrackBarC9.Value              'Note: The remote slave should know the starting value of the coefficient and 
            mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
            'the latest coefficient value can be determined.
            LabelC9Val.Text = CStr(mdblC(8))                'Update the coefficient value display.
            mintCTrackBarValueBackUp(8) = TrackBarC9.Value  'Backup current value of Trackbar.
        End If

    End Sub

    Private Sub ButtonC10Up_Click(sender As Object, e As EventArgs) Handles ButtonC10Up.Click

        If TrackBarC10.Value < TrackBarC10.Maximum Then 'Make sure no overflow!
            mdblC(9) = mdblC(9) + mdblCDelta(9)             'Compute current coefficient value.
            TrackBarC10.Value = TrackBarC10.Value + 1         'Update trackbar position.
            mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
            mbytRFArgument = 9                              'Indicate coefficient 9
            mbytRFArgument2 = TrackBarC10.Value              'Note: The remote slave should know the starting value of the coefficient and 
            mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
            'the latest coefficient value can be determined.
            LabelC10Val.Text = CStr(mdblC(9))                'Update the coefficient value display.
            mintCTrackBarValueBackUp(9) = TrackBarC10.Value  'Backup current value of Trackbar.
        End If

    End Sub

    Private Sub ButtonC10Down_Click(sender As Object, e As EventArgs) Handles ButtonC10Down.Click

        If TrackBarC10.Value > TrackBarC10.Minimum Then 'Make sure no underflow!
            mdblC(9) = mdblC(9) - mdblCDelta(9)             'Compute current coefficient value.
            TrackBarC10.Value = TrackBarC10.Value - 1         'Update trackbar position.
            mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
            mbytRFArgument = 9                             'Indicate coefficient 9
            mbytRFArgument2 = TrackBarC10.Value              'Note: The remote slave should know the starting value of the coefficient and 
            mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
            'the latest coefficient value can be determined.
            LabelC10Val.Text = CStr(mdblC(9))                'Update the coefficient value display.
            mintCTrackBarValueBackUp(9) = TrackBarC10.Value  'Backup current value of Trackbar.
        End If

    End Sub

    Private Sub TrackBarC1_Scroll(sender As Object, e As EventArgs) Handles TrackBarC1.Scroll

        Dim nDelta As Integer

        nDelta = TrackBarC1.Value - mintCTrackBarValueBackUp(0) 'Compute the change in trackbar value.
        mdblC(0) = mdblC(0) + (nDelta * mdblCDelta(0))  'Compute current coefficient value based on changes in trackbar position.

        mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
        mbytRFArgument = 0  'Indicate coefficient 0
        mbytRFArgument2 = TrackBarC1.Value              'Note: The remote slave should know the starting value of the coefficient and 
        mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
        'the latest coefficient value can be determined.
        LabelC1Val.Text = CStr(mdblC(0))                'Update the coefficient value display.
        mintCTrackBarValueBackUp(0) = TrackBarC1.Value  'Backup current value of Trackbar.

    End Sub

    Private Sub TrackBarC2_Scroll(sender As Object, e As EventArgs) Handles TrackBarC2.Scroll

        Dim nDelta As Integer

        nDelta = TrackBarC2.Value - mintCTrackBarValueBackUp(1) 'Compute the change in trackbar value.
        mdblC(1) = mdblC(1) + (nDelta * mdblCDelta(1))  'Compute current coefficient value based on changes in trackbar position.

        mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
        mbytRFArgument = 1  'Indicate coefficient 1
        mbytRFArgument2 = TrackBarC2.Value              'Note: The remote slave should know the starting value of the coefficient and 
        mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
        'the latest coefficient value can be determined.
        LabelC2Val.Text = CStr(mdblC(1))                'Update the coefficient value display.
        mintCTrackBarValueBackUp(1) = TrackBarC2.Value  'Backup current value of Trackbar.

    End Sub

    Private Sub TrackBarC3_Scroll(sender As Object, e As EventArgs) Handles TrackBarC3.Scroll

        Dim nDelta As Integer

        nDelta = TrackBarC3.Value - mintCTrackBarValueBackUp(2) 'Compute the change in trackbar value.
        mdblC(2) = mdblC(2) + (nDelta * mdblCDelta(2))  'Compute current coefficient value based on changes in trackbar position.

        mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
        mbytRFArgument = 2  'Indicate coefficient 2
        mbytRFArgument2 = TrackBarC3.Value              'Note: The remote slave should know the starting value of the coefficient and 
        mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
        'the latest coefficient value can be determined.
        LabelC3Val.Text = CStr(mdblC(2))                'Update the coefficient value display.
        mintCTrackBarValueBackUp(2) = TrackBarC3.Value  'Backup current value of Trackbar.

    End Sub

    Private Sub TrackBarC4_Scroll(sender As Object, e As EventArgs) Handles TrackBarC4.Scroll

        Dim nDelta As Integer

        nDelta = TrackBarC4.Value - mintCTrackBarValueBackUp(3) 'Compute the change in trackbar value.
        mdblC(3) = mdblC(3) + (nDelta * mdblCDelta(3))  'Compute current coefficient value based on changes in trackbar position.

        mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
        mbytRFArgument = 3  'Indicate coefficient 3
        mbytRFArgument2 = TrackBarC4.Value              'Note: The remote slave should know the starting value of the coefficient and 
        mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
        'the latest coefficient value can be determined.
        LabelC4Val.Text = CStr(mdblC(3))                'Update the coefficient value display.
        mintCTrackBarValueBackUp(3) = TrackBarC4.Value  'Backup current value of Trackbar.

    End Sub

    Private Sub TrackBarC5_Scroll(sender As Object, e As EventArgs) Handles TrackBarC5.Scroll

        Dim nDelta As Integer

        nDelta = TrackBarC5.Value - mintCTrackBarValueBackUp(4) 'Compute the change in trackbar value.
        mdblC(4) = mdblC(4) + (nDelta * mdblCDelta(4))  'Compute current coefficient value based on changes in trackbar position.

        mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
        mbytRFArgument = 4  'Indicate coefficient 4
        mbytRFArgument2 = TrackBarC5.Value              'Note: The remote slave should know the starting value of the coefficient and 
        mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
        'the latest coefficient value can be determined.
        LabelC5Val.Text = CStr(mdblC(4))                'Update the coefficient value display.
        mintCTrackBarValueBackUp(4) = TrackBarC5.Value  'Backup current value of Trackbar.

    End Sub

    Private Sub TrackBarC6_Scroll(sender As Object, e As EventArgs) Handles TrackBarC6.Scroll

        Dim nDelta As Integer

        nDelta = TrackBarC6.Value - mintCTrackBarValueBackUp(5) 'Compute the change in trackbar value.
        mdblC(5) = mdblC(5) + (nDelta * mdblCDelta(5))  'Compute current coefficient value based on changes in trackbar position.

        mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
        mbytRFArgument = 5  'Indicate coefficient 5
        mbytRFArgument2 = TrackBarC6.Value              'Note: The remote slave should know the starting value of the coefficient and 
        mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
        'the latest coefficient value can be determined.
        LabelC6Val.Text = CStr(mdblC(5))                'Update the coefficient value display.
        mintCTrackBarValueBackUp(5) = TrackBarC6.Value  'Backup current value of Trackbar.

    End Sub

    Private Sub TrackBarC7_Scroll(sender As Object, e As EventArgs) Handles TrackBarC7.Scroll

        Dim nDelta As Integer

        nDelta = TrackBarC7.Value - mintCTrackBarValueBackUp(6) 'Compute the change in trackbar value.
        mdblC(6) = mdblC(6) + (nDelta * mdblCDelta(6))  'Compute current coefficient value based on changes in trackbar position.

        mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
        mbytRFArgument = 6  'Indicate coefficient 6
        mbytRFArgument2 = TrackBarC7.Value              'Note: The remote slave should know the starting value of the coefficient and 
        mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
        'the latest coefficient value can be determined.
        LabelC7Val.Text = CStr(mdblC(6))                'Update the coefficient value display.
        mintCTrackBarValueBackUp(6) = TrackBarC7.Value  'Backup current value of Trackbar.

    End Sub

    Private Sub TrackBarC8_Scroll(sender As Object, e As EventArgs) Handles TrackBarC8.Scroll

        Dim nDelta As Integer

        nDelta = TrackBarC8.Value - mintCTrackBarValueBackUp(7) 'Compute the change in trackbar value.
        mdblC(7) = mdblC(7) + (nDelta * mdblCDelta(7))  'Compute current coefficient value based on changes in trackbar position.

        mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
        mbytRFArgument = 7  'Indicate coefficient 7
        mbytRFArgument2 = TrackBarC8.Value              'Note: The remote slave should know the starting value of the coefficient and 
        mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
        'the latest coefficient value can be determined.
        LabelC8Val.Text = CStr(mdblC(7))                'Update the coefficient value display.
        mintCTrackBarValueBackUp(7) = TrackBarC8.Value  'Backup current value of Trackbar.

    End Sub

    Private Sub TrackBarC9_Scroll(sender As Object, e As EventArgs) Handles TrackBarC9.Scroll

        Dim nDelta As Integer

        nDelta = TrackBarC9.Value - mintCTrackBarValueBackUp(8) 'Compute the change in trackbar value.
        mdblC(8) = mdblC(8) + (nDelta * mdblCDelta(8))  'Compute current coefficient value based on changes in trackbar position.

        mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
        mbytRFArgument = 8  'Indicate coefficient 8
        mbytRFArgument2 = TrackBarC9.Value              'Note: The remote slave should know the starting value of the coefficient and 
        mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
        'the latest coefficient value can be determined.
        LabelC9Val.Text = CStr(mdblC(8))                'Update the coefficient value display.
        mintCTrackBarValueBackUp(8) = TrackBarC9.Value  'Backup current value of Trackbar.

    End Sub

    Private Sub TrackBarC10_Scroll(sender As Object, e As EventArgs) Handles TrackBarC10.Scroll

        Dim nDelta As Integer

        nDelta = TrackBarC10.Value - mintCTrackBarValueBackUp(9) 'Compute the change in trackbar value.
        mdblC(9) = mdblC(9) + (nDelta * mdblCDelta(9))  'Compute current coefficient value based on changes in trackbar position.

        mbytRFCommand = _SET_COEFFICIENT                'Send command to remote slave to adjust coefficient.
        mbytRFArgument = 9  'Indicate coefficient 9
        mbytRFArgument2 = TrackBarC10.Value              'Note: The remote slave should know the starting value of the coefficient and 
        mintState = 5                                   'also the trackbar position.  Thus using these and the current trackbar value,
        'the latest coefficient value can be determined.
        LabelC10Val.Text = CStr(mdblC(9))                'Update the coefficient value display.
        mintCTrackBarValueBackUp(9) = TrackBarC10.Value  'Backup current value of Trackbar.

    End Sub


    Private Sub ButtonStore_Click(sender As Object, e As EventArgs) Handles ButtonStore.Click

        Dim nTemp As Integer

        'Backup all coefficients and Trackbar values.
        For nTemp = 0 To 9
            mdblCRes(mintMotorSequenceNo)(nTemp) = mdblC(nTemp)
        Next
        mintTrackBarValueRes(mintMotorSequenceNo)(0) = TrackBarC1.Value
        mintTrackBarValueRes(mintMotorSequenceNo)(1) = TrackBarC2.Value
        mintTrackBarValueRes(mintMotorSequenceNo)(2) = TrackBarC3.Value
        mintTrackBarValueRes(mintMotorSequenceNo)(3) = TrackBarC4.Value
        mintTrackBarValueRes(mintMotorSequenceNo)(4) = TrackBarC5.Value
        mintTrackBarValueRes(mintMotorSequenceNo)(5) = TrackBarC6.Value
        mintTrackBarValueRes(mintMotorSequenceNo)(6) = TrackBarC7.Value
        mintTrackBarValueRes(mintMotorSequenceNo)(7) = TrackBarC8.Value
        mintTrackBarValueRes(mintMotorSequenceNo)(8) = TrackBarC9.Value
        mintTrackBarValueRes(mintMotorSequenceNo)(9) = TrackBarC10.Value

        mintMotorSequenceNo = mintMotorSequenceNo + 1
        If (mintMotorSequenceNo > _MAX_COEFF_SEQUENCE) Then
            mintMotorSequenceNo = _MAX_COEFF_SEQUENCE
        End If

        LabelMotorSequence.Text = CStr(mintMotorSequenceNo)

        'Send command to remote controller.
        mbytRFCommand = CByte(AscW("S")) 'ASCII instruction 'S'.
        mintState = 4

    End Sub


    Private Sub ButtonPlay1_Click(sender As Object, e As EventArgs) Handles ButtonPlay1.Click
        Dim nTemp As Integer
        Dim nx As Integer


        nTemp = 0 'Sequence 1

        If mintMotorSequenceNo > 0 Then 'Make sure there is valid data store here
            mbytRFCommand = _RES_COEFFICIENT
            mbytRFArgument = 0
            mintState = 5

            'Restore the values of trackbars and coefficients labels.
            TrackBarC1.Value = mintTrackBarValueRes(nTemp)(0)
            TrackBarC2.Value = mintTrackBarValueRes(nTemp)(1)
            TrackBarC3.Value = mintTrackBarValueRes(nTemp)(2)
            TrackBarC4.Value = mintTrackBarValueRes(nTemp)(3)
            TrackBarC5.Value = mintTrackBarValueRes(nTemp)(4)
            TrackBarC6.Value = mintTrackBarValueRes(nTemp)(5)
            TrackBarC7.Value = mintTrackBarValueRes(nTemp)(6)
            TrackBarC8.Value = mintTrackBarValueRes(nTemp)(7)
            TrackBarC9.Value = mintTrackBarValueRes(nTemp)(8)
            TrackBarC10.Value = mintTrackBarValueRes(nTemp)(9)

            For nx = 0 To 9
                mdblC(nx) = mdblCRes(nTemp)(nx)
            Next
            LabelC1Val.Text = CStr(mdblC(0))
            LabelC2Val.Text = CStr(mdblC(1))
            LabelC3Val.Text = CStr(mdblC(2))
            LabelC4Val.Text = CStr(mdblC(3))
            LabelC5Val.Text = CStr(mdblC(4))
            LabelC6Val.Text = CStr(mdblC(5))
            LabelC7Val.Text = CStr(mdblC(6))
            LabelC8Val.Text = CStr(mdblC(7))
            LabelC9Val.Text = CStr(mdblC(8))
            LabelC10Val.Text = CStr(mdblC(9))
        End If

    End Sub

    Private Sub ButtonPlay2_Click(sender As Object, e As EventArgs) Handles ButtonPlay2.Click
        Dim nTemp As Integer
        Dim nx As Integer

        nTemp = 1 'Sequence 2

        If mintMotorSequenceNo > 1 Then 'Make sure there is valid data store here

            mbytRFCommand = _RES_COEFFICIENT
            mbytRFArgument = 1
            mintState = 5

            'Restore the values of trackbars and coefficients labels.
            TrackBarC1.Value = mintTrackBarValueRes(nTemp)(0)
            TrackBarC2.Value = mintTrackBarValueRes(nTemp)(1)
            TrackBarC3.Value = mintTrackBarValueRes(nTemp)(2)
            TrackBarC4.Value = mintTrackBarValueRes(nTemp)(3)
            TrackBarC5.Value = mintTrackBarValueRes(nTemp)(4)
            TrackBarC6.Value = mintTrackBarValueRes(nTemp)(5)
            TrackBarC7.Value = mintTrackBarValueRes(nTemp)(6)
            TrackBarC8.Value = mintTrackBarValueRes(nTemp)(7)
            TrackBarC9.Value = mintTrackBarValueRes(nTemp)(8)
            TrackBarC10.Value = mintTrackBarValueRes(nTemp)(9)

            For nx = 0 To 9
                mdblC(nx) = mdblCRes(nTemp)(nx)
            Next
            LabelC1Val.Text = CStr(mdblC(0))
            LabelC2Val.Text = CStr(mdblC(1))
            LabelC3Val.Text = CStr(mdblC(2))
            LabelC4Val.Text = CStr(mdblC(3))
            LabelC5Val.Text = CStr(mdblC(4))
            LabelC6Val.Text = CStr(mdblC(5))
            LabelC7Val.Text = CStr(mdblC(6))
            LabelC8Val.Text = CStr(mdblC(7))
            LabelC9Val.Text = CStr(mdblC(8))
            LabelC10Val.Text = CStr(mdblC(9))
        End If
    End Sub

    Private Sub ButtonPlay3_Click(sender As Object, e As EventArgs) Handles ButtonPlay3.Click
        Dim nTemp As Integer
        Dim nx As Integer


        nTemp = 2 'Sequence 3

        If mintMotorSequenceNo > 2 Then 'Make sure there is valid data store here
            mbytRFCommand = _RES_COEFFICIENT
            mbytRFArgument = 2
            mintState = 5

            'Restore the values of trackbars and coefficients labels.
            TrackBarC1.Value = mintTrackBarValueRes(nTemp)(0)
            TrackBarC2.Value = mintTrackBarValueRes(nTemp)(1)
            TrackBarC3.Value = mintTrackBarValueRes(nTemp)(2)
            TrackBarC4.Value = mintTrackBarValueRes(nTemp)(3)
            TrackBarC5.Value = mintTrackBarValueRes(nTemp)(4)
            TrackBarC6.Value = mintTrackBarValueRes(nTemp)(5)
            TrackBarC7.Value = mintTrackBarValueRes(nTemp)(6)
            TrackBarC8.Value = mintTrackBarValueRes(nTemp)(7)
            TrackBarC9.Value = mintTrackBarValueRes(nTemp)(8)
            TrackBarC10.Value = mintTrackBarValueRes(nTemp)(9)

            For nx = 0 To 9
                mdblC(nx) = mdblCRes(nTemp)(nx)
            Next
            LabelC1Val.Text = CStr(mdblC(0))
            LabelC2Val.Text = CStr(mdblC(1))
            LabelC3Val.Text = CStr(mdblC(2))
            LabelC4Val.Text = CStr(mdblC(3))
            LabelC5Val.Text = CStr(mdblC(4))
            LabelC6Val.Text = CStr(mdblC(5))
            LabelC7Val.Text = CStr(mdblC(6))
            LabelC8Val.Text = CStr(mdblC(7))
            LabelC9Val.Text = CStr(mdblC(8))
            LabelC10Val.Text = CStr(mdblC(9))
        End If

    End Sub

    Private Sub ButtonForwardFast_Click(sender As Object, e As EventArgs) Handles ButtonForwardFast.Click
        mbytRFCommand = CByte(AscW("f")) 'ASCII instruction 'f'.
        mintState = 4
    End Sub

    Private Sub ButtonForwardSlow_Click(sender As Object, e As EventArgs) Handles ButtonForwardSlow.Click
        mbytRFCommand = CByte(AscW("s")) 'ASCII instruction 's'.
        mintState = 4
    End Sub

    Private Sub ButtonTurnLeft_Click(sender As Object, e As EventArgs) Handles ButtonTurnLeft.Click
        mbytRFCommand = CByte(AscW("l")) 'ASCII instruction 'l'. 'Turn left.
        mintState = 4
    End Sub

    Private Sub ButtonTurnRight_Click(sender As Object, e As EventArgs) Handles ButtonTurnRight.Click
        mbytRFCommand = CByte(AscW("r")) 'ASCII instruction 'r'.  'Turn right.
        mintState = 4
    End Sub

    Private Sub ButtonBackward_Click(sender As Object, e As EventArgs) Handles ButtonBackward.Click
        mbytRFCommand = CByte(AscW("t")) 'ASCII instruction 't'.
        mintState = 4
    End Sub

    Private Sub ButtonModeNormal_Click(sender As Object, e As EventArgs) Handles ButtonModeNormal.Click
        mbytRFCommand = CByte(AscW("N")) 'ASCII instruction 'N'.
        mintState = 4
    End Sub

    Private Sub ButtonModeTest1_Click(sender As Object, e As EventArgs) Handles ButtonModeTest1.Click
        mbytRFCommand = CByte(AscW("T")) 'ASCII instruction 'T'.
        mintState = 4
    End Sub

    Private Sub ButtonTest2_Click(sender As Object, e As EventArgs) Handles ButtonModeTest2.Click
        mbytRFCommand = CByte(AscW("D")) 'ASCII instruction 'D'.
        mintState = 4
    End Sub

    Private Sub ButtonManualAuto_Click(sender As Object, e As EventArgs) Handles ButtonManualAuto.Click
        mbytRFCommand = CByte(AscW("m")) 'ASCII instruction 'm'.
        mintState = 4
    End Sub

    Private Sub ButtonTurnLeftCont_Click(sender As Object, e As EventArgs) Handles ButtonTurnLeftCont.Click
        mbytRFCommand = CByte(AscW("c")) 'ASCII instruction 'c'.
        mintState = 4
    End Sub

    Private Sub ButtonTurnRightCont_Click(sender As Object, e As EventArgs) Handles ButtonTurnRightCont.Click
        mbytRFCommand = CByte(AscW("C")) 'ASCII instruction 'C'.
        mintState = 4
    End Sub

    Private Sub ButtonTest_Click(sender As Object, e As EventArgs) Handles ButtonTest.Click
        mbytRFCommand = CByte(AscW("E")) 'ASCII instruction 'E'.
        mintState = 4
    End Sub

    Private Sub ButtonStop_Click(sender As Object, e As EventArgs) Handles ButtonStop.Click
        mbytRFCommand = CByte(AscW("x")) 'ASCII instruction 'x'.
        mintState = 4
    End Sub

    Private Sub ButtonForwardNormal_Click(sender As Object, e As EventArgs) Handles ButtonForwardNormal.Click
        mbytRFCommand = CByte(AscW("F")) 'ASCII instruction 'F'.
        mintState = 4
    End Sub

    Private Sub ButtonRestoreFactoryDefault_Click(sender As Object, e As EventArgs) Handles ButtonRestoreFactoryDefault.Click
        mbytRFCommand = CByte(AscW("R")) 'ASCII instruction 'R'.
        mintState = 4
    End Sub

    Private Sub ButtonSelectParam_Click(sender As Object, e As EventArgs) Handles ButtonSelectParam.Click
        mbytRFCommand = CByte(AscW("P")) 'ASCII instruction 'P'.
        mintState = 4
    End Sub

    Private Sub Trace1RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles Trace1RadioButton1.CheckedChanged
        mintXYplot1Trace1Select = 0
        Data1Label.Text = _PARAM1_TEXT
    End Sub

    Private Sub Trace1RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles Trace1RadioButton2.CheckedChanged
        mintXYplot1Trace1Select = 1
        Data1Label.Text = _PARAM2_TEXT
    End Sub

    Private Sub Trace1RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles Trace1RadioButton3.CheckedChanged
        mintXYplot1Trace1Select = 2
        Data1Label.Text = _PARAM3_TEXT
    End Sub

    Private Sub Trace1RadioButton4_CheckedChanged(sender As Object, e As EventArgs) Handles Trace1RadioButton4.CheckedChanged
        mintXYplot1Trace1Select = 3
        Data1Label.Text = _PARAM4_TEXT
    End Sub

    Private Sub Trace1RadioButton5_CheckedChanged(sender As Object, e As EventArgs) Handles Trace1RadioButton5.CheckedChanged
        mintXYplot1Trace1Select = 4
        Data1Label.Text = _PARAM5_TEXT
    End Sub

    Private Sub Trace1RadioButton6_CheckedChanged(sender As Object, e As EventArgs) Handles Trace1RadioButton6.CheckedChanged
        mintXYplot1Trace1Select = 5
        Data1Label.Text = _PARAM6_TEXT
    End Sub

    Private Sub Trace1RadioButton7_CheckedChanged(sender As Object, e As EventArgs) Handles Trace1RadioButton7.CheckedChanged
        mintXYplot1Trace1Select = 6
        Data1Label.Text = _PARAM7_TEXT
    End Sub

    Private Sub Trace1RadioButton8_CheckedChanged(sender As Object, e As EventArgs) Handles Trace1RadioButton8.CheckedChanged
        mintXYplot1Trace1Select = 7
        Data1Label.Text = _PARAM8_TEXT
    End Sub

    Private Sub Trace1RadioButton9_CheckedChanged(sender As Object, e As EventArgs) Handles Trace1RadioButton9.CheckedChanged
        mintXYplot1Trace1Select = 8
        Data1Label.Text = _PARAM9_TEXT
    End Sub

    Private Sub Trace1RadioButton10_CheckedChanged(sender As Object, e As EventArgs) Handles Trace1RadioButton10.CheckedChanged
        mintXYplot1Trace1Select = 9
        Data1Label.Text = _PARAM10_TEXT
    End Sub

    Private Sub Trace1RadioButton11_CheckedChanged(sender As Object, e As EventArgs) Handles Trace1RadioButton11.CheckedChanged
        mintXYplot1Trace1Select = 10
        Data1Label.Text = _PARAM11_TEXT
    End Sub

    Private Sub Trace1RadioButton12_CheckedChanged(sender As Object, e As EventArgs) Handles Trace1RadioButton12.CheckedChanged
        mintXYplot1Trace1Select = 11
        Data1Label.Text = _PARAM12_TEXT
    End Sub

    Private Sub Trace2RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles Trace2RadioButton1.CheckedChanged
        mintXYPlot1Trace2Select = 0
        Data2Label.Text = _PARAM1_TEXT
    End Sub

    Private Sub Trace2RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles Trace2RadioButton2.CheckedChanged
        mintXYPlot1Trace2Select = 1
        Data2Label.Text = _PARAM2_TEXT
    End Sub

    Private Sub Trace2RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles Trace2RadioButton3.CheckedChanged
        mintXYPlot1Trace2Select = 2
        Data2Label.Text = _PARAM3_TEXT
    End Sub

    Private Sub Trace2RadioButton4_CheckedChanged(sender As Object, e As EventArgs) Handles Trace2RadioButton4.CheckedChanged
        mintXYPlot1Trace2Select = 3
        Data2Label.Text = _PARAM4_TEXT
    End Sub

    Private Sub Trace2RadioButton5_CheckedChanged(sender As Object, e As EventArgs) Handles Trace2RadioButton5.CheckedChanged
        mintXYPlot1Trace2Select = 4
        Data2Label.Text = _PARAM5_TEXT
    End Sub

    Private Sub Trace2RadioButton6_CheckedChanged(sender As Object, e As EventArgs) Handles Trace2RadioButton6.CheckedChanged
        mintXYPlot1Trace2Select = 5
        Data2Label.Text = _PARAM6_TEXT
    End Sub

    Private Sub Trace2RadioButton7_CheckedChanged(sender As Object, e As EventArgs) Handles Trace2RadioButton7.CheckedChanged
        mintXYPlot1Trace2Select = 6
        Data2Label.Text = _PARAM7_TEXT
    End Sub

    Private Sub Trace2RadioButton8_CheckedChanged(sender As Object, e As EventArgs) Handles Trace2RadioButton8.CheckedChanged
        mintXYPlot1Trace2Select = 7
        Data2Label.Text = _PARAM8_TEXT
    End Sub

    Private Sub Trace2RadioButton9_CheckedChanged(sender As Object, e As EventArgs) Handles Trace2RadioButton9.CheckedChanged
        mintXYPlot1Trace2Select = 8
        Data2Label.Text = ""
    End Sub

    Private Sub Trace3RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles Trace3RadioButton1.CheckedChanged
        mintXYPlot1Trace3Select = 0
        Data3Label.Text = _PARAM4_TEXT
    End Sub

    Private Sub Trace3RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles Trace3RadioButton2.CheckedChanged
        mintXYPlot1Trace3Select = 1
        Data3Label.Text = _PARAM7_TEXT
    End Sub

    Private Sub Trace3RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles Trace3RadioButton3.CheckedChanged
        mintXYPlot1Trace3Select = 2
        Data3Label.Text = _PARAM8_TEXT
    End Sub

    Private Sub Trace3RadioButton4_CheckedChanged(sender As Object, e As EventArgs) Handles Trace3RadioButton4.CheckedChanged
        mintXYPlot1Trace3Select = 3
        Data3Label.Text = "Tilt angle from wheels"
    End Sub

    Private Sub Trace3RadioButton5_CheckedChanged(sender As Object, e As EventArgs) Handles Trace3RadioButton5.CheckedChanged
        mintXYPlot1Trace3Select = 4
        Data3Label.Text = ""
    End Sub

    Private Sub Trace4RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles Trace4RadioButton1.CheckedChanged
        mintXYPlot1Trace4Select = 0
        Data4Label.Text = _PARAM9_TEXT
    End Sub

    Private Sub Trace4RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles Trace4RadioButton2.CheckedChanged
        mintXYPlot1Trace4Select = 1
        Data4Label.Text = _PARAM10_TEXT
    End Sub

    Private Sub Trace4RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles Trace4RadioButton3.CheckedChanged
        mintXYPlot1Trace4Select = 2
        Data4Label.Text = _PARAM11_TEXT
    End Sub

    Private Sub Trace4RadioButton4_CheckedChanged(sender As Object, e As EventArgs) Handles Trace4RadioButton4.CheckedChanged
        mintXYPlot1Trace4Select = 3
        Data4Label.Text = _PARAM12_TEXT
    End Sub

    Private Sub Trace4RadioButton5_CheckedChanged(sender As Object, e As EventArgs) Handles Trace4RadioButton5.CheckedChanged
        mintXYPlot1Trace4Select = 4
        Data4Label.Text = ""
    End Sub

End Class
