

Public Class XYPlot_menuForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents ColorSelectDialog As System.Windows.Forms.ColorDialog
    Friend WithEvents SetBackgroundColorButton As System.Windows.Forms.Button
    Friend WithEvents DoneButton As System.Windows.Forms.Button
    Friend WithEvents CancelButton As System.Windows.Forms.Button
    Friend WithEvents SetLine1ColorButton As System.Windows.Forms.Button
    Friend WithEvents SetCurveWeightTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents appearancePictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents SetLine2ColorButton As System.Windows.Forms.Button
    Friend WithEvents SetLine3ColorButton As Button
    Friend WithEvents SetLine4ColorButton As Button
    Friend WithEvents SetGridColorButton As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.ColorSelectDialog = New System.Windows.Forms.ColorDialog()
        Me.SetBackgroundColorButton = New System.Windows.Forms.Button()
        Me.DoneButton = New System.Windows.Forms.Button()
        Me.CancelButton = New System.Windows.Forms.Button()
        Me.SetLine1ColorButton = New System.Windows.Forms.Button()
        Me.SetCurveWeightTextBox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.appearancePictureBox = New System.Windows.Forms.PictureBox()
        Me.SetGridColorButton = New System.Windows.Forms.Button()
        Me.SetLine2ColorButton = New System.Windows.Forms.Button()
        Me.SetLine3ColorButton = New System.Windows.Forms.Button()
        Me.SetLine4ColorButton = New System.Windows.Forms.Button()
        CType(Me.appearancePictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SetBackgroundColorButton
        '
        Me.SetBackgroundColorButton.Location = New System.Drawing.Point(111, 12)
        Me.SetBackgroundColorButton.Name = "SetBackgroundColorButton"
        Me.SetBackgroundColorButton.Size = New System.Drawing.Size(80, 48)
        Me.SetBackgroundColorButton.TabIndex = 0
        Me.SetBackgroundColorButton.Text = "Set Background Color"
        '
        'DoneButton
        '
        Me.DoneButton.Location = New System.Drawing.Point(31, 175)
        Me.DoneButton.Name = "DoneButton"
        Me.DoneButton.Size = New System.Drawing.Size(64, 32)
        Me.DoneButton.TabIndex = 1
        Me.DoneButton.Text = "Done"
        '
        'CancelButton
        '
        Me.CancelButton.Location = New System.Drawing.Point(111, 175)
        Me.CancelButton.Name = "CancelButton"
        Me.CancelButton.Size = New System.Drawing.Size(72, 32)
        Me.CancelButton.TabIndex = 2
        Me.CancelButton.Text = "Cancel"
        '
        'SetLine1ColorButton
        '
        Me.SetLine1ColorButton.Location = New System.Drawing.Point(111, 66)
        Me.SetLine1ColorButton.Name = "SetLine1ColorButton"
        Me.SetLine1ColorButton.Size = New System.Drawing.Size(80, 47)
        Me.SetLine1ColorButton.TabIndex = 4
        Me.SetLine1ColorButton.Text = "Set Line 1 Color"
        '
        'SetCurveWeightTextBox
        '
        Me.SetCurveWeightTextBox.Location = New System.Drawing.Point(125, 144)
        Me.SetCurveWeightTextBox.Name = "SetCurveWeightTextBox"
        Me.SetCurveWeightTextBox.Size = New System.Drawing.Size(48, 20)
        Me.SetCurveWeightTextBox.TabIndex = 5
        Me.SetCurveWeightTextBox.Text = "2"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(63, 144)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 16)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Plot Width"
        '
        'appearancePictureBox
        '
        Me.appearancePictureBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.appearancePictureBox.Location = New System.Drawing.Point(11, 12)
        Me.appearancePictureBox.Name = "appearancePictureBox"
        Me.appearancePictureBox.Size = New System.Drawing.Size(80, 101)
        Me.appearancePictureBox.TabIndex = 7
        Me.appearancePictureBox.TabStop = False
        '
        'SetGridColorButton
        '
        Me.SetGridColorButton.Location = New System.Drawing.Point(197, 12)
        Me.SetGridColorButton.Name = "SetGridColorButton"
        Me.SetGridColorButton.Size = New System.Drawing.Size(80, 48)
        Me.SetGridColorButton.TabIndex = 8
        Me.SetGridColorButton.Text = "Set Grid Color"
        '
        'SetLine2ColorButton
        '
        Me.SetLine2ColorButton.Location = New System.Drawing.Point(197, 66)
        Me.SetLine2ColorButton.Name = "SetLine2ColorButton"
        Me.SetLine2ColorButton.Size = New System.Drawing.Size(80, 47)
        Me.SetLine2ColorButton.TabIndex = 9
        Me.SetLine2ColorButton.Text = "Set Line 2 Color"
        '
        'SetLine3ColorButton
        '
        Me.SetLine3ColorButton.Location = New System.Drawing.Point(196, 119)
        Me.SetLine3ColorButton.Name = "SetLine3ColorButton"
        Me.SetLine3ColorButton.Size = New System.Drawing.Size(80, 47)
        Me.SetLine3ColorButton.TabIndex = 10
        Me.SetLine3ColorButton.Text = "Set Line 3 Color"
        '
        'SetLine4ColorButton
        '
        Me.SetLine4ColorButton.Location = New System.Drawing.Point(196, 172)
        Me.SetLine4ColorButton.Name = "SetLine4ColorButton"
        Me.SetLine4ColorButton.Size = New System.Drawing.Size(80, 47)
        Me.SetLine4ColorButton.TabIndex = 11
        Me.SetLine4ColorButton.Text = "Set Line 4 Color"
        '
        'XYPlot_menuForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(288, 228)
        Me.Controls.Add(Me.SetLine4ColorButton)
        Me.Controls.Add(Me.SetLine3ColorButton)
        Me.Controls.Add(Me.SetLine2ColorButton)
        Me.Controls.Add(Me.SetGridColorButton)
        Me.Controls.Add(Me.appearancePictureBox)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.SetCurveWeightTextBox)
        Me.Controls.Add(Me.SetLine1ColorButton)
        Me.Controls.Add(Me.CancelButton)
        Me.Controls.Add(Me.DoneButton)
        Me.Controls.Add(Me.SetBackgroundColorButton)
        Me.Name = "XYPlot_menuForm"
        Me.Text = "Appearance Setting"
        CType(Me.appearancePictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

    'Public fields

    'Private fields
    Private userBackgroundColor As Color
    Private userCurve1Color As Color
    Private userCurve2Color As Color
    Private userCurve3Color As Color
    Private userCurve4Color As Color
    Private userGridcolor As Color
    Private intCurveWeight As Integer
    Private callingForm As Form = Form.ActiveForm 'Get the reference to current active form
    Private callingFormPictureBox As Control
    Private callingFormCurve1 As Control
    Private callingFormCurve2 As Control
    Private callingFormCurve3 As Control
    Private callingFormCurve4 As Control
    Private callingFormLabel1 As Control
    Private callingFormLabel2 As Control
    Private callingFormLabel3 As Control
    Private callingFormLabel4 As Control


    Private Sub XYPlot_menuForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'callingFormPictureBox = callingForm.Controls.Item(7) 'Index 7 refers to XYPictureBox control
        'callingFormCurve1 = callingForm.Controls.Item(8)  'Index 8 refers to Trace 1
        'callingFormCurve2 = callingForm.Controls.Item(9)  'Index 9 refers to Trace 2
        'callingFormCurve3 = callingForm.Controls.Item(10)  'Index 10 refers to Trace 3
        callingFormPictureBox = callingForm.Controls.Item(8) 'Index 8 refers to XYPictureBox control
        callingFormCurve1 = callingForm.Controls.Item(9)  'Index 9 refers to Trace 1
        callingFormCurve2 = callingForm.Controls.Item(10)  'Index 10 refers to Trace 2
        callingFormCurve3 = callingForm.Controls.Item(11)  'Index 11 refers to Trace 3
        callingFormCurve4 = callingForm.Controls.Item(12)   'Index 12 refers to Trace 4

        'callingFormLabel1 = callingForm.Controls.Item(2)    'Index 2 refers to label for Trace 1
        'callingFormLabel2 = callingForm.Controls.Item(1)    'Index 1 refers to label for Trace 2
        'callingFormLabel3 = callingForm.Controls.Item(0)    'Index 0 refers to label for Trace 3
        callingFormLabel1 = callingForm.Controls.Item(3)    'Index 2 refers to label for Trace 1
        callingFormLabel2 = callingForm.Controls.Item(2)    'Index 1 refers to label for Trace 2
        callingFormLabel3 = callingForm.Controls.Item(1)    'Index 0 refers to label for Trace 3
        callingFormLabel4 = callingForm.Controls.Item(0)

        userBackgroundColor = callingFormPictureBox.BackColor

        userGridcolor = callingFormCurve1.BackColor

        intCurveWeight = callingFormCurve1.Height
        'intCurveWeight = 1

        userCurve1Color = callingFormCurve1.ForeColor
        userCurve2Color = callingFormCurve2.ForeColor
        userCurve3Color = callingFormCurve3.ForeColor
        userCurve4Color = callingFormCurve4.ForeColor

        'Setup appearancePictureBox to reflect the XYPlot window
        appearancePictureBox.BackColor = userBackgroundColor

    End Sub

    Private Sub SetBackgroundColorButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetBackgroundColorButton.Click

        ColorSelectDialog.Color = callingFormPictureBox.BackColor 'Set the color to current color of Picture Box first
        ColorSelectDialog.ShowDialog()  'Show color selection dialog box
        userBackgroundColor = ColorSelectDialog.Color 'Assign new color after selection
        appearancePictureBox.Refresh()

    End Sub

    Private Sub SetLine1ColorButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetLine1ColorButton.Click

        ColorSelectDialog.Color = callingFormCurve1.ForeColor  'Set the color to current color of line plot first
        ColorSelectDialog.ShowDialog()  'Show color selection dialog box
        userCurve1Color = ColorSelectDialog.Color 'Assign new color after selection
        appearancePictureBox.Refresh()  'Show how the line will look like in picture box.

    End Sub

    Private Sub SetLine2ColorButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetLine2ColorButton.Click

        ColorSelectDialog.Color = callingFormCurve2.ForeColor  'Set the color to current color of line plot first
        ColorSelectDialog.ShowDialog()  'Show color selection dialog box
        userCurve2Color = ColorSelectDialog.Color 'Assign new color after selection
        appearancePictureBox.Refresh() 'Show how the line will look like in picture box.

    End Sub

    Private Sub SetLine3ColorButton_Click(sender As Object, e As EventArgs) Handles SetLine3ColorButton.Click

        ColorSelectDialog.Color = callingFormCurve3.ForeColor  'Set the color to current color of line plot first
        ColorSelectDialog.ShowDialog()  'Show color selection dialog box
        userCurve3Color = ColorSelectDialog.Color 'Assign new color after selection
        appearancePictureBox.Refresh() 'Show how the line will look like in picture box.

    End Sub

    Private Sub SetLine4ColorButton_Click(sender As Object, e As EventArgs) Handles SetLine4ColorButton.Click

        ColorSelectDialog.Color = callingFormCurve4.ForeColor  'Set the color to current color of line plot first
        ColorSelectDialog.ShowDialog()  'Show color selection dialog box
        userCurve4Color = ColorSelectDialog.Color 'Assign new color after selection
        appearancePictureBox.Refresh() 'Show how the line will look like in picture box.

    End Sub

    Private Sub SetGridColorButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetGridColorButton.Click

        ColorSelectDialog.Color = callingFormCurve1.BackColor   'Set the color to current color of grid lines first
        ColorSelectDialog.ShowDialog()  'Show color selection dialog box
        userGridcolor = ColorSelectDialog.Color 'Assign new color after selection
        appearancePictureBox.Refresh()

    End Sub

    Private Sub SetCurveWeightTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetCurveWeightTextBox.TextChanged

        Try
            If SetCurveWeightTextBox.Text <> "" Then
                intCurveWeight = CInt(SetCurveWeightTextBox.Text)
            End If
            If intCurveWeight < 1 Then 'Minimum weight should be +1
                intCurveWeight = 1
            End If
        Catch ex As Exception
            intCurveWeight = 1
        End Try

        appearancePictureBox.Refresh()

    End Sub

    Private Sub DoneButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DoneButton.Click

        callingFormPictureBox.BackColor = userBackgroundColor   'Reassign the background color of picturebox.
        callingFormCurve1.ForeColor = userCurve1Color           'Reassigne the foreground color and line width for Trace 1 to 3.
        callingFormCurve1.BackColor = userGridcolor
        callingFormCurve1.Height = intCurveWeight
        callingFormCurve2.ForeColor = userCurve2Color
        callingFormCurve2.BackColor = userGridcolor
        callingFormCurve2.Height = intCurveWeight
        callingFormCurve3.ForeColor = userCurve3Color
        callingFormCurve3.BackColor = userGridcolor
        callingFormCurve3.Height = intCurveWeight
        callingFormCurve4.ForeColor = userCurve4Color
        callingFormCurve4.BackColor = userGridcolor
        callingFormCurve4.Height = intCurveWeight

        callingFormLabel1.BackColor = userCurve1Color           'Refresh the background color for Trace 1 to 3 labels.
        callingFormLabel2.BackColor = userCurve2Color
        callingFormLabel3.BackColor = userCurve3Color
        callingFormLabel4.BackColor = userCurve4Color

        Me.Close()

    End Sub

    Private Sub CancelButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CancelButton.Click

        Me.Close()

    End Sub

    Private Sub appearancePictureBox_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles appearancePictureBox.Paint

        Dim appearanceGraphics As Graphics = e.Graphics 'Declare a graphics object
        Dim MainPen1 As New Pen(userCurve1Color, intCurveWeight)
        Dim MainPen2 As New Pen(userCurve2Color, intCurveWeight)
        Dim MainPen3 As New Pen(userCurve3Color, intCurveWeight)
        Dim MainPen4 As New Pen(userCurve4Color, intCurveWeight)
        Dim GridPen As New Pen(userGridcolor, 1)
        Dim sngHeight As Single = appearancePictureBox.Height
        Dim sngWidth As Single = appearancePictureBox.Width

        'Set the appearance of the picturebox to reflect the selection by the user
        appearancePictureBox.BackColor = userBackgroundColor
        appearanceGraphics.DrawLine(MainPen1, 0, sngHeight / 2, sngWidth, sngHeight / 2)    'Draw Trace 1
        appearanceGraphics.DrawLine(MainPen2, 0, sngHeight / 3, sngWidth, sngHeight / 3)    'Draw Trace 2
        appearanceGraphics.DrawLine(MainPen3, 0, sngHeight / 4, sngWidth, sngHeight / 4)    'Draw Trace 3
        appearanceGraphics.DrawLine(MainPen4, 0, sngHeight / 5, sngWidth, sngHeight / 5)    'Draw Trace 4
        appearanceGraphics.DrawLine(GridPen, 0, sngHeight / 3, sngWidth, sngHeight / 3) 'Draw grid
        appearanceGraphics.DrawLine(GridPen, sngWidth / 2, 0, sngWidth / 2, sngHeight) 'Draw grid

    End Sub

End Class
